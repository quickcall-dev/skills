---
title: "prelim-research-scope"
experiment: 004-pi-dev-harness
created: "2026-04-25 09:33 UTC"
---

# Prelim Research Scope — pi.dev

## Context (from web sweep)

pi.dev = minimalist terminal coding harness by Mario Zechner (`badlogic/pi-mono`). Positioned against Claude Code / Cursor / Copilot. Core philosophy: **tiny core, aggressive extensibility**.

### What it ships

- **4 built-in tools only**: Read, Write, Edit, Bash. Everything else = extension.
- **15+ LLM providers**: Anthropic, OpenAI, Google, Azure, Bedrock, Mistral, Groq, Cerebras, xAI, HuggingFace, Kimi, MiniMax, OpenRouter, Ollama. Mid-session model swap (`/model`, Ctrl+L). Token + cost tracking.
- **4 run modes**: interactive TUI, print/JSON, RPC, SDK (embeddable).
- **Session trees**: sessions stored as trees, `/tree` to branch from any prior point.
- **Project config**: `AGENTS.md` (loaded from `~/.pi/agent/`, parents, cwd), `SYSTEM.md` (replace/append default sys prompt per-project).
- **Extension surface**: TypeScript modules. 25+ hooks. Hot-reload. Skills, prompt templates, themes, sub-agents, keybindings, tool-exec interception, full TUI access. Distribute via npm/git.

### Notable third-party

- `oh-my-pi` (can1357): hash-anchored edits, optimized tool harness, LSP, Python, browser, sub-agents.

### Differentiators vs Claude Code

- No baked-in plan mode / sub-agents — opt-in via extensions.
- Provider-agnostic from day 1 (Claude Code is Anthropic-locked).
- RPC + SDK modes → embed in pipelines / other tools.
- Session-as-tree (vs linear).

---

## Open questions for deep research

### A. Architecture & internals
1. How does extension hook system work (lifecycle, ordering, cancellation)?
2. RPC mode protocol — JSON-RPC? gRPC? wire format?
3. Session tree storage format + how `/tree` resolves branches.
4. Tool dispatch: how does Read/Write/Edit/Bash compare to Claude Code's (e.g. hash-anchor edits in `oh-my-pi`)?
5. Multi-provider abstraction layer — how is tool-use normalized across providers w/ different tool schemas?

### B. Power workflows
6. Sub-agent patterns via extensions (parallel? DAG? reviewer-gated?).
7. Skills system vs Claude Code skills — composability, discovery, namespacing.
8. Prompt template ecosystem — what patterns exist?
9. SDK embedding — concrete examples (CI, batch jobs, custom UIs).
10. Model-mid-session swap — context handoff fidelity, cost optimization patterns.

### C. Ecosystem
11. Top published packages on npm under `@pi/*` or similar.
12. Notable extensions in the wild (`oh-my-pi` and beyond).
13. Community size, release cadence, governance (solo maintainer?).

### D. Comparison axes (vs Claude Code, Cursor, aider, codex)
14. Token efficiency / context management.
15. Headless / agentic loop suitability.
16. Provider lock-in cost.
17. Customization ceiling.

### E. Practical evaluation
18. Install + basic run on this machine.
19. Build one trivial extension (hello-world hook).
20. Compare a real task done in pi vs Claude Code (same prompt, same repo).

---

## Proposed research phases

| Phase | Output | Method |
|-------|--------|--------|
| 1. Source dive | finding: architecture map | clone `badlogic/pi-mono`, read core + hooks |
| 2. Docs sweep | finding: feature matrix | pi.dev/packages, README, AGENTS.md examples |
| 3. Ecosystem scan | finding: extensions catalog | npm search, github search `pi-extension` |
| 4. Hands-on | finding: install + hello-extension | local install, build one extension |
| 5. Comparative bench | review: pi vs Claude Code | same task both, diff outcomes |
| 6. Power-workflow synthesis | finding: workflow recipes | combine 1-5 into actionable patterns |

---

## Decision points before deep research

- **Scope cut**: all 6 phases or trim? (Phase 5 = expensive.)
- **Hands-on depth**: just install + hello, or build something real (e.g. fleet-runner extension)?
- **Comparison target**: Claude Code only, or also aider / codex / cursor?
- **Output form**: findings only, or also a published writeup?

## Next

User picks scope → spawn research agents per phase (parallelizable: 1, 2, 3 independent; 4 needs install; 5 needs 4).
