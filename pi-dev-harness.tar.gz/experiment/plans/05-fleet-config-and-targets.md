---
title: "fleet-config-and-targets"
experiment: 004-pi-dev-harness
created: "2026-04-25 09:51 UTC"
---

# Fleet Config + Health Targets + Source Citation

Supersedes the **model / budget / cost** sections of plans 02 + 03 + 04. All other content (worker briefs, MECE source partition, DAG, synthesis spec) stays canonical.

---

## Provider + model assignment

| Tier | Workers | Provider | Model | Reasoning effort | Per-worker budget |
|---|---|---|---|---|---|
| Research | A1-A5, B1-B5, C1-C3 (13) | `codex` | `gpt-5.3` | `medium` | **$10** |
| Synthesis | S2, S3, S4, S5, S6 (5) | `claude` | `opus-4-6` | `medium` | **$10** |
| Index | S1 | `claude` | `opus-4-6` | `medium` | **$10** (overkill, will undershoot) |

**Total cap**: 13 × $10 + 6 × $10 = **$190**.

Provider switch in fleet.json:
```json
"config": {
  "provider": "codex",
  "model": "gpt-5.3",
  "reasoning_effort": "medium",
  "cost_cap_usd": 190.0
},
"workers": [
  { "id": "A1", "max_budget_usd": 10.0, ... },
  ...
  { "id": "S2", "provider": "claude", "model": "opus-4-6",
    "reasoning_effort": "medium", "max_budget_usd": 10.0, "depends_on": ["A1","A2","A3","A4","A5"] }
]
```

---

## Health targets per worker

Each worker must demonstrate **exploration breadth** before writing the finding. Stop conditions are the *minimum* — go deeper if budget allows.

### Common floor (every research worker)

- **≥ 100 distinct sources consulted** (URLs, files, repos, gists, npm pages, GH issues, posts, talks, tweets — each counted once).
- **≥ 30 unique domains/origins** (avoid 100 hits all on one site).
- **≥ 10 primary sources** (source code files, official docs, maintainer-authored content).
- **≥ 5 contradicting or surprising signals noted** (forces "Gotchas" section to be real).
- **Exploration log**: every consulted URL/path appended to `findings/NN-<slug>.sources.md` (1 line per source: `- [title](url) — what it gave me`).

If a worker can't hit 100 sources within $10, that's a signal — it must record **why** (niche topic, dead ecosystem, etc.) in the finding's "Open questions" section. Don't fake the count.

### Per-track tailoring

| Worker | Source mix expectation |
|---|---|
| A1 bootstrap | 60% pi-mono code/docs, 30% blog/walkthroughs, 10% issues |
| A2 core tools | 80% source code, 20% docs/issues |
| A3 run modes | 70% source code (modes/), 20% RPC/SDK clients in wild, 10% docs |
| A4 providers | 50% pi provider source, 30% per-provider docs, 20% comparison posts |
| A5 sessions | 80% source code, 20% issue threads on tree/resume |
| B1 extensions | 70% source + example exts, 30% Mario's writeups + community exts |
| B2 skills/prompts | 60% source + skill examples, 40% published packages |
| B3 ecosystem | 100% breadth — npm search, GH topic search, awesome-pi if exists, oh-my-pi + others |
| B4 power users | 100% breadth — blogs, HN, Reddit, X/Twitter, YouTube, conference talks, podcast mentions |
| B5 comparison | 40% pi material, 60% Claude Code/Cursor/aider/codex docs + comparative reviews |
| C1 call-sites | 100% local — every script in `skills/*/scripts/`, every flag, every JSONL field |
| C2 pi CLI | 100% pi-mono source — CLI entry, modes, flag tables |
| C3 redesign | 50% pi extension API source, 30% existing pi extensions, 20% my fleet skills (cross-ref) |

### Synthesis worker targets

Synthesis workers don't need 100 sources — they consume the 13 worker findings + their `.sources.md` exploration logs. Target instead:

- **100% finding coverage** — every relevant worker finding must be cited at least once or explicitly excluded with reason.
- **≥ 3 cross-finding contradictions** surfaced (or noted "no contradictions found, here's why").
- **≥ 5 actionable items** in S4/S5 (verdict per skill).
- **0 lossy summaries** — link to source finding for any compressed claim.

---

## Source citation contract (mandatory)

Every research worker produces **two files**:

1. `findings/NN-<slug>.md` — the finding (frontmatter + standard sections from plan 02).
2. `findings/NN-<slug>.sources.md` — the exploration log, **one source per line**:

```markdown
---
worker: A1
finding: 03-pi-bootstrap
created: "<ISO ts>"
total_sources: 117
unique_domains: 34
primary_sources: 18
---

## Sources consulted

- [pi-mono README](https://github.com/badlogic/pi-mono#readme) — install steps, AGENTS.md path
- [pi.dev landing](https://pi.dev/) — confirmed 4 modes
- [packages/coding-agent/src/cli.ts](https://github.com/badlogic/pi-mono/blob/main/packages/coding-agent/src/cli.ts) — entry point, flag parsing
- ... (≥100 lines)

## Sources cited in finding

(subset of above, marked with which finding section uses them)

- finding §Building blocks → [pi-mono README]
- finding §Code refs → [src/cli.ts:42]
- ...
```

**Why two files**: separates *exploration breadth* (sources.md, the audit trail) from *substantive citations* (finding.md, the argument). Reviewer of the finding can verify breadth without scrolling through 100 links inline.

In-finding citations use `[label](url)` or `path:line` — no bare claims allowed. Synthesis docs cite worker findings by `NN-<slug>#section` not by re-fetching upstream.

---

## Stop conditions per worker

Worker stops when **first** of:

1. Budget hit ($10).
2. All health-target floors hit AND finding sections complete AND ≥1 reviewer-style self-critique noted.
3. Source pool exhausted (worker explicitly states "consulted everything reachable, here's the count").

Workers must **not** stop on (2) without all three sub-conditions. Premature stop = re-launch on next iteration (operator decision).

---

## Updates to prior plans (delta only)

- Plan 02 "Fleet config sketch": model + budget rows replaced by table above.
- Plan 03: same.
- Plan 04: synthesis budget/model rows replaced.
- Worker brief template (plan 02) gains 2 mandatory lines:
  - `Health target: ≥100 sources, ≥30 domains, ≥10 primary, ≥5 contradictions.`
  - `Citation contract: produce both NN-<slug>.md AND NN-<slug>.sources.md.`

---

## Decision points

12. **Budget escalation policy**: if a worker requests over $10 (rare but possible for B3/B4 ecosystem sweeps), auto-extend by $5 once or hard-stop?
13. **Source dedup**: same URL discovered by multiple workers — count separately per worker (current default) or central dedup?
14. **Web-fetch quota**: cap web-fetches per worker (e.g. 80) to avoid rate-limit / cost spikes?
15. **`gpt-5.3` availability**: confirm codex CLI on this machine supports `gpt-5.3` — if not, fallback to `gpt-5.2`?

---

## Next

User confirms config + targets → `/fleet-plan` consumes plans 02 + 03 + 04 + 05 → emits 13 worker `prompt.md` + 6 synth `prompt.md` + `fleet.json` with the model/budget table baked in.
