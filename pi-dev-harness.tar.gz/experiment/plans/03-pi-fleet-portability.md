---
title: "pi-fleet-portability"
experiment: 004-pi-dev-harness
created: "2026-04-25 09:42 UTC"
---

# Fleet Skills × pi.dev — Portability + Native Alternatives

Addendum to plan 02. Adds **3 new MECE workers** (C-bucket) covering: do my fleet skills run on pi? Is there a more idiomatic pi-native way?

---

## Context — what my skills look like (verified)

Inventory at `/home/sagar/skills/skills/`:

| Skill | LOC (scripts) | Provider abstraction | What it shells |
|---|---|---|---|
| `dag-fleet` | ~2,900 | `provider: claude\|codex` field per worker (launch.sh:159, :179-182, :475) | `claude -p` / `codex exec` in tmux |
| `worktree-fleet` | ~1,090 | same provider field | `claude -p` / `codex exec` in worktrees |
| `iterative-fleet` | ~1,590 | same | `claude -p` / `codex exec` in iter loops |
| `autoresearch-fleet` | ~1,350 | same | single-agent loop, `claude -p` / `codex exec` |
| `fleet-plan` | (planner only, no exec) | n/a | generates `fleet.json` + `prompt.md` |
| `doc` | ~750 | n/a | local file scaffolding |

**Key finding from inspection**: skills already have a clean **provider switch** at the script level (`DEFAULT_PROVIDER=$(jq -r '.config.provider // "claude"' …)`). Adding pi as a third provider = additive change, not a rewrite.

Common dependencies across all fleet skills:
- `tmux` (panes per worker)
- `jq` (fleet.json parsing)
- streaming JSONL output from CLI (`claude -p --output-format stream-json` / `codex exec --json`)
- session resume token (claude `--resume`, codex `--resume`)
- cost/token reporting fields in stream events

---

## Hypothesis

pi.dev exposes all the primitives needed:
- **print/JSON mode** ≈ `claude -p --output-format stream-json`
- **RPC mode** ≈ longer-lived control channel (may simplify status/feed.sh)
- **SDK mode** ≈ embed instead of shelling out (could replace tmux for some skills)
- **session-as-tree** ≈ richer than claude's linear `--resume`; could enable better iterative-fleet semantics
- **AGENTS.md / SYSTEM.md** ≈ replaces inline `--system-prompt` plumbing
- **Extensions / skills / hooks** ≈ could reimplement parts of fleet-plan + doc as pi-native

Open: does pi emit cost+tokens per turn? Does it support session resume by ID? Does print mode flush JSONL deterministically?

---

## New workers (Bucket C — Portability)

### C1 — Provider-abstraction audit

**Scope**: enumerate every place the fleet skills shell out to `claude` or `codex` and classify each call site by what pi must provide to substitute.

**Sources owned**:
- `skills/dag-fleet/scripts/launch.sh`, `relaunch-worker.sh`
- `skills/worktree-fleet/scripts/launch.sh`
- `skills/iterative-fleet/scripts/launch.sh`
- `skills/autoresearch-fleet/scripts/launch.sh`
- (read-only — do not edit)

**Out of scope**: pi internals (C2 owns), workflow synthesis (C3 owns).

**Deliverable**: `finding: fleet-provider-call-sites` — a table of every CLI invocation, flag, and what pi equivalent is needed. Output: ✅ trivial / ⚠️ needs adapter / ❌ blocking gap per call.

### C2 — pi CLI surface mapping (claude/codex → pi)

**Scope**: for each capability my skills require, find the pi equivalent. Build a translation table.

**Required capabilities** (from C1, but worker can derive independently):
| Capability | claude | codex | pi (TO RESEARCH) |
|---|---|---|---|
| Headless one-shot run | `claude -p "<prompt>"` | `codex exec "<prompt>"` | ? |
| Stream JSONL events | `--output-format stream-json` | `--json` | ? |
| Session ID for resume | `--resume <sid>` | `--resume <sid>` | `/tree` ? |
| Per-turn cost/tokens | event field | event field | ? |
| System prompt override | `--append-system-prompt` | flag | `SYSTEM.md` ? |
| Tool allowlist | `--allowed-tools` | sandbox flags | ? |
| Working-dir cwd | inherits | `--cd` | ? |
| Model override per call | `--model` | `--model` | `--model` / `/model` |
| Provider/model swap mid-run | n/a | n/a | `/model` (mid-session strength) |

**Sources owned**: pi-mono README + CLI source (`packages/coding-agent/src/cli.ts` and modes/print, modes/rpc).

**Deliverable**: `finding: pi-cli-translation` — definitive mapping table with exact pi flags, JSONL event field names, and known gaps.

### C3 — pi-native fleet redesign (better-than-port?)

**Scope**: assuming pi works, is there a *more idiomatic* implementation using pi's first-class features instead of porting bash + tmux?

**Questions**:
1. Could fleet-plan be a pi **skill** (npm pkg)?
2. Could dag-fleet's worker dispatch use pi **RPC mode** instead of tmux panes?
3. Could iterative-fleet's reviewer loop be a pi **extension hook** (post-turn)?
4. Could doc skill be replaced by a pi **prompt template** + skill?
5. Could session-as-tree replace iterative-fleet's per-iter directory shuffling?
6. What does pi's `/tree` give that `claude --resume` doesn't?
7. Cost/budget enforcement — pi hook vs external bash wrapper?

**Sources owned**: pi extension API docs, hooks list, RPC schema, skill format spec, `oh-my-pi` (for inspiration), Mario's blog posts on extension patterns.

**Deliverable**: `finding: pi-native-fleet-design` — for each of my 5 fleet skills + doc, a proposed pi-native architecture sketch with pros/cons vs current bash impl. Explicit verdict: keep-as-bash / port-to-pi-extension / hybrid.

---

## Updated MECE source partition (additions only)

| Worker | Primary sources |
|---|---|
| C1 | `skills/*/scripts/launch.sh` and `relaunch-worker.sh` (this repo, read-only) |
| C2 | `pi-mono/packages/coding-agent/src/cli.ts`, `src/modes/print/`, `src/modes/rpc/`, `packages/api/` |
| C3 | `pi-mono/packages/coding-agent/src/extensions/`, `src/hooks/`, `src/skills/`, `oh-my-pi/`, mariozechner.at posts on extensions |

Overlap check: C2 and B1 (extensions internals) — split is **C2 = CLI surface, B1 = extension hook lifecycle**. Different files, different angle.

---

## Updated worker count

**13 workers total**: A1-A5 (5) + B1-B5 (5) + C1-C3 (3).

Recommended fleet shape: `dag-fleet`. C1 has no deps (reads my repo). C2 + B1-B5 + A1-A5 read pi-mono (parallel). C3 depends on C2 + B1 + B2 (needs CLI map + extension internals + skills format) → DAG edge.

```
A1..A5  ┐
B1..B5  ├─ parallel (read pi-mono slices)
C1, C2  ┘
                C3 ← depends on C2, B1, B2
```

---

## Updated synthesis (post-fleet)

Same 4 outputs as plan 02 + 2 new:

5. **Portability verdict**: from C1+C2, "do my skills run on pi today, with what changes?" — a punch list.
6. **pi-native redesign roadmap**: from C3, prioritized list of which skills to rebuild pi-native vs leave as bash. Effort estimates.

---

## Updated decision points

(adds to plan 02's 5)

6. **Add C bucket?** Confirm 3 new workers → fleet goes 10 → 13.
7. **C3 verdict authority**: should C3 just propose, or also produce one prototype pi extension as proof? (Adds work + worktree.)
8. **My-skills read-only?** Confirm C1 worker may NOT edit my skills, only read + report.
9. **Output location for portability findings**: same `findings/` dir or separate `findings/portability/`?

---

## Next

User confirms additions → regenerate full prompt set (10+3 = 13 worker briefs) → run `/fleet-plan` against this file (not plan 02 alone).
