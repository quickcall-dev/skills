---
title: "synthesis-multi-doc"
experiment: 004-pi-dev-harness
created: "2026-04-25 09:47 UTC"
---

# Synthesis Spec — Multi-Doc, No Lossy Merge

**Supersedes** the "Synthesis phase" sections of plans 02 and 03. Reason: the original spec said "merge → ONE consolidated finding `pi-knowledge-base`" which collapses 13 workers into one doc → severe information loss. This plan replaces it with a **6-output multi-doc synthesis** + a thin index.

The 13-worker fleet shape, briefs, MECE source partition, and worker prompts in plans 02 + 03 remain canonical. **Only the synthesis section changes.**

---

## Principle

- **No merge-into-one.** Each synthesis output stays its own file with its own audience.
- **Index, don't compress.** S1 is a navigation doc with one-line hooks per finding — never a summary that replaces reading the source.
- **Audience-segregated.** Beginner doc and power-user recipes never co-mingle. Different reader, different file.
- **Lossless preservation.** Worker findings (the 13 raw outputs) stay verbatim under `findings/`. Synthesis docs **link to** them, never replace them.

---

## Synthesis outputs (6 separate findings)

| # | Slug (for `finding.sh`) | Source workers | Audience | Purpose |
|---|---|---|---|---|
| S1 | `pi-knowledge-index` | all 13 (link only) | navigation | thin landing page; links + 1-line hook per finding |
| S2 | `pi-beginner-onboarding` | A1, A2, A3, A4, A5 | new pi user | "start here" — install → first run → core tools → first session |
| S3 | `pi-power-workflow-recipes` | B1, B2, B3, B4, B5 | power user | 3–5 named workflows (e.g. "headless review via SDK", "multi-provider cost opt", "fleet via RPC") |
| S4 | `pi-portability-verdict` | C1, C2 | skill maintainer (me) | does my fleet skill set run on pi today? Punch list per skill. |
| S5 | `pi-native-redesign-roadmap` | C3 | skill maintainer (me) | per-skill verdict: keep-bash / port-to-extension / hybrid + effort estimate |
| S6 | `pi-open-questions` | all 13 (harvest "Open questions" sections) | next-experiment planner | aggregated unknowns → spawn follow-up research |

---

## Per-synthesis-doc structure

Every synthesis doc must include:

1. **One-paragraph TL;DR** (audience-tuned).
2. **Body** sized to its purpose:
   - S1: bulleted index, no prose.
   - S2: linear walkthrough, code snippets.
   - S3: named recipes with steps + when-to-use.
   - S4: table per skill (status / blockers / changes needed).
   - S5: table per skill (verdict / why / effort / dependencies).
   - S6: bucketed unknowns by topic.
3. **Source map**: every claim cites a worker finding by `NN-<slug>` + section.
4. **What this doc does NOT cover**: explicit pointer to the synthesis sibling that does.

The "what this does NOT cover" line is the anti-merge guard — keeps each doc focused, prevents drift toward a mega-doc.

---

## Synthesis ordering

S1 last (it indexes the others). The other 5 are independent → can be written in parallel by main agent (you), or even delegated to 5 sub-agents.

```
[fleet completes, 13 findings on disk]
            │
            ├──► S2 (beginner)        ─┐
            ├──► S3 (power workflows)   │  parallel
            ├──► S4 (portability)       │  (5 sub-agents OR 1 main)
            ├──► S5 (redesign)          │
            └──► S6 (open questions)  ─┘
                          │
                          ▼
                    S1 (index over S2-S6 + raw findings)
```

---

## Lossy-merge prohibitions

The following are **explicitly forbidden** during synthesis:

- ❌ Concatenating all 13 findings into one doc.
- ❌ Replacing a finding with its summary in a synthesis doc (always link).
- ❌ Dropping "gotchas" / "open questions" sections — these feed S6.
- ❌ Smoothing out contradictions between workers — surface them in S6.
- ❌ Compressing tables to prose. Tables stay tables.

---

## Updates to plans 02 and 03 (delta only)

- Plan 02 "Synthesis phase (post-fleet)" — **replaced** by this plan.
- Plan 03 "Updated synthesis (post-fleet)" — **replaced** by this plan.
- Plan 02's outputs 1-4 → mapped to S1, S2, S3, S6 here.
- Plan 03's outputs 5-6 → mapped to S4, S5 here.

No worker briefs, source partitions, or fleet shape change.

---

## Updated decision points (delta only)

10. **Synthesis as fleet or solo?** Run S2-S6 as a 5-worker follow-up fleet, or main agent writes them after the 13-worker fleet completes? (Solo cheaper but slower; fleet faster but adds coordination.)
11. **S6 harvest mechanism**: each worker tags "Open questions" in standard heading so harvest is mechanical — confirm worker briefs enforce this heading.

---

## Next

Confirm 6-output synthesis spec → ready to launch `/fleet-plan` against plans 02 + 03 + 04 as the canonical plan set.
