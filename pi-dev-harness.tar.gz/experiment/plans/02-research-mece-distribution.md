---
title: "research-mece-distribution"
experiment: 004-pi-dev-harness
created: "2026-04-25 09:37 UTC"
---

# pi.dev Research Plan — MECE Distribution for /fleet-plan

Goal: produce **comprehensive, actionable knowledge of pi.dev** covering (a) beginner foundations and (b) power-user workflows. Designed so sub-agents work **in parallel without overlap**. Each track = one worker. Each worker has a fixed scope, fixed sources, fixed deliverable.

---

## MECE design principles

- **Mutually exclusive**: each track owns a disjoint slice of the source space. No two workers read the same primary file.
- **Collectively exhaustive**: union of tracks = full coverage of pi.dev surface (foundations + power use).
- **Self-contained brief**: each track section below = a complete prompt for one sub-agent. Worker should not need clarification.
- **Same output schema**: every worker writes one finding under `experiments/004-pi-dev-harness/findings/` using the standard template (see "Output contract" below).

---

## Track index (10 workers, 2 buckets)

### Bucket A — Foundations (beginner-facing, building blocks)

| # | Track | Owns | Deliverable |
|---|-------|------|-------------|
| A1 | Install + first-run | install paths, AGENTS.md, SYSTEM.md, config files, env vars | `finding: pi-bootstrap` |
| A2 | Core tools deep-dive | Read / Write / Edit / Bash semantics, diffs vs Claude Code tools | `finding: pi-core-tools` |
| A3 | Run modes | TUI, print/JSON, RPC, SDK — when to use which, wire formats | `finding: pi-run-modes` |
| A4 | Provider layer | 15+ providers, `/model` swap, cost/token tracking, normalization | `finding: pi-providers` |
| A5 | Session model | session-as-tree, `/tree`, branching, persistence, resume semantics | `finding: pi-sessions` |

### Bucket B — Power use (advanced, ecosystem, workflows)

| # | Track | Owns | Deliverable |
|---|-------|------|-------------|
| B1 | Extension system internals | hook lifecycle (25+ hooks), TS API, hot-reload, packaging | `finding: pi-extensions` |
| B2 | Skills + prompts + themes | composability, discovery, namespacing, distribution | `finding: pi-skills-prompts` |
| B3 | Ecosystem catalog | published packages, notable forks (`oh-my-pi`), npm/github scan | `finding: pi-ecosystem` |
| B4 | Power users + workflows | who uses pi seriously, blog posts, talks, tweets, repos showcasing real use | `finding: pi-power-users` |
| B5 | Comparison & positioning | vs Claude Code, Cursor, aider, codex — strengths, gaps, lock-in | `finding: pi-comparison` |

---

## MECE source partition (no worker reads another's source)

| Worker | Primary sources (exclusive) |
|---|---|
| A1 | `pi-mono/packages/coding-agent/README.md`, `pi-mono/packages/coding-agent/src/cli.ts` (or entry), `pi.dev/` landing page, install docs |
| A2 | `pi-mono/packages/coding-agent/src/tools/` directory (read.ts, write.ts, edit.ts, bash.ts) |
| A3 | `pi-mono/packages/coding-agent/src/modes/` or equivalent (interactive, print, rpc, sdk dirs); RPC schema files |
| A4 | `pi-mono/packages/coding-agent/src/providers/` and `pi-mono/packages/api/` (unified LLM API) |
| A5 | `pi-mono/packages/coding-agent/src/session/` or sessions/state code; `/tree` command source |
| B1 | `pi-mono/packages/coding-agent/src/extensions/` + `hooks/`; extension example dir |
| B2 | `pi-mono/packages/coding-agent/src/skills/` + `prompts/` + `themes/`; example skills repos |
| B3 | npm registry search `@mariozechner/*`, `pi-extension`, `pi-skill`; github search `topic:pi-extension`; `oh-my-pi` repo |
| B4 | Mario's blog (`mariozechner.at`), dev.to posts, HN/Reddit/Twitter mentions, conference talks, YouTube |
| B5 | External reviews (`petronellatech.com`, `topai.tools`, `aitoolnet.com`, `aisoftwaresystems.com`, `tazlab.net`); Claude Code / aider / cursor docs for compare |

If a worker hits a source assigned to another, **stop and note it** in their finding's "cross-refs" section — do not duplicate work.

---

## Per-worker brief template

Every worker gets this exact structure. Replace `{TRACK}` fields.

```
You are researching pi.dev (badlogic/pi-mono) for track {TRACK_ID}: {TRACK_TITLE}.

Scope (your slice only): {SCOPE}
Sources you own (do not read others): {SOURCES}
Out of scope (other workers cover): {EXCLUSIONS}

Method:
1. Clone or git-fetch badlogic/pi-mono if not present at /tmp/pi-mono.
2. Read only the files in your source list. WebFetch only your assigned URLs.
3. Take notes in scratch, then write final finding.

Deliverable: ONE markdown file at
  docs/experiments/004-pi-dev-harness/findings/NN-{slug}.md
created via:
  bash /home/sagar/.claude/skills/doc/scripts/finding.sh 4 "{slug}"

Finding must include sections:
  - Summary (3 bullets)
  - Building blocks / concepts (named, defined)
  - Code refs (file:line for every claim)
  - Examples (minimal runnable snippets)
  - Gotchas / surprises
  - Open questions
  - Cross-refs (things you saw belonging to other tracks)

Budget: ~30 min. Stop when finding is complete + sourced.
```

---

## Output contract (uniform across workers)

Every finding = single `.md` file under `findings/`. Frontmatter auto-generated by `finding.sh`. Body sections **must match** the brief template above so the synthesis step can mechanically merge them.

Naming: `NN-pi-{track-slug}.md` where NN is auto-assigned by script.

---

## Synthesis phase (post-fleet)

After all 10 findings land:

1. **Merge** → one consolidated finding `pi-knowledge-base` that indexes all 10 with cross-links.
2. **Power-workflow recipes** → derive 3-5 concrete workflows (e.g. "headless code review via SDK + reviewer skill", "multi-provider cost optimization with `/model` mid-session", "fleet of pi workers via RPC").
3. **Beginner onboarding** → distill A1-A5 into a single "start here" doc.
4. **Gaps + next experiments** → list anything the fleet couldn't answer → spawn follow-up research.

Synthesis = main agent (you), not a fleet worker.

---

## Fleet config sketch (for /fleet-plan)

- **Fleet type**: `worktree-fleet` if any worker writes code (B1 hello-extension), else `dag-fleet` (read-only, no merge conflict risk).
- **Parallelism**: all 10 independent — fan out fully.
- **Model**: Sonnet 4.6 sufficient per worker; Opus only for B5 (comparison synthesis).
- **Budget per worker**: ~$0.50–$1 (reading + 1 finding). Fleet total ≤ $10.
- **Reviewer**: not needed (no iteration). Synthesis manual.
- **Inputs to each worker**: this file + their per-track brief block.

---

## Decision points before launch

1. **Confirm 10 tracks** — drop any? Add any (e.g. "security/sandbox", "telemetry")?
2. **Hands-on track?** A1 currently doc-only. Want a worker to actually install + smoke-test? (Adds 1 worker, needs worktree.)
3. **Code track for B1?** Should B1 also build a hello-extension as proof-of-extension? (Adds work, validates docs.)
4. **Scope of B4 (power users)** — only public material, or also reach out / DM? (Public only recommended.)
5. **Cost cap** — confirm ≤ $10 fleet budget.

---

## Next

User confirms tracks + answers decision points → run `/fleet-plan` pointing at this file → fleet-plan generates `fleet.json` + per-worker `prompt.md` files using the briefs above.
