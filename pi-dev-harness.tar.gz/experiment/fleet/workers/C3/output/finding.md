## Summary
- Recommended architecture split: `port-to-extension` for `fleet-plan`, `keep-bash` for `worktree-fleet`, and `hybrid` for `dag-fleet`, `iterative-fleet`, `autoresearch-fleet`, and `doc` (6/6 mapped with effort). (`/home/sagar/skills/skills/fleet-plan/SKILL.md:14`, `/home/sagar/skills/skills/worktree-fleet/SKILL.md:15`, `/home/sagar/skills/skills/iterative-fleet/SKILL.md:15`, `/home/sagar/skills/skills/autoresearch-fleet/SKILL.md:28`, `/home/sagar/skills/skills/doc/SKILL.md:14`)
- The strongest pi-native leverage is extension control + resource discovery (`resources_discover`, command context APIs, runtime tool gating), while long-lived multi-worker orchestration remains better outside the agent process. (`/tmp/pi-mono/packages/coding-agent/docs/extensions.md:334`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:331`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:1074`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/runner.ts:676`)
- C2/B1/B2/C1 dependencies align: pi already provides headless JSON/RPC/session/model primitives, but fleet scripts still assume provider-specific event/cost envelopes, so an adapter layer is required before deeper rewrites. (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C2/output/finding.md:2`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C2/output/finding.md:11`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C1/output/finding.md:4`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/B1/output/finding.md:3`)

## Building blocks / concepts
`Execution plane (RPC/JSON runner adapter)`
A thin process adapter that normalizes `pi --mode json`/`pi --mode rpc` events to fleet’s terminal/cost schema and abstracts session/model/tool switches. (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C2/output/finding.md:9`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C2/output/finding.md:18`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:56`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:69`)

`Control plane (extension commands + event hooks)`
Use `registerCommand`, `tool_call`/`tool_result`, and session/tree hooks for gating, policy, and iteration control that currently lives in shell conditionals. (`/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:1107`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:1126`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:331`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:430`)

`Resource plane (skills/prompts/themes as packages)`
Use `resources_discover` and package-distributed `skills/` + `prompts/` to ship planning/documentation behavior natively, instead of only shell script entry points. (`/tmp/pi-mono/packages/coding-agent/docs/extensions.md:334`, `/tmp/pi-mono/packages/coding-agent/examples/extensions/dynamic-resources/index.ts:8`, `/tmp/pi-mono/packages/coding-agent/docs/skills.md:24`, `/tmp/pi-mono/packages/coding-agent/docs/prompt-templates.md:9`)

`Session-tree state model`
Leverage `fork`/`switchSession`/`navigateTree` and persisted custom entries to replace some iterative directory bookkeeping with first-class branch-aware state. (`/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:343`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:349`, `/tmp/pi-mono/packages/coding-agent/examples/extensions/todo.ts:118`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:1016`)

`Maintainer philosophy constraint`
pi intentionally keeps core minimal (“no built-in subagents/plan/todo”), so redesign should prefer optional extension packages, not core changes. (`https://mariozechner.at/posts/2025-11-30-pi-coding-agent/`, `https://mariozechner.at/posts/2025-12-22-year-in-review-2025/`)

## Code refs
| Skill | Proposed pi-native architecture | Verdict | Effort |
|---|---|---|---|
| `dag-fleet` | Keep tmux+DAG orchestration, replace provider-specific runner internals with a `pi` adapter (`--mode rpc` preferred) that normalizes terminal/cost/session events and model/tool controls. Keep operator-owned kill/relaunch flow unchanged. (`/home/sagar/skills/skills/dag-fleet/SKILL.md:15`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C1/output/finding.md:2`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C2/output/finding.md:9`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:56`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:558`) | `hybrid` | 1.5-2.5 weeks |
| `worktree-fleet` | Keep bash-first worktree lifecycle and merge workflow; only add `provider=pi` in spawn path. Git worktree creation, branch isolation, and merge planning stay external. (`/home/sagar/skills/skills/worktree-fleet/SKILL.md:15`, `/home/sagar/skills/skills/worktree-fleet/SKILL.md:91`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C1/output/finding.md:29`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:2463`) | `keep-bash` | 3-5 days |
| `iterative-fleet` | Keep external iteration DAG orchestrator, but move reviewer gate semantics into an extension package: `turn_end`/`agent_end` verdict synthesis helpers, session-aware checkpoints, and command-driven pause/resume hooks. (`/home/sagar/skills/skills/iterative-fleet/SKILL.md:15`, `/home/sagar/skills/skills/iterative-fleet/SKILL.md:105`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:1099`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:1097`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:940`) | `hybrid` | 2-3 weeks |
| `autoresearch-fleet` | Keep external endless loop + stop-condition enforcement, but add extensionized plateau/search policy and structured metrics capture from usage/session stats to reduce brittle shell parsing and string mutation. (`/home/sagar/skills/skills/autoresearch-fleet/SKILL.md:17`, `/home/sagar/skills/skills/autoresearch-fleet/SKILL.md:220`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C1/output/finding.md:20`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C2/output/finding.md:11`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:1107`) | `hybrid` | 2-3 weeks |
| `fleet-plan` | Port to pi extension package: register `/fleet-plan` command, expose fleet templates via resources (`resources_discover`), surface prompt templates for common fleet archetypes, and optionally expose a planning tool for LLM invocation. (`/home/sagar/skills/skills/fleet-plan/SKILL.md:16`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:1126`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:334`, `/tmp/pi-mono/packages/coding-agent/examples/extensions/dynamic-resources/index.ts:8`, `/tmp/pi-mono/packages/coding-agent/docs/prompt-templates.md:5`) | `port-to-extension` | 1-1.5 weeks |
| `doc` | Keep existing scripts as deterministic file/index backend, add extension+prompt layer for native `/doc-*` commands, template discovery, and session-tree-aware checkpoint helpers. (`/home/sagar/skills/skills/doc/SKILL.md:14`, `/home/sagar/skills/skills/doc/SKILL.md:73`, `/tmp/pi-mono/packages/coding-agent/docs/prompt-templates.md:5`, `/tmp/pi-mono/packages/coding-agent/src/core/resource-loader.ts:487`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:349`) | `hybrid` | 1-2 weeks |

Additional architectural anchors:
- Hooks-to-extensions migration signal: `oh-my-pi` still documents separate hooks path and `.omp` layout, while upstream examples/docs are extension-centric. (`/tmp/oh-my-pi/packages/coding-agent/examples/hooks/README.md:1`, `/tmp/oh-my-pi/packages/coding-agent/examples/extensions/README.md:12`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:7`)
- Existing first-party “complex extension” patterns already mirror fleet-like behavior (plan mode, subagent spawning, tool presets, dynamic resources). (`/tmp/pi-mono/packages/coding-agent/docs/extensions.md:2522`, `/tmp/pi-mono/packages/coding-agent/examples/extensions/subagent/index.ts:265`, `/tmp/pi-mono/packages/coding-agent/examples/extensions/plan-mode/index.ts:99`, `/tmp/pi-mono/packages/coding-agent/examples/extensions/preset.ts:113`)

## Examples
```bash
# Hybrid runner pattern for dag/worktree/iterative/autoresearch:
# keep shell orchestrator, swap provider adapter to pi RPC
pi --mode rpc
# then send JSONL commands: prompt, get_session_stats, switch_session, set_model
```
Source: `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C2/output/finding.md:48`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:56`.

```ts
// Port-to-extension pattern for fleet-plan/doc resources
import type { ExtensionAPI } from "@mariozechner/pi-coding-agent";
import { join } from "node:path";

export default function (pi: ExtensionAPI) {
  pi.registerCommand("fleet-plan", { description: "Generate fleet files", handler: async () => {} });
  pi.on("resources_discover", () => ({
    skillPaths: [join(process.cwd(), ".pi/skills/fleet-plan/SKILL.md")],
    promptPaths: [join(process.cwd(), ".pi/prompts/fleet-plan.md")],
  }));
}
```
Source pattern: `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:1126`, `/tmp/pi-mono/packages/coding-agent/examples/extensions/dynamic-resources/index.ts:8`.

```ts
// Iterative/doc state in session tree instead of ad-hoc files
pi.on("session_tree", async (_event, ctx) => {
  // restore branch-local state from custom/tool entries
});
```
Source: `/tmp/pi-mono/packages/coding-agent/examples/extensions/todo.ts:133`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:430`.

## Gotchas / surprises
- Source-slice path mismatch: prompt says `src/extensions|hooks|skills`, but upstream code has `src/core/extensions` + `src/core/skills.ts`; direct `src/extensions` does not exist in this checkout. (`/tmp/pi-mono/packages/coding-agent/src:1`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:1`, `/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:1`)
- pi docs/examples support advanced extensionized features (plan-mode, subagent, todo), while maintainer messaging rejects built-in versions; redesign should package features externally, not target core merges. (`https://mariozechner.at/posts/2025-11-30-pi-coding-agent/`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:2522`, `/tmp/pi-mono/packages/coding-agent/examples/extensions/subagent/README.md:7`)
- `tool_call` can mutate arguments without post-mutation validation; policy extensions can accidentally create unsafe argument drift. (`/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:810`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:652`)
- Command-context lifecycle is footgun-prone: post `newSession/fork/switchSession/reload`, captured old context is stale and can throw. (`/tmp/pi-mono/packages/coding-agent/src/core/extensions/loader.ts:167`, `/tmp/pi-mono/packages/coding-agent/docs/extensions.md:1083`)
- C2 portability gap still matters: no first-class CLI cwd flag equivalent to codex `--cd`; heavy fleet cwd routing should prefer RPC embedding/adapter. (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C2/output/finding.md:13`)
- Upstream naming/governance changed on April 8, 2026 (repo/package move to Earendil namespace), which can break hardcoded package references in port plans. (`https://mariozechner.at/posts/2026-04-08-ive-sold-out/`)

## Open questions
- Should the first migration milestone be “`provider=pi` adapter only” across all fleet launchers before any extension-native control-plane work? (lowest risk, highest immediate leverage) (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C1/output/finding.md:87`)
- Can reviewer verdicting for `iterative-fleet` be made branch-native with session entries, or is file-based `iterations/N/review.md` required for operator auditability? (`/home/sagar/skills/skills/iterative-fleet/SKILL.md:105`, `/tmp/pi-mono/packages/coding-agent/examples/extensions/todo.ts:118`)
- For `doc`, is script-level numbering still required after extensionization, or can session-tree IDs become the canonical sequence key? (`/home/sagar/skills/skills/doc/SKILL.md:124`, `/tmp/pi-mono/packages/coding-agent/src/core/extensions/types.ts:349`)
- Source health self-critique: C3’s assigned source slice is intentionally narrow and could not credibly reach 30+ web domains without violating MECE boundaries; breadth is concentrated in primary code sources instead. (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/05-fleet-config-and-targets.md:69`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C3/prompt.md:11`)

## Cross-refs
- C1 owns full call-site portability audit and exact shell flag inventory; I used it as a dependency but did not replicate call-site enumeration. (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C1/output/finding.md:23`)
- C2 owns definitive CLI/RPC flag mapping and event-envelope certainty for parser implementation details. (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/C2/output/finding.md:6`)
- B1 owns extension runtime internals (hot-reload semantics, interception architecture); C3 uses those internals only for architecture choices. (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/B1/output/finding.md:14`)
- B2 owns skills/prompt/theme semantics and collision behavior; C3 consumes that for `fleet-plan`/`doc` packaging recommendations. (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/B2/output/finding.md:7`, `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/B2/output/finding.md:17`)
