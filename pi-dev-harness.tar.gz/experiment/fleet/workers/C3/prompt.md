# Worker C3 — pi-native fleet redesign

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

For each of my 5 fleet skills + doc skill, propose a pi-native architecture. Verdict per skill: keep-bash / port-to-extension / hybrid + effort estimate.

Depends on C2 (CLI map) + B1 (extension internals) + B2 (skills format) — read their findings first from $FLEET_ROOT/workers/{C2,B1,B2}/output/finding.md.

## Sources you own (do not touch others')

- pi-mono/packages/coding-agent/src/extensions/, hooks/, skills/
- oh-my-pi (for redesign inspiration)
- mariozechner.at posts on extension patterns
- Findings from C2, B1, B2 (upstream deps)

## Out of scope (other workers cover)

- Portability call-site audit (C1)

## Source-mix target (per plan 05)

50% pi extension API source, 30% existing pi extensions, 20% my fleet skills (cross-ref via C1's finding if available). Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/C3/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/C3/output/` — use absolute paths.
