## Summary
- Sessions are append-only JSONL trees (`id`/`parentId`) with a mutable `leafId`; branching is pointer movement, not history rewrite (`/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:658`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1125`).
- `/tree` is in-session branch navigation: interactive mode opens a selector, optionally summarizes the abandoned path, then rewrites active context from `buildSessionContext()` (`/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:4159`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2668`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2828`).
- Resume semantics are runtime replacement semantics: `--resume` selects a session file, `switchSession()` tears down old runtime, loads target session/cwd, emits switch lifecycle events, and rebinds (`/tmp/pi-mono/packages/coding-agent/src/main.ts:263`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:175`, `/tmp/pi-mono/packages/coding-agent/test/agent-session-runtime-events.test.ts:92`).

## Building blocks / concepts
- Session tree: each non-header entry is a node; `leafId` defines active branch head (`/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:44`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:680`).
- Context projection: model input is not “all entries”; it is root→leaf path transformed by `buildSessionContext()` with compaction/branch-summary handling (`/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:315`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:390`).
- `/tree` navigation contract: selecting a prior user/custom message rewinds leaf to its parent and pre-fills editor text; selecting non-user nodes sets leaf to selected node (`/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2783`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2798`).
- Branch summarization: `collectEntriesForBranchSummary()` walks old leaf back to common ancestor; summary is appended as `branch_summary` via `branchWithSummary()` at the target position (`/tmp/pi-mono/packages/coding-agent/src/core/compaction/branch-summarization.ts:98`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2805`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1146`).
- Fork/clone vs tree: `fork/createBranchedSession()` creates a new session file and session header lineage (`parentSession`), while `/tree` remains in the current file (`/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:234`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1170`, `/tmp/pi-mono/packages/coding-agent/docs/tree.md:14`).
- Resume lifecycle: `session_before_switch` can cancel; successful switch emits shutdown/start around runtime replacement (`/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:115`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:179`, `/tmp/pi-mono/packages/coding-agent/test/suite/agent-session-runtime.test.ts:123`).

## Code refs
- Tree persistence model and append-only behavior: `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:658`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1063`.
- Branch operations: `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1125`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1146`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1170`.
- Session-file lineage via `parentSession`: `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:739`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1191`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1345`.
- `/tree` command dispatch and UI flow: `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:2548`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:4159`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:4239`.
- Tree selector ordering and active-branch prioritization: `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/components/tree-selector.ts:156`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/components/tree-selector.ts:216`.
- Navigation semantics in `navigateTree`: `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2672`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2783`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2805`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2828`.
- Branch summary collection/budgeting: `/tmp/pi-mono/packages/coding-agent/src/core/compaction/branch-summarization.ts:98`, `/tmp/pi-mono/packages/coding-agent/src/core/compaction/branch-summarization.ts:185`, `/tmp/pi-mono/packages/coding-agent/src/core/compaction/branch-summarization.ts:289`.
- CLI resume path: `/tmp/pi-mono/packages/coding-agent/src/cli/args.ts:81`, `/tmp/pi-mono/packages/coding-agent/src/main.ts:263`, `/tmp/pi-mono/packages/coding-agent/src/cli/session-picker.ts:13`.
- Runtime resume switch path: `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:175`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:187`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:193`.
- Missing cwd guard on resume: `/tmp/pi-mono/packages/coding-agent/src/core/session-cwd.ts:14`, `/tmp/pi-mono/packages/coding-agent/src/core/session-cwd.ts:54`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:4343`.
- Session selector threaded parent/child matching: `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/components/session-selector.ts:211`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/components/session-selector.ts:224`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/components/session-selector.ts:226`.
- Validation tests for tree/branch behavior: `/tmp/pi-mono/packages/coding-agent/test/session-manager/tree-traversal.test.ts:192`, `/tmp/pi-mono/packages/coding-agent/test/session-manager/tree-traversal.test.ts:314`, `/tmp/pi-mono/packages/coding-agent/test/agent-session-tree-navigation.test.ts:78`.
- Validation tests for resume/switch events: `/tmp/pi-mono/packages/coding-agent/test/agent-session-runtime-events.test.ts:92`, `/tmp/pi-mono/packages/coding-agent/test/suite/agent-session-runtime.test.ts:168`.

## Examples
```ts
import { SessionManager } from "@mariozechner/pi-coding-agent";

const sm = SessionManager.inMemory();
const u1 = sm.appendMessage({ role: "user", content: [{ type: "text", text: "A" }], timestamp: Date.now() } as any);
sm.appendMessage({ role: "assistant", content: [{ type: "text", text: "B" }], timestamp: Date.now(), api: "x", provider: "x", model: "x", usage: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, totalTokens: 0, cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0, total: 0 } }, stopReason: "stop" } as any);

sm.branch(u1);                 // move leaf to earlier point
sm.appendMessage({ role: "user", content: [{ type: "text", text: "A2" }], timestamp: Date.now() } as any);
console.log(sm.getTree().length); // same session file/tree, new sibling branch
```
Cites: `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1125`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:1075`.

```ts
// runtimeHost.switchSession(sessionPath) semantics (simplified)
const before = await runtimeHost.switchSession(targetPath);
if (!before.cancelled) {
  // old session was shut down, new session runtime rebound
  // session_start(reason: "resume") already emitted
}
```
Cites: `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:179`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:187`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:196`.

## Gotchas / surprises
- `navigateTree()` currently clears `_branchSummaryAbortController` at normal function end, so early returns on cancel paths can leave `isCompacting` true; this matches open bug [#3688](https://github.com/badlogic/pi-mono/issues/3688) and code shape around controller lifetime (`/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2713`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2726`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2842`).
- Reported behavior mismatch between `/tree` state and later `/resume` restoration of model/thinking in [#3544](https://github.com/badlogic/pi-mono/issues/3544); this aligns with tree navigation rewriting message path but not necessarily restoring every runtime knob the same way users expect (`/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2828`).
- `--continue` cwd handling was explicitly called out in [#3249](https://github.com/badlogic/pi-mono/issues/3249); this is high-risk for cross-project resumed sessions because services/tools bind to cwd (`/tmp/pi-mono/packages/coding-agent/src/main.ts:281`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:190`).
- Fork bugs historically included “new child file created but parent still active” ([#1242](https://github.com/badlogic/pi-mono/issues/1242)); current code now explicitly replaces runtime/session manager during fork (`/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:284`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:299`).
- Session tree presentation in `/resume` depends on path canonicalization; symlinked session roots broke parent/child linking until fixes discussed in [#3364](https://github.com/badlogic/pi-mono/issues/3364) (`/tmp/pi-mono/packages/coding-agent/src/modes/interactive/components/session-selector.ts:50`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/components/session-selector.ts:224`).
- Self-critique: docs appear to lag current names in places (`getLeafUuid()` shown in docs, runtime uses `getLeafId()`), so code should be considered canonical over docs (`/tmp/pi-mono/packages/coding-agent/docs/tree.md:156`, `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts:969`).

## Open questions
- Health-target tension: this MECE slice is intentionally narrow (session/tree code + tree/resume issues), so reaching 30 truly independent web domains is not realistic without violating source partition.
- Should `/tree` and `/resume` share one authoritative “state restore” function for model/thinking restoration semantics (the user-facing inconsistency in [#3544](https://github.com/badlogic/pi-mono/issues/3544) suggests drift)?
- Should `_branchSummaryAbortController` lifecycle be wrapped in `try/finally` in `navigateTree()` (as proposed in [#3688](https://github.com/badlogic/pi-mono/issues/3688)) to guarantee cleanup on all returns?
- Is `SessionManager.continueRecent(cwd, ...)` expected to favor session-header cwd over launch cwd in all modes, including non-interactive and RPC (related to [#3249](https://github.com/badlogic/pi-mono/issues/3249))?
- Should `/resume` threaded mode expose stronger diagnostics when parent links fail canonical matching (related to [#3364](https://github.com/badlogic/pi-mono/issues/3364))?

## Cross-refs
- Provider/model-thinking semantics touched by tree/resume restoration are primarily Provider track concerns (A4), not expanded here.
- Extension lifecycle and stale-context guardrails surfaced by session replacement are extension-internals work (B1), especially around `withSession` and stale ctx behavior ([#2860](https://github.com/badlogic/pi-mono/issues/2860)).
- Prompt/skill behavior during reload/resume is primarily Skills/Prompts track (B2), only referenced as side effects of session replacement.
