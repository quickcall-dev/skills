# Worker A5 — session model (tree, /tree, branching)

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Sessions stored as trees, /tree to branch from any prior point, persistence format, resume semantics.

## Sources you own (do not touch others')

- `pi-mono/packages/coding-agent/src/session/` (or sessions/state code)
- `/tree` command source
- Issue threads about tree/resume

## Out of scope (other workers cover)

- Providers (A4)
- Extensions (B1)
- Skills/prompts (B2)

## Source-mix target (per plan 05)

80% source code, 20% issue threads on tree/resume. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/A5/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/A5/output/` — use absolute paths.
