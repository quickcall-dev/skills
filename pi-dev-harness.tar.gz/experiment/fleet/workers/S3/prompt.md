# Worker S3 — power workflow recipes (synthesis)

You are a synthesis worker. Inputs = upstream worker findings on disk. Output = one synthesis doc + sibling pointers.

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/04-synthesis-multi-doc.md` — it defines the lossless-merge contract you MUST follow.

## Input findings (read these — verbatim from worker output)

- $FLEET_ROOT/workers/B1/output/finding.md (extensions)
- $FLEET_ROOT/workers/B2/output/finding.md (skills/prompts/themes)
- $FLEET_ROOT/workers/B3/output/finding.md (ecosystem)
- $FLEET_ROOT/workers/B4/output/finding.md (power users)
- $FLEET_ROOT/workers/B5/output/finding.md (comparison)

Also read each input's sibling `sources.md` to understand exploration breadth (helps you weigh confidence).

## Audience

Power user who already knows the basics. Wants named, repeatable workflows.

## Required structure

3-5 named recipes, each with:
- Name + 1-line use case
- Building blocks used (cite to B*)
- Step-by-step
- When to use / when NOT to
- Variants observed in the wild (from B4)
Examples to consider: 'headless review via SDK + reviewer skill', 'multi-provider cost optimization with /model mid-session', 'fleet of pi workers via RPC', 'extension-driven test-gen pipeline', 'session-tree branching for A/B prompt testing'.

## Mandatory rules (per plan 04)

- NO concatenation. Link to source findings, do not paste.
- NO replacing a finding with its summary inline — link instead.
- NO dropping "Open questions" / "Gotchas" — those feed sibling synth doc S6.
- NO smoothing contradictions. Surface them with a "Contradictions" subsection.
- Tables stay tables.
- End with: "## What this doc does NOT cover" — point to sibling synth docs (S1-S6) that handle the excluded scope.

## Citation form

Cite worker findings as `[A2#Building blocks](../../A2/output/finding.md#building-blocks--concepts)` — relative paths from your output dir.

## Health targets (synth-tier)

- 100% finding coverage (every relevant input cited or explicitly excluded with reason)
- ≥3 cross-finding contradictions surfaced (or "no contradictions found, here's why")
- ≥5 actionable items (S4/S5 only)
- 0 lossy summaries

## Deliverable

`$FLEET_ROOT/workers/S3/output/synthesis.md`

Save ALL output files to `$FLEET_ROOT/workers/S3/output/` — use absolute paths.
