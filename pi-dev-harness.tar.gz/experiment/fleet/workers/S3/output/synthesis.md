---
name: pi-power-workflow-recipes
audience: power user (knows pi basics, wants named workflows)
sources: B1, B2, B3, B4, B5
synthesis_tier: S3
created: "2026-04-25"
---

# pi-power-workflow-recipes

## TL;DR

Five named, repeatable workflows for pi power users, grounded in observed extension internals, skill/prompt mechanics, ecosystem packages, real adopter patterns, and competitor positioning. Each recipe links back to source findings — no inline summaries of upstream work. Recipes favor the **minimal-core + userland** posture maintainers and adopters actually use ([B4#summary](../../B4/output/finding.md#summary)), not the marketing surface.

---

## Recipe 1 — Preflight Policy Gate (block destructive tool calls)

**Use case**: enforce repo-wide bash/edit policy without forking core. Every dangerous command runs through a tool_call handler that can mutate args or block.

**Building blocks**:
- `tool_call` interception, mutable input, block-with-reason — see [B1#building-blocks--concepts](../../B1/output/finding.md#building-blocks--concepts) and [B1 example 2](../../B1/output/finding.md#examples).
- Agent-level hook install at `AgentSession._installAgentToolHooks()` — [B1#code-refs](../../B1/output/finding.md#code-refs).
- Permission-gate pattern observed in `rytswd/pi-agent-extensions` — [B4#code-refs](../../B4/output/finding.md#code-refs) (`README.org:166`,`:175`,`:181`).

**Steps**:
1. Scaffold extension factory exporting default `(pi: ExtensionAPI) => …`.
2. Register `pi.on("tool_call", …)`; for `bash`, inspect `event.input.command` against deny regex.
3. Return `{ block: true, reason }` to short-circuit; or mutate `event.input` to rewrite (note: no re-validation after mutation, [B1#gotchas--surprises](../../B1/output/finding.md#gotchas--surprises)).
4. Drop in user/project extension dir or ship as npm package per [B2#examples](../../B2/output/finding.md#examples).

**When to use**: regulated repos, shared dev box, CI agents where YOLO default ([B4#summary](../../B4/output/finding.md#summary)) is unacceptable.
**When NOT**: solo throwaway prototyping — overhead of policy authoring outweighs risk.

**Variants in the wild**:
- External sandbox wrapper (`bwrap`, container) instead of in-process gate — [B4#examples](../../B4/output/finding.md#examples).
- Tool-name override (`registerTool({name:"read"})` shadows core) — [B1#gotchas--surprises](../../B1/output/finding.md#gotchas--surprises).

---

## Recipe 2 — Embedded pi-SDK Runtime with Domain Tool Injection

**Use case**: ship a product that *uses* pi as its agent runtime (not CLI). OpenClaw is the canonical public example.

**Building blocks**:
- Direct `pi-coding-agent` SDK consumption, custom tool injection, session lifecycle control — [B4#code-refs](../../B4/output/finding.md#code-refs) (`openclaw/docs/pi.md:13`–`:250`).
- First-party packages `@mariozechner/pi-agent-core`, `pi-coding-agent`, `pi-ai`, `pi-tui` — [B3#building-blocks--concepts](../../B3/output/finding.md#building-blocks--concepts).
- `ExtensionRuntime` with throwing action stubs until runner binding (prevents action calls during load) — [B1#building-blocks--concepts](../../B1/output/finding.md#building-blocks--concepts).

**Steps**:
1. Add `@mariozechner/pi-agent-core` + `pi-coding-agent` as deps.
2. Compose host process: instantiate `AgentSession`, register domain tools via `defineTool`, inject channel-specific context.
3. Drive lifecycle (start/shutdown/reload) explicitly; do NOT call action methods during factory load — [B1#gotchas--surprises](../../B1/output/finding.md#gotchas--surprises).
4. Treat `session_start` reason `"reload"` as the resync signal for resource discovery — [B1#summary](../../B1/output/finding.md#summary).

**When to use**: vertical SaaS, in-product agents, anything where shelling out to `pi` CLI breaks UX or auth model.
**When NOT**: bench scripts and one-off automations — Recipe 3's subprocess pattern is lower-effort.

**Variants in the wild**:
- Wrapper namespaces `@oh-my-pi/pi-coding-agent`, `@helios-agent/pi-web-ui`, `@rumisle/pi-web-ui` — [B3#gotchas--surprises](../../B3/output/finding.md#gotchas--surprises).
- Vendored fork (`pi-mono` clone) for governance autonomy — [B4#code-refs](../../B4/output/finding.md#code-refs) (Earendil notes).

---

## Recipe 3 — Subprocess Subagent Fan-out (parallel pi -p workers)

**Use case**: parallelize research/refactor/review across many isolated context windows from a single parent session.

**Building blocks**:
- First-party `examples/extensions/subagent` spawns `pi --mode json -p --no-session` subprocesses — [B1#building-blocks--concepts](../../B1/output/finding.md#building-blocks--concepts) (`subagent/index.ts:12`,`:265`).
- Headless competitor parity: `codex exec`, `aider --message`, `claude -p` — [B5#examples](../../B5/output/finding.md#examples).
- Community recreations of "agent orchestration in userland" despite no built-in subagents — [B4#gotchas--surprises](../../B4/output/finding.md#gotchas--surprises) (Contradiction 3).

**Steps**:
1. From parent extension/tool, fork `pi --mode json -p --no-session "$task"` per shard.
2. Read JSON-mode events from stdout; aggregate results in parent.
3. Use `--no-session` to avoid session-tree pollution; explicit JSON mode keeps output machine-parseable.
4. Optionally route to different providers per shard (cost vs. capability mix) — see [B5#building-blocks--concepts](../../B5/output/finding.md#building-blocks--concepts) (`Customization ceiling`).

**When to use**: large codebase audits, multi-file refactors, A/B prompt tests where context isolation matters.
**When NOT**: single-file tight loops — overhead of N processes dominates.

**Variants in the wild**:
- Embedded SDK fan-out (Recipe 2 + this) for tighter coupling — [B4#code-refs](../../B4/output/finding.md#code-refs).
- Wrappers `rynfar/meridian`, `mikeyobrien/rho` as long-running harnesses — [B3#code-refs](../../B3/output/finding.md#code-refs).

---

## Recipe 4 — Cross-Harness Skill Portability (one skill dir, three agents)

**Use case**: reuse the same skill library across pi, Claude Code, and Codex without duplicating files.

**Building blocks**:
- pi `settings.json` accepts `~/.claude/skills` and `~/.codex/skills` directly — [B2#examples](../../B2/output/finding.md#examples), [B2#summary](../../B2/output/finding.md#summary).
- Skill discovery is recursive on `SKILL.md`; missing `description` = hard skip, name violations = warning — [B2#gotchas--surprises](../../B2/output/finding.md#gotchas--surprises).
- Collision precedence project > user > package, regression-locked — [B2#code-refs](../../B2/output/finding.md#code-refs) (`2781-skill-collision-precedence.test.ts:61`).

**Steps**:
1. Single source of truth: keep skills under `~/.claude/skills/` (Claude's canonical path).
2. Wire pi: `{"skills": ["~/.claude/skills", "~/.codex/skills"]}`.
3. For Claude-only frontmatter (`context`, `agent`, `hooks`, `paths`) document explicit no-op behavior on pi — parity is unmapped, see [B2#open-questions](../../B2/output/finding.md#open-questions).
4. For shared distribution: publish as npm package using `pi.skills`/`pi.prompts`/`pi.themes` manifest — [B2#examples](../../B2/output/finding.md#examples).

**When to use**: multi-harness teams, polyglot workflows, vendor-agnostic skill libraries.
**When NOT**: when you need plugin-namespaced collision avoidance (Claude's `plugin-name:skill-name`) — pi only does first-wins+diagnostics, [B2#gotchas--surprises](../../B2/output/finding.md#gotchas--surprises).

**Variants in the wild**:
- Skill packs published to npm: `pi-skill-martin-fowler`, `@tmustier/pi-skill-creator`, `@ifi/oh-pi-skills` — [B3#building-blocks--concepts](../../B3/output/finding.md#building-blocks--concepts).
- Mixed quality: many `pi-package`-keyword repos point to demos — [B2#open-questions](../../B2/output/finding.md#open-questions).

---

## Recipe 5 — Profile-Driven Extension Pack with Hot Reload

**Use case**: switch entire toolset between workflow modes (security audit / refactor / docgen) without restarting pi.

**Building blocks**:
- `/reload` UX guardrails (no overlap with stream/compaction) and runtime refresh — [B1#code-refs](../../B1/output/finding.md#code-refs) (`interactive-mode.ts:4745`–`:4808`).
- Reload = full runtime replacement: `session_shutdown` → reload resources → rebuild registry → `session_start{reason:"reload"}` → `resources_discover` — [B1#summary](../../B1/output/finding.md#summary).
- Package-level enable/disable per workflow — [B4#code-refs](../../B4/output/finding.md#code-refs) (`pi-agent-extensions/README.org:18`,`:33`,`:39`).
- `registerCommand("reload-runtime", { handler: (_a, ctx) => ctx.reload() })` is the canonical entrypoint — [B1#examples](../../B1/output/finding.md#examples).

**Steps**:
1. Author N profile dirs (e.g., `~/.pi/profiles/audit/extensions/`).
2. Symlink active profile to `~/.pi/agent/extensions/` or update `settings.json.packages` per [B4#examples](../../B4/output/finding.md#examples).
3. Trigger `/reload` (or `ctx.reload()` from a command) — observe `resources_discover` repopulates skills/prompts/themes.
4. Mind: post-`await ctx.reload()` code in the calling handler still runs in the *old* call frame — [B1#gotchas--surprises](../../B1/output/finding.md#gotchas--surprises).

**When to use**: long-lived sessions, repeated context switches, extension authors iterating on factory code.
**When NOT**: any flow requiring guaranteed handler-frame migration mid-reload (currently unsupported).

**Variants in the wild**:
- Repo-local `AGENTS.md` as workflow steering surfaced often — [B4#building-blocks--concepts](../../B4/output/finding.md#building-blocks--concepts), [B4#code-refs](../../B4/output/finding.md#code-refs).
- Settings-pinned `packages` array as poor-man's profile — [B4#examples](../../B4/output/finding.md#examples).

---

## Contradictions across findings

| # | Tension | Sources |
|---|---|---|
| 1 | Maintainer says "no built-in subagents/plan mode" — yet first-party subagent example + heavy userland orchestration exist. Distinction is core-vs-extension, not capability. | [B1#gotchas--surprises](../../B1/output/finding.md#gotchas--surprises), [B4#gotchas--surprises](../../B4/output/finding.md#gotchas--surprises) (Contradiction 3) |
| 2 | "Minimal harness" ideology vs. observed sprawling ecosystem (pi-extension topic 148 repos, pi-coding-agent topic 150). | [B3#summary](../../B3/output/finding.md#summary), [B4#gotchas--surprises](../../B4/output/finding.md#gotchas--surprises) (Contradiction 2) |
| 3 | "CLI-only minimalism" narrative vs. embedded SDK deployments (OpenClaw) where pi is a runtime layer. | [B4#gotchas--surprises](../../B4/output/finding.md#gotchas--surprises) (Contradiction 5), [B5#building-blocks--concepts](../../B5/output/finding.md#building-blocks--concepts) |
| 4 | YOLO-by-default loved by power users, retrofitted with sandboxing by newcomers. | [B4#gotchas--surprises](../../B4/output/finding.md#gotchas--surprises) (Contradiction 1) |
| 5 | Cross-harness portability marketed (`~/.claude/skills`) but advanced Claude frontmatter (`context`,`agent`,`hooks`,`paths`) parity is unmapped. | [B2#summary](../../B2/output/finding.md#summary), [B2#open-questions](../../B2/output/finding.md#open-questions) |
| 6 | OSS = low lock-in directionally, but proprietary model aliases / config conventions still self-lock teams. | [B5#gotchas--surprises](../../B5/output/finding.md#gotchas--surprises) (Contradiction 4) |
| 7 | Headless suitability framed by UI polish in third-party reviews; actually depends on scripting surface, approval policy, remote exec semantics. | [B5#gotchas--surprises](../../B5/output/finding.md#gotchas--surprises) (Surprise/Contradiction 5) |

---

## Coverage map (input → recipe)

| Input | Used in | Excluded scope |
|---|---|---|
| [B1](../../B1/output/finding.md) | R1, R2, R3, R5 | extension event surface enumeration → S5 redesign roadmap |
| [B2](../../B2/output/finding.md) | R4, R5 | precedence-matrix codification → S6 open questions |
| [B3](../../B3/output/finding.md) | R2, R3, R4 | namespace governance / awesome-pi list → S6 |
| [B4](../../B4/output/finding.md) | R1, R2, R3, R5 | persistence-of-workflow / Earendil enterprise impact → S6 |
| [B5](../../B5/output/finding.md) | R3, R4 (positioning) | competitor head-to-head feature scoring → S4/S5 portability+redesign |

---

## What this doc does NOT cover

- **Beginner onboarding** (install → first run → core tools): see S2 `pi-beginner-onboarding`.
- **Skill-fleet portability verdict** (does *my* fleet skill set run on pi today?): see S4 `pi-portability-verdict`.
- **Per-skill keep-bash / port-to-extension / hybrid roadmap**: see S5 `pi-native-redesign-roadmap`.
- **Aggregated open questions** (precedence matrix, governance, namespace policy, workflow persistence, frontmatter parity): see S6 `pi-open-questions`.
- **Navigation index over all findings**: see S1 `pi-knowledge-index`.
- **Raw worker findings** (verbatim): `../../B1/output/finding.md` … `../../B5/output/finding.md`.
