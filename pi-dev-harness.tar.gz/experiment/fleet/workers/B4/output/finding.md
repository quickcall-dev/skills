## Summary
- Serious pi users are mostly workflow engineers, not “out-of-box” users: they run pi as a small core and layer custom extensions/skills/packages around it ([Mario 2025-11-30](https://mariozechner.at/posts/2025-11-30-pi-coding-agent/), [pi-agent-extensions](https://github.com/rytswd/pi-agent-extensions), [pi-qmd](https://github.com/hjanuschka/pi-qmd)).
- The strongest production pattern is embedding pi runtime into another system (not just CLI use), with OpenClaw as the clearest public example ([openclaw docs](https://github.com/openclaw/openclaw/blob/main/docs/pi.md), [Mario 2026-04-08](https://mariozechner.at/posts/2026-04-08-ive-sold-out/)).
- What works in practice is profile-driven setup: explicit config files, extension packs, and external sandboxing (container/bwrap/VM) rather than relying on built-in guardrails ([Mario 2025-11-30](https://mariozechner.at/posts/2025-11-30-pi-coding-agent/), [Reddit sandbox thread](https://www.reddit.com/r/LocalLLaMA/comments/1sunkcq/pidev_coding_agent_as_no_sandbox_by_default), [HN ecosystem signals](https://news.ycombinator.com/item?id=47120784)).

## Building blocks / concepts
- Minimal-core + userland features: advanced users keep core toolset small (`read/write/edit/bash`) and move custom behavior to extensions/skills ([Mario 2025-11-30](https://mariozechner.at/posts/2025-11-30-pi-coding-agent/), [dev.to self-documenting](https://dev.to/theoklitosbam7/pi-coding-agent-a-self-documenting-extensible-ai-partner-dn)).
- Package-first customization: teams install git/npm packages into pi settings and enable/disable per workflow ([pi-agent-extensions](https://github.com/rytswd/pi-agent-extensions), [gist setup guide](https://gist.github.com/schpet/85531b6a05a5d8119e859bdec6b0e0b8)).
- Embedded-agent architecture: power users/vendors integrate `pi-coding-agent` SDK directly and inject channel/domain tools (OpenClaw model) ([openclaw docs](https://github.com/openclaw/openclaw/blob/main/docs/pi.md), [dev.to OpenClaw architecture](https://dev.to/ialijr/lessons-from-openclaws-architecture-for-agent-builders-1j93)).
- AGENTS/SYSTEM steering as workflow primitive: power users treat instruction files as first-class, repo-local controls (examples in public AGENTS files and setup guides) ([oh-my-pi AGENTS](https://github.com/can1357/oh-my-pi/blob/main/AGENTS.md), [pi-coding-agent AGENTS](https://github.com/dnouri/pi-coding-agent/blob/master/AGENTS.md), [pi-qmd AGENTS](https://github.com/hjanuschka/pi-qmd/blob/main/AGENTS.md)).
- Community validation loops: HN launches, Reddit operational threads, X quick demos, and podcast/talk circuits are where workflows spread fastest ([HN](https://news.ycombinator.com/item?id=46579787), [Reddit](https://www.reddit.com/r/PiCodingAgent/comments/1srbq38/whats_worth_doing_asking_for_learning_guidance), [X](https://x.com/doublespends/status/2033668159039840622), [Podwise](https://podwise.ai/dashboard/episodes/7682649)).

## Code refs
- Pi workflow power users rely on extension packs loaded globally/per-user and managed via config: `/tmp/b4repos/pi-agent-extensions/README.org:18`, `/tmp/b4repos/pi-agent-extensions/README.org:20`, `/tmp/b4repos/pi-agent-extensions/README.org:33`, `/tmp/b4repos/pi-agent-extensions/README.org:39`.
- Package install path + settings wiring are explicit and reproducible: `/tmp/b4repos/pi-agent-extensions/README.org:64`, `/tmp/b4repos/pi-agent-extensions/README.org:66`, `/tmp/b4repos/pi-agent-extensions/README.org:68`, `/tmp/b4repos/pi-agent-extensions/README.org:111`.
- Selective workflow profiles emerge from toggles/gates in extensions (permission-gate etc.): `/tmp/b4repos/pi-agent-extensions/README.org:166`, `/tmp/b4repos/pi-agent-extensions/README.org:175`, `/tmp/b4repos/pi-agent-extensions/README.org:181`.
- Practical “pi as platform” usage appears in extension package AGENTS docs (qmd): `/tmp/b4repos/pi-qmd/AGENTS.md:3`, `/tmp/b4repos/pi-qmd/AGENTS.md:7`, `/tmp/b4repos/pi-qmd/AGENTS.md:17`, `/tmp/b4repos/pi-qmd/AGENTS.md:21`.
- OpenClaw embeds pi SDK directly rather than shelling out, with custom tool injection and session lifecycle control: `/tmp/b4repos/openclaw/docs/pi.md:13`, `/tmp/b4repos/openclaw/docs/pi.md:16`, `/tmp/b4repos/openclaw/docs/pi.md:18`, `/tmp/b4repos/openclaw/docs/pi.md:20`, `/tmp/b4repos/openclaw/docs/pi.md:246`, `/tmp/b4repos/openclaw/docs/pi.md:250`.
- Public AGENTS examples show experienced users codifying behavior/contracts for contributors and agents: `/tmp/b4repos/oh-my-pi/AGENTS.md:5`, `/tmp/b4repos/oh-my-pi/AGENTS.md:7`, `/tmp/b4repos/pi-coding-agent/AGENTS.md:3`, `/tmp/b4repos/pi-coding-agent/AGENTS.md:165`.
- Maintainer workflow stance (minimal tools, extension-first, no built-in plan/subagents) is explicit: `/tmp/b4_refs/mario-2025-11-30.html:47`, `/tmp/b4_refs/mario-2025-11-30.html:542`, `/tmp/b4_refs/mario-2025-11-30.html:564`, `/tmp/b4_refs/mario-2025-12-22.html:191`.
- Governance/workflow continuity signal after Earendil move is explicit (MIT core, ownership/governance statements): `/tmp/b4_refs/mario-2026-04-08.html:115`, `/tmp/b4_refs/mario-2026-04-08.html:120`, `/tmp/b4_refs/mario-2026-04-08.html:123`.

## Examples
```bash
# 1) Install shared extension pack for daily workflow
pi install git:github/rytswd/pi-agent-extensions

# 2) Pin package in user config (profile-like behavior)
cat > ~/.pi/agent/settings.json <<'JSON'
{
  "packages": ["/absolute/path/to/pi-agent-extensions"]
}
JSON

# 3) Add domain skill/extension package
npm install -g pi-qmd
jq '.extensions += ["pi-qmd"]' ~/.pi/agent/settings.json > /tmp/pi-settings.json && mv /tmp/pi-settings.json ~/.pi/agent/settings.json
```

```bash
# Typical safety pattern reported by power users: external sandbox wrapper
# (from community thread patterns, adapted to minimal bwrap usage)
bwrap --ro-bind / / --bind "$PWD" "$PWD" --tmpfs /tmp --setenv PS1 "pi-sandbox$ " bash
```

## Gotchas / surprises
- Contradiction 1: pi’s “YOLO by default” is loved for speed by power users, but newcomers repeatedly hit safety surprises and retrofit sandboxing later ([Mario 2025-11-30](https://mariozechner.at/posts/2025-11-30-pi-coding-agent/), [Reddit sandbox thread](https://www.reddit.com/r/LocalLLaMA/comments/1sunkcq/pidev_coding_agent_as_no_sandbox_by_default)).
- Contradiction 2: the “minimal harness” ideology still produces large extension ecosystems and complex workflow stacks in practice ([HN extension posts](https://news.ycombinator.com/item?id=47708055), [pi-agent-extensions](https://github.com/rytswd/pi-agent-extensions)).
- Contradiction 3: users praise no built-in subagents/plan mode, while community writeups quickly recreate agent orchestration in userland ([Mario 2025-11-30](https://mariozechner.at/posts/2025-11-30-pi-coding-agent/), [dev.to self-documenting](https://dev.to/theoklitosbam7/pi-coding-agent-a-self-documenting-extensible-ai-partner-dn)).
- Contradiction 4: governance anxiety after Earendil move appears in social threads, while maintainer states MIT core continuity and forkability ([Mario 2026-04-08](https://mariozechner.at/posts/2026-04-08-ive-sold-out/), [Reddit Earendil thread](https://www.reddit.com/r/LocalLLaMA/comments/1sg37af/pidev_coding_agent_is_moving_to_earendil)).
- Contradiction 5: “CLI-only minimalism” narrative coexists with heavy embedded deployments (OpenClaw) where pi is an SDK/runtime layer, not just a terminal tool ([openclaw docs](https://github.com/openclaw/openclaw/blob/main/docs/pi.md), [dev.to OpenClaw architecture](https://dev.to/ialijr/lessons-from-openclaws-architecture-for-agent-builders-1j93)).
- Self-critique: source breadth target was achieved, but social signals are noisy and over-indexed toward OpenClaw-adjacent chatter; direct user interviews were not part of this pass.

## Open questions
- Which power-user workflows persist >3 months versus hype-cycle experiments (especially HN “Show HN” spikes)?
- What is the stable “minimum safe profile” that retains pi velocity but reduces destructive command risk?
- How many serious teams use embedded pi SDK (OpenClaw-style) versus pure CLI + extension model?
- After April 8, 2026 governance changes, which enterprise-only features materially affect OSS users (if any)?
- If breadth had to exclude OpenClaw-adjacent sources, would B4 still hit ≥100 meaningful sources at similar confidence?

## Cross-refs
- B3 (ecosystem catalog): package-level enumeration and extension taxonomy overlap appeared repeatedly (true-queue, pi-persistent-term, pi-local-rag, oh-my-pi); I did not catalog package internals.
- B5 (comparison): many user posts compare pi vs Claude Code/Codex/opencode; I noted signals but did not score head-to-head feature/perf claims.
- A5/C tracks: session tree/compaction and embedded runtime details surfaced often; implementation-level correctness should come from code-focused workers.
