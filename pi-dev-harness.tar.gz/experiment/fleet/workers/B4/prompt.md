# Worker B4 — power users + workflows

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Who uses pi seriously, what they build, how they configure it, what works.

## Sources you own (do not touch others')

- Mario's blog (mariozechner.at)
- dev.to posts on pi
- HN, Reddit, X/Twitter mentions
- YouTube + conference talks + podcasts
- Public dotfiles repos with pi config
- Public AGENTS.md / SYSTEM.md examples on GitHub

## Out of scope (other workers cover)

- Ecosystem packages (B3)
- Comparison (B5)

## Source-mix target (per plan 05)

100% breadth — blogs/HN/X/YT/podcasts/dotfiles. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/B4/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/B4/output/` — use absolute paths.
