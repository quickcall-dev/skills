# Worker A3 — run modes (TUI / print-JSON / RPC / SDK)

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Four execution modes — when to use which, wire formats, JSONL event schema, RPC protocol, SDK embedding API.

## Sources you own (do not touch others')

- `pi-mono/packages/coding-agent/src/modes/` (interactive, print, rpc, sdk subdirs)
- RPC schema files
- SDK README + examples
- Any client repos using pi RPC/SDK in the wild

## Out of scope (other workers cover)

- Tool internals (A2)
- Providers (A4)
- Sessions (A5)

## Source-mix target (per plan 05)

70% source code (modes/), 20% RPC/SDK clients in wild, 10% docs. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/A3/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/A3/output/` — use absolute paths.
