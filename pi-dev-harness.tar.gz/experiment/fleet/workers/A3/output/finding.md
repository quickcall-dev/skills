## Summary
- Pi exposes four execution surfaces with distinct lifecycle contracts: TUI (`interactive`), one-shot output (`print` / `--mode json`), long-lived RPC (`--mode rpc`), and in-process embedding (SDK APIs). `packages/coding-agent/src/main.ts:96` `packages/coding-agent/src/main.ts:677` `packages/coding-agent/README.md:25`
- Wire formats diverge by mode: print text emits only final assistant text; JSON mode emits session header + `AgentSessionEvent` JSONL; RPC adds command/response/event framing plus extension-UI request/response sub-protocol. `packages/coding-agent/src/modes/print-mode.ts:104` `packages/coding-agent/docs/json.md:60` `packages/coding-agent/src/modes/rpc/rpc-types.ts:19` `packages/coding-agent/docs/rpc.md:984`
- “In the wild” clients split into two camps: subprocess RPC wrappers (e.g. Polpo) and embedded SDK runtimes (e.g. OpenClaw/PiClaw). `/tmp/polpo/src/agent/pi-agent.js:166` `/tmp/openclaw/docs/pi.md:13` `/tmp/piclaw/runtime/src/agent-pool/session.ts:590`

## Building blocks / concepts
- `Interactive mode`:
  Full TUI app with keybinding-driven controls, slash-command handling, queue UX, model/session selectors, and extension widgets. `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:244` `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:2388` `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:2476`
- `Print mode (text)`:
  Single-shot run; sends prompts and prints only assistant text blocks, then exits with non-zero on assistant error/abort. `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:2` `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:128`
- `Print mode (json)`:
  Same single-shot execution, but subscribes to session events and writes JSON line per event; emits header first. `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:103` `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:111` `/tmp/pi-mono/packages/coding-agent/docs/json.md:60`
- `RPC mode`:
  Long-lived command loop over stdin/stdout JSONL. Commands are request-like objects; responses correlate with optional `id`; events stream independently. `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:365` `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:19` `/tmp/pi-mono/packages/coding-agent/docs/rpc.md:21`
- `Strict JSONL framing`:
  Protocol delimiter is LF only; U+2028/U+2029 are valid inside payload and must not split records. `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:7` `/tmp/pi-mono/packages/coding-agent/test/rpc-jsonl.test.ts:14`
- `RPC extension UI bridge`:
  Dialog-style UI calls block on `extension_ui_response`; fire-and-forget UI calls only notify host. `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:83` `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:213` `/tmp/pi-mono/packages/coding-agent/docs/rpc.md:988`
- `SDK embedding API`:
  `createAgentSession()` for single session, and `AgentSessionRuntime`/`createAgentSessionRuntime()` when host must replace active sessions (`newSession`, `switchSession`, `fork`, import). `/tmp/pi-mono/packages/coding-agent/src/core/sdk.ts:180` `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:67` `/tmp/pi-mono/packages/coding-agent/docs/sdk.md:120`

## Code refs
- Mode selection and dispatch:
  `/tmp/pi-mono/packages/coding-agent/src/main.ts:96`
  `/tmp/pi-mono/packages/coding-agent/src/main.ts:98`
  `/tmp/pi-mono/packages/coding-agent/src/main.ts:677`
  `/tmp/pi-mono/packages/coding-agent/src/main.ts:718`
- CLI-exposed mode values and help text:
  `/tmp/pi-mono/packages/coding-agent/src/cli/args.ts:10`
  `/tmp/pi-mono/packages/coding-agent/src/cli/args.ts:74`
  `/tmp/pi-mono/packages/coding-agent/src/cli/args.ts:217`
- Print/JSON behavior:
  `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:17`
  `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:104`
  `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:111`
  `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:128`
- Interactive loop + queue semantics in TUI:
  `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:707`
  `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:2635`
  `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:3350`
- RPC command schema (stdin):
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:19`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:51`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:55`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:68`
- RPC response schema + state payload:
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:91`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:111`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:205`
- RPC command handling implementation:
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:374`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:426`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:448`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:506`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:534`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:617`
- RPC JSONL framing:
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:10`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:21`
  `/tmp/pi-mono/packages/coding-agent/test/rpc-jsonl.test.ts:6`
- RPC client abstraction (SDK-exported):
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:68`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:167`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:401`
  `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:474`
- Official protocol docs:
  `/tmp/pi-mono/packages/coding-agent/docs/rpc.md:29`
  `/tmp/pi-mono/packages/coding-agent/docs/rpc.md:55`
  `/tmp/pi-mono/packages/coding-agent/docs/rpc.md:499`
  `/tmp/pi-mono/packages/coding-agent/docs/rpc.md:740`
  `/tmp/pi-mono/packages/coding-agent/docs/rpc.md:984`
- JSON event schema docs:
  `/tmp/pi-mono/packages/coding-agent/docs/json.md:11`
  `/tmp/pi-mono/packages/coding-agent/docs/json.md:25`
  `/tmp/pi-mono/packages/coding-agent/docs/json.md:60`
- SDK docs/runtime APIs:
  `/tmp/pi-mono/packages/coding-agent/docs/sdk.md:50`
  `/tmp/pi-mono/packages/coding-agent/docs/sdk.md:118`
  `/tmp/pi-mono/packages/coding-agent/src/core/sdk.ts:180`
  `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:175`
  `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:200`
  `/tmp/pi-mono/packages/coding-agent/src/core/agent-session-runtime.ts:234`
- SDK exports include run-mode + RPC helpers:
  `/tmp/pi-mono/packages/coding-agent/src/index.ts:284`
  `/tmp/pi-mono/packages/coding-agent/src/index.ts:290`
- Real-world RPC client implementation (Polpo):
  `/tmp/polpo/src/agent/pi-agent.js:4`
  `/tmp/polpo/src/agent/pi-agent.js:166`
  `/tmp/polpo/src/agent/pi-agent.js:233`
  `/tmp/polpo/src/agent/pi-agent.js:504`
  `/tmp/polpo/src/agent/pi-agent.js:519`
- Real-world SDK embedding (OpenClaw + PiClaw):
  `/tmp/openclaw/docs/pi.md:13`
  `/tmp/openclaw/src/agents/pi-embedded-runner/run/attempt.ts:1365`
  `/tmp/openclaw/scripts/control-ui-i18n.ts:702`
  `/tmp/piclaw/runtime/src/agent-pool/session.ts:22`
  `/tmp/piclaw/runtime/src/agent-pool/session.ts:590`
  `/tmp/piclaw/runtime/src/agent-pool/runtime-facade.ts:633`
  `/tmp/piclaw/runtime/src/channels/web/theming/ui-bridge.ts:185`

## Examples
```bash
# 1) Interactive TUI (human-in-the-loop)
pi

# 2) One-shot text output (shell-friendly)
pi -p "Summarize src/main.ts"

# 3) One-shot JSONL event stream
pi --mode json "List TypeScript files"

# 4) Long-lived RPC process (host controls lifecycle)
pi --mode rpc --model anthropic/claude-sonnet-4-5
```

```json
{"id":"req-1","type":"prompt","message":"Review this diff"}
{"id":"req-1","type":"response","command":"prompt","success":true}
{"type":"agent_start"}
{"type":"message_update","assistantMessageEvent":{"type":"text_delta","delta":"Looking at"}}
{"type":"agent_end","messages":[...]}
```

```ts
import { createAgentSession, SessionManager } from "@mariozechner/pi-coding-agent";

const { session } = await createAgentSession({
  sessionManager: SessionManager.inMemory(),
});
session.subscribe((event) => {
  if (event.type === "message_update" && event.assistantMessageEvent.type === "text_delta") {
    process.stdout.write(event.assistantMessageEvent.delta);
  }
});
await session.prompt("What changed in this repository?");
```

```ts
import { RpcClient } from "@mariozechner/pi-coding-agent";

const client = new RpcClient({ cliPath: "dist/cli.js" });
await client.start();
await client.prompt("Run tests and summarize failures");
await client.waitForIdle();
await client.stop();
```

## Gotchas / surprises
- `print` mode is not only `-p`; non-TTY stdin also forces print path unless explicit RPC. This can surprise script authors. `/tmp/pi-mono/packages/coding-agent/src/main.ts:105` `/tmp/pi-mono/packages/coding-agent/src/main.ts:639`
- `--mode json` and `--mode rpc` are not equivalent: JSON mode is one-shot event dump; RPC is command loop with request correlation and extension UI sub-protocol. `/tmp/pi-mono/packages/coding-agent/src/cli/args.ts:10` `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:2` `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:48`
- RPC `prompt` returns success at preflight acceptance time, not at final generation completion; completion arrives via later events (`agent_end`). `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:375` `/tmp/pi-mono/packages/coding-agent/test/rpc-prompt-response-semantics.test.ts:230`
- Strict LF framing means using generic Node `readline` on RPC payload is protocol-risky (Unicode separators). Official docs warn against it, but some third-party code still uses `readline` for parsing process stdout, which can diverge from strict reader behavior. `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:17` `/tmp/pi-mono/packages/coding-agent/docs/rpc.md:36` `/tmp/polpo/src/agent/pi-agent.js:185`
- RPC UI coverage is intentionally partial: many TUI-only UI methods are no-ops or degraded in RPC mode (`setFooter`, `setHeader`, theme switching, editor introspection). `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:203` `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:286` `/tmp/pi-mono/packages/coding-agent/docs/rpc.md:995`
- “SDK embedding” clients in the wild commonly bypass RPC entirely and call `createAgentSession`/runtime APIs directly (OpenClaw, PiClaw), so RPC is not the universal integration path. `/tmp/openclaw/docs/pi.md:13` `/tmp/piclaw/runtime/src/agent-pool/session.ts:590`

## Open questions
- Health-floor gap: this slice reached ≥100 distinct sources but not ≥30 unique web domains because the A3 MECE scope is code-heavy (`modes/`, RPC schema, SDK docs/examples) and real integrations are concentrated on GitHub/local repos. Additional non-GitHub domains would require broad commentary sources beyond this worker’s source partition.
- Should strict JSONL framing be enforced by schema/version handshake in RPC startup to prevent clients silently using incompatible line readers?
- RPC currently exports many session operations but no explicit capability negotiation packet. Should hosts discover support via `get_state`/`get_commands`, or should a dedicated `get_capabilities` command be added?
- SDK guidance nudges Node users toward embedding `AgentSession`; however, cross-process isolation and fault containment are better with RPC. Missing: a first-class “selection matrix” in docs for reliability/security tradeoffs.
- Third-party wrappers (e.g., Polpo) map tool/result event shapes with custom field names (`event.tool` vs `toolName` assumptions). Should upstream publish conformance tests or JSON schema artifacts to harden adapters?

## Cross-refs
- Tool semantics and built-in tool behavior are mostly in A2 scope; A3 only touches their event envelopes and mode transport boundaries.
- Provider/model normalization details (auth injection, per-provider transport quirks) are A4 scope; A3 only references mode-level model switching commands.
- Session-tree persistence and branching internals are A5 scope; A3 only references runtime replacement APIs and RPC commands that trigger session operations.
