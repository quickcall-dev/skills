# Worker B2 — skills, prompts, themes

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Composability, discovery, namespacing, distribution. How pi skills compare to Claude Code skills.

## Sources you own (do not touch others')

- `pi-mono/packages/coding-agent/src/skills/` + `prompts/` + `themes/`
- Example skills repos
- Published pi-skill packages on npm

## Out of scope (other workers cover)

- Extension internals (B1)
- Ecosystem (B3)

## Source-mix target (per plan 05)

60% source + skill examples, 40% published packages. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/B2/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/B2/output/` — use absolute paths.
