## Summary
- pi’s skill/prompt/theme system is composition-first: resources are discovered from user/project/path/package inputs, then deduped by name with collision diagnostics rather than hard failure (`/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:404`, `/tmp/pi-mono/packages/coding-agent/src/core/resource-loader.ts:790`).
- Discovery semantics are asymmetric by resource type: skills recurse for `SKILL.md`, prompt templates are non-recursive, and themes are JSON file-based with strict schema validation and fallback behavior (`/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:167`, `/tmp/pi-mono/packages/coding-agent/src/core/prompt-templates.ts:136`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:516`).
- Versus Claude Code, pi stays closer to cross-harness portability (`~/.claude/skills`, `~/.codex/skills`) but has weaker built-in namespacing than Claude’s plugin-prefixed skill namespace (`/tmp/pi-mono/packages/coding-agent/docs/skills.md:45`, [https://r.jina.ai/http://code.claude.com/docs/en/skills](https://r.jina.ai/http://code.claude.com/docs/en/skills)).

## Building blocks / concepts
- Skill discovery roots: user/project/default paths plus explicit `--skill` paths and package-provided paths; load order is resolved in `loadSkills` + resource loader path merging (`/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:404`, `/tmp/pi-mono/packages/coding-agent/src/core/resource-loader.ts:420`).
- Skill validation contract: name is validated leniently (warnings), but missing description prevents load (`/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:293`, `/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:309`).
- Prompt template expansion model: `/name` lookup + shell-style argument parsing/substitution (`$1`, `$@`, `$ARGUMENTS`, slices) with non-recursive directory scanning (`/tmp/pi-mono/packages/coding-agent/src/core/prompt-templates.ts:24`, `/tmp/pi-mono/packages/coding-agent/src/core/prompt-templates.ts:68`, `/tmp/pi-mono/packages/coding-agent/src/core/prompt-templates.ts:136`).
- Theme model: built-ins (`dark`,`light`) + custom JSON; all required color tokens validated by TypeBox schema; invalid theme parse/validation errors trigger fallback to dark (`/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:23`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:463`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:691`).
- Distribution model: `pi` package manifest (`pi.skills`, `pi.prompts`, `pi.themes`) or convention dirs (`skills/`, `prompts/`, `themes/`) with install sources npm/git/local (`/tmp/pi-mono/packages/coding-agent/docs/packages.md:5`, `/tmp/pi-mono/packages/coding-agent/docs/packages.md:108`, `/tmp/pi-mono/packages/coding-agent/docs/packages.md:150`).
- Claude Code comparison anchors: enterprise/personal/project/plugin locations, plugin namespace (`plugin-name:skill-name`), and richer skill frontmatter controls (`context`, `agent`, `user-invocable`, etc.) ([https://r.jina.ai/http://code.claude.com/docs/en/skills](https://r.jina.ai/http://code.claude.com/docs/en/skills)).

## Code refs
- Skill name/description validation rules and limits: `/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:10`, `/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:92`, `/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:121`.
- Discovery behavior (root `SKILL.md` short-circuit, recursive search, root `.md` handling): `/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:167`, `/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:224`, `/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:266`.
- Collision behavior (`first wins`, diagnostics for losers): `/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:431`, `/tmp/pi-mono/packages/coding-agent/src/core/resource-loader.ts:790`, `/tmp/pi-mono/packages/coding-agent/src/core/resource-loader.ts:816`.
- Prompt argument parser/substituter and `/template` expansion: `/tmp/pi-mono/packages/coding-agent/src/core/prompt-templates.ts:24`, `/tmp/pi-mono/packages/coding-agent/src/core/prompt-templates.ts:68`, `/tmp/pi-mono/packages/coding-agent/src/core/prompt-templates.ts:282`.
- Theme schema + runtime discovery/fallback: `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:23`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:463`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:516`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:691`.
- Regression-enforced precedence (project > user > package): `/tmp/pi-mono/packages/coding-agent/test/suite/regressions/2781-skill-collision-precedence.test.ts:61`.

## Examples
```json
{
  "skills": ["~/.claude/skills", "~/.codex/skills"]
}
```
Loads Claude Code and Codex skill directories directly in pi (`/tmp/pi-mono/packages/coding-agent/docs/skills.md:45`).

```json
{
  "keywords": ["pi-package"],
  "pi": {
    "skills": ["./skills"],
    "prompts": ["./prompts"],
    "themes": ["./themes"]
  }
}
```
Minimal package distribution shape for B2 resources (`/tmp/pi-mono/packages/coding-agent/docs/packages.md:108`).

```bash
/skill:brave-search
/component Button "onClick handler"
```
Skill invocation and prompt template invocation coexist, with distinct syntaxes (`/tmp/pi-mono/packages/coding-agent/docs/skills.md:75`, `/tmp/pi-mono/packages/coding-agent/docs/prompt-templates.md:60`).

## Gotchas / surprises
- Missing skill `description` is a hard skip, while many other spec violations are warnings only (`/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:309`, `/tmp/pi-mono/packages/coding-agent/docs/skills.md:178`).
- If a directory contains root `SKILL.md`, nested `SKILL.md` files under it are not traversed for that subtree (`/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:168`, `/tmp/pi-mono/packages/coding-agent/test/skills.test.ts:108`).
- Prompt templates are non-recursive in `prompts/`, unlike recursive skill discovery; monorepos must explicitly wire subdirs (`/tmp/pi-mono/packages/coding-agent/docs/prompt-templates.md:87`, `/tmp/pi-mono/packages/coding-agent/src/core/prompt-templates.ts:136`).
- Invalid theme selection falls back to `dark`, which can mask configuration mistakes unless diagnostics are surfaced (`/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:699`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/theme/theme.ts:719`).
- Name collision semantics differ by system: pi mostly relies on first-seen winner + diagnostics, while Claude Code documents location precedence and plugin namespacing to avoid collisions up-front (`/tmp/pi-mono/packages/coding-agent/src/core/skills.ts:431`, [https://r.jina.ai/http://code.claude.com/docs/en/skills](https://r.jina.ai/http://code.claude.com/docs/en/skills)).
- pi skill command namespace uses `skill:` prefix (`/skill:name`), which reduces collision with prompt template commands but adds a different UX from Claude’s `/name` skill convention (`/tmp/pi-mono/packages/coding-agent/docs/skills.md:75`, [https://r.jina.ai/http://code.claude.com/docs/en/skills](https://r.jina.ai/http://code.claude.com/docs/en/skills)).

## Open questions
- Self-critique: this pass emphasizes static source/metadata analysis; I did not install/execute third-party skill packages, so runtime quality and safety posture remain partially unvalidated.
- pi docs describe package-level dedup and precedence, and regression tests enforce project/user/package priority for skills, but there is no single authoritative precedence matrix covering skills, prompts, and themes together; this should be codified in one spec page (`/tmp/pi-mono/packages/coding-agent/docs/packages.md:212`, `/tmp/pi-mono/packages/coding-agent/test/suite/regressions/2781-skill-collision-precedence.test.ts:91`).
- Cross-harness compatibility is documented for Claude/Codex skill directories, but behavior parity for advanced Claude-only frontmatter (`context`, `agent`, `hooks`, `paths`) is not explicitly mapped by pi docs (`/tmp/pi-mono/packages/coding-agent/docs/skills.md:45`, [https://r.jina.ai/http://code.claude.com/docs/en/skills](https://r.jina.ai/http://code.claude.com/docs/en/skills)).
- Package ecosystem signal quality is noisy: many npm `pi-package` entries point to mixed-purpose repos; tighter discoverability metadata would help users find high-signal skill packs ([https://www.npmjs.com/package/@alexgorbatchev/pi-skill-library](https://www.npmjs.com/package/@alexgorbatchev/pi-skill-library), [https://www.npmjs.com/package/pi-skill-tavily](https://www.npmjs.com/package/pi-skill-tavily), [https://www.npmjs.com/package/std-c99-proj-skill](https://www.npmjs.com/package/std-c99-proj-skill)).

## Cross-refs
- B1 overlap: extension lifecycle/hook internals affect how package resources are materialized and enabled, but I avoided deep extension API analysis (`/tmp/pi-mono/packages/coding-agent/src/core/resource-loader.ts:556`).
- B3 overlap: npm ecosystem quality/ranking and package catalog breadth are visible in this slice but belong to ecosystem synthesis.
- B5 overlap: competitive positioning vs Claude/Codex/Cursor appears in package README outbound links but comparative judgments belong in dedicated comparison track.
