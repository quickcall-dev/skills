---
title: "pi-portability-verdict"
audience: skill maintainer (Sagar)
synthesizes: [C1, C2]
created: "2026-04-25"
---

# S4 — pi Portability Verdict

## TL;DR

Fleet skills are **mostly portable** to `pi` today via the existing `build_inner_cmd` adapter seam — `pi -p` + `pi --mode json` cleanly map to `claude -p --output-format stream-json` for the 4/5 abstracted launch sites. **One global blocker**: `dag-fleet/scripts/relaunch-worker.sh` hardcodes `claude -p` flags and bypasses the adapter (must be migrated first). **Three normalization gaps**: terminal-event schema (`result` vs `turn.completed` vs pi's `AgentSessionEvent` envelope), cost field shape (`total_cost_usd` vs `AssistantMessage.usage.cost.*`), and CLI cwd flag (no top-level `pi --cd` — RPC-only). `fleet-plan` and `doc` skills are config/doc generators with no provider shell-outs → effectively portable today.

---

## Per-skill verdict

| Skill | Today on pi? | Blockers | Changes needed | Effort |
|---|---|---|---|---|
| dag-fleet | ⚠️ | `relaunch-worker.sh` hardcodes `claude -p` flags ([C1#Direct CLI hardcode path](../../C1/output/finding.md#building-blocks--concepts), [C1#code refs row 2](../../C1/output/finding.md#code-refs)); terminal/cost event parsing assumes `result`+`total_cost_usd` ([C1#Terminal-event contract](../../C1/output/finding.md#building-blocks--concepts)) | Add `provider=pi` branch to `build_inner_cmd`; migrate `relaunch-worker.sh` to adapter; add pi event normalizer (`AgentSessionEvent` → `result`-shaped; `AssistantMessage.usage.cost.*` → `total_cost_usd`) ([C2#Per-turn cost/tokens](../../C2/output/finding.md#summary), [C2#Unified usage schema](../../C2/output/finding.md#building-blocks--concepts)) | M |
| worktree-fleet | ✅ (with adapter) | No CLI cwd flag in pi help → worktree cwd targeting depends on shell `cd` wrapper, not flag ([C2#CWD override](../../C2/output/finding.md#summary)); provider-conditional worker-type override is Claude-specific ([C1#Gotchas](../../C1/output/finding.md#gotchas--surprises)) | `build_inner_cmd` emits `cd "$WORKER_DIR" && pi -p ...` instead of `--cd`; add pi to provider-conditional override policy in `worktree-fleet/scripts/launch.sh:321` | S |
| iterative-fleet | ⚠️ | Replays raw shell command strings from `.worker-cmd-*.sh` each iteration ([C1#Gotchas](../../C1/output/finding.md#gotchas--surprises)) → quoting fragility for new provider; cost parsing assumes `total_cost_usd` ([C1#Cost contract](../../C1/output/finding.md#building-blocks--concepts)) | Once adapter handles pi, replay path inherits it; add pi cost-field normalizer matching `AssistantMessage.usage` shape | S |
| autoresearch-fleet | ⚠️ | Search-mode enabled by `sed`-injecting `--tools default` into `claude -p` command string ([C1#Search-mode tool escalation](../../C1/output/finding.md#building-blocks--concepts), [C1#Gotchas](../../C1/output/finding.md#gotchas--surprises)); usage parsing reads `message.usage.{input,output,cache_read,cache_creation}_tokens` ([C1#code refs](../../C1/output/finding.md#code-refs)) | Replace string mutation with structured option in `build_inner_cmd`; pi search escalation likely maps to `--tools` allowlist incl. web ([C2#Tool allowlist](../../C2/output/finding.md#summary)) — confirm pi web-search tool name; remap usage parser to pi `cost.*` fields | M |
| fleet-plan | ✅ | None known — fleet-plan emits config + prompt files, no direct provider shell-out (not in C1/C2 scope; inferred from absence in C1 call-site inventory) | Verify generated configs reference `provider=pi` once adapter lands | S |
| doc | ✅ | None known — doc skill writes structured markdown, no provider shell-out (out of C1/C2 scope) | None | S |

Effort key: S = <1 day, M = 1–3 days, L = >3 days.

---

## Global blockers (cross-skill)

1. **Hardcoded `claude -p` in relaunch path** — only call site bypassing `build_inner_cmd`. Must migrate before pi integration ([C1#Direct CLI hardcode path](../../C1/output/finding.md#building-blocks--concepts), [C1#Open questions](../../C1/output/finding.md#open-questions)).
2. **Terminal-event schema divergence** — fleets check `type=result|turn.completed|turn.failed`; pi emits `AgentSessionEvent`-wrapped events whose top-level field names are not declared in C2-owned files ([C2#Open questions](../../C2/output/finding.md#open-questions)). Adapter must normalize.
3. **Cost-field schema divergence** — fleets read `total_cost_usd` (Claude exact) or estimate from `usage.input_tokens/output_tokens` (Codex); pi exposes `AssistantMessage.usage.cost.*` plus RPC `get_session_stats` ([C2#Per-turn cost/tokens](../../C2/output/finding.md#summary)). Adapter must map.
4. **No CLI cwd flag** — pi help shows no `--cd`; cwd lives only in `RpcClientOptions.cwd` for RPC embedding ([C2#CWD override](../../C2/output/finding.md#summary), [C2#Gotchas](../../C2/output/finding.md#gotchas--surprises)). Bash port must wrap with `cd && pi ...`.
5. **JSON-mode header line** — pi `--mode json` emits non-event header before stream ([C2#Gotchas](../../C2/output/finding.md#gotchas--surprises)). Consumers (`tail -1 jsonl | jq`) must skip it.
6. **Brittle `sed` mutation in autoresearch** — search escalation rewrites command string rather than passing options ([C1#Gotchas](../../C1/output/finding.md#gotchas--surprises)). Any new provider amplifies fragility.
7. **`HOME` requirement** — pi initializes session storage even on `--help` ([C2#Gotchas](../../C2/output/finding.md#gotchas--surprises)). Fleet runner scripts must guarantee writable `HOME`.

---

## Quick wins (already work)

- **Headless one-shot** — `pi -p "..."` direct map to `claude -p` / `codex exec` ([C2#Headless one-shot run](../../C2/output/finding.md#summary)).
- **JSONL streaming** — `pi --mode json` produces newline-delimited events; `pi --mode rpc` provides stronger control channel ([C2#Stream JSONL](../../C2/output/finding.md#summary)).
- **Session resume** — `--continue` / `--resume` / `--session <path|id>` covers fleet's session-name use ([C2#Session resume](../../C2/output/finding.md#summary)).
- **Tool allowlist** — `--tools` / `--no-tools` / `--no-builtin-tools` covers `--disallowed-tools` ([C2#Tool allowlist](../../C2/output/finding.md#summary)).
- **Model swap** — `--provider`/`--model` startup; RPC `set_model`/`cycle_model` runtime ([C2#Model swap](../../C2/output/finding.md#summary)).
- **Adapter seam already exists** — 4/5 launchers route through `build_inner_cmd`, so adding `provider=pi` is single-point change ([C1#`build_inner_cmd` abstraction](../../C1/output/finding.md#building-blocks--concepts)).

---

## Contradictions

1. **C1 says provider portability is asymmetric (relaunch hardcodes Claude); C2 says pi maps to claude/codex on most flags.** Not a real contradiction — they describe different layers. C1 = current call-site code ships with Claude bias; C2 = pi CLI surface is *capable* of substituting. Resolution: capability ≠ wiring; wiring work still required.
2. **C1 lists `--max-budget-usd` as required Claude flag in relaunch; C2 does not enumerate any pi budget flag.** Possible gap — pi help inspection in C2 did not list a per-run budget cap. Flagging for S6: does pi expose a budget ceiling?
3. **C1 treats `usage.input_tokens/output_tokens` (snake_case) as Codex/estimate shape; C2 documents pi's `AssistantMessage.usage.{input,output}` (camelCase, no `_tokens` suffix).** Different field naming → adapter must explicitly translate, not pass-through.
4. **C1 autoresearch parses `message.usage.cache_read_input_tokens` / `cache_creation_input_tokens`; C2 pi shape is `usage.cacheRead` / `usage.cacheWrite`.** Same translation issue, separate cache fields.

---

## Actionable punch list

1. Migrate `dag-fleet/scripts/relaunch-worker.sh:242` from direct `claude -p` to `build_inner_cmd` invocation. Pre-req for any pi work.
2. Add `provider=pi` branch in `build_inner_cmd` (all 4 launcher copies — or extract to shared lib if not already) emitting `pi -p` + `--mode json` + `--tools` + `--session` + `--model`.
3. Wrap with `cd "$CWD" && pi ...` for cwd targeting in worktree-fleet (no `--cd` flag).
4. Write event normalizer: pi `AgentSessionEvent` → fleet's `{type:result, subtype:..., total_cost_usd:...}` shape. Drop pi's JSON-mode header line.
5. Write cost normalizer: pi `AssistantMessage.usage.cost.*` and `usage.{input,output,cacheRead,cacheWrite,totalTokens}` → fleet's `total_cost_usd` + `usage.input_tokens/output_tokens`.
6. Replace autoresearch's `sed`-based `--tools default` injection with structured option; map pi web-search tool name (verify via pi tool catalog).
7. Ensure runner scripts export writable `HOME` before any `pi` invocation.
8. Add pi to `worktree-fleet/scripts/launch.sh:321` provider-conditional worker-type policy.

---

## Open questions (forward to S6)

- Does `build_inner_cmd` extensibility suffice without changing all 4 callers? ([C1#Open questions](../../C1/output/finding.md#open-questions))
- Should fleet standardize on `result` or `turn.completed` as canonical terminal? ([C1#Open questions](../../C1/output/finding.md#open-questions))
- Exact `AgentSessionEvent` envelope field names — outside C2 slice ([C2#Open questions](../../C2/output/finding.md#open-questions)).
- Hidden CLI cwd flags not in pi help? ([C2#Open questions](../../C2/output/finding.md#open-questions))
- `SessionStats` schema for `get_session_stats` (cost aggregation) ([C2#Open questions](../../C2/output/finding.md#open-questions)).
- Does pi expose a per-run budget cap analog to `--max-budget-usd`? (contradiction #2 above).
- Does pi have a fallback-model flag analog to Claude's `--fallback-model`? (not surfaced in C2).

---

## Source map

- C1 (call-site audit): [`workers/C1/output/finding.md`](../../C1/output/finding.md), [`workers/C1/output/sources.md`](../../C1/output/sources.md) — 273 primary sources, 100% local fleet-script + plan refs. High confidence on call-site contracts; explicit gap: `lib/worker-spawn.sh` excluded from scope.
- C2 (pi CLI translation): [`workers/C2/output/finding.md`](../../C2/output/finding.md), [`workers/C2/output/sources.md`](../../C2/output/sources.md) — pi-mono package files + extracted help text. High confidence on flag/protocol mapping; lower confidence on event-envelope field names (agent-core types out of slice).

---

## What this doc does NOT cover

- **Beginner pi onboarding / install / first-run** → see S2 (`pi-beginner-onboarding`).
- **Power-user workflow recipes (headless review, multi-provider cost, RPC fleet)** → see S3 (`pi-power-workflow-recipes`).
- **pi-native redesign (keep-bash vs port-to-extension vs hybrid + per-skill effort)** → see S5 (`pi-native-redesign-roadmap`). C3 is the source for that decision; this doc only answers "today, with what changes."
- **Aggregated open questions across all 13 workers** → see S6 (`pi-open-questions`).
- **Navigation index over all findings** → see S1 (`pi-knowledge-index`).
