---
title: "pi-open-questions"
audience: next-experiment planner
sources: A1, A2, A3, A4, A5, B1, B2, B3, B4, B5, C1, C2, C3
---

# S6 — Open Questions Harvest

## TL;DR
Across 13 workers, ~40 distinct unknowns clustered into five buckets. Highest cost-of-not-knowing items concentrate on **pi runtime contracts that fleet redesign depends on** (event/usage envelope, JSONL framing handshake, CLI cwd flag) and on **maintainer-philosophy boundaries** (what can be packaged vs forced into core). Seven cross-worker contradictions surfaced — most are surface-vs-truth gaps (capability narrative vs ecosystem reality) rather than bugs. This doc is the input list for the next research round; do not treat ranks as priorities for engineering.

---

## Ranking convention

Cost of not knowing:
- **HIGH** — blocks an S4/S5 redesign decision or risks rework if assumed wrong.
- **MED** — narrows redesign options or affects ecosystem strategy.
- **LOW** — clarifies edges, useful for completeness.

---

## Bucket 1 — pi.dev internals (unanswered)

| # | Question | Raised by | Cost |
|---|---|---|---|
| 1 | What is the exact top-level event-envelope shape for per-turn `usage`/`cost` in `AgentSessionEvent`? `AssistantMessage.usage` is clear, but the event wrapper is outside C2's slice. Without this, a fleet adapter cannot reliably extract per-turn cost from `--mode json`/RPC. | [C2#Open questions](../../C2/output/finding.md#open-questions), [C1#Building blocks](../../C1/output/finding.md#building-blocks--concepts) | **HIGH** |
| 2 | Should strict JSONL framing be enforced via a startup version/handshake so RPC clients can't silently use `readline` (Unicode-separator) splitters? Polpo already diverges in the wild. | [A3#Open questions](../../A3/output/finding.md#open-questions) | **HIGH** |
| 3 | Is there a hidden CLI cwd flag (codex `--cd` equivalent) that doesn't appear in `--help`? If not, does fleet have to embed via RPC `RpcClientOptions.cwd` for cwd-targeted workers? | [C2#Open questions](../../C2/output/finding.md#open-questions), [C2#Gotchas](../../C2/output/finding.md#gotchas--surprises) | **HIGH** |
| 4 | Should `bash` expose a configurable non-zero exit allowlist (grep/diff/test exit-1) instead of blanket error-conversion? Current behavior misleads agent control flow. | [A2#Open questions](../../A2/output/finding.md#open-questions), [A2#Gotchas](../../A2/output/finding.md#gotchas--surprises) | MED |
| 5 | Should pi adopt an optional hash-anchor edit mode (à la oh-my-pi `hashline`) for weaker models, keeping exact-text mode as default? | [A2#Open questions](../../A2/output/finding.md#open-questions) | MED |
| 6 | Should pi expose an atomic multi-file edit transaction primitive instead of only per-file mutation queueing? | [A2#Open questions](../../A2/output/finding.md#open-questions) | LOW |
| 7 | Should RPC add an explicit `get_capabilities` command rather than forcing hosts to derive support from `get_state`/`get_commands`? | [A3#Open questions](../../A3/output/finding.md#open-questions) | MED |
| 8 | Should provider/API registration become introspectable at runtime so `/model` and diagnostics can deterministically explain normalization? | [A4#Open questions](../../A4/output/finding.md#open-questions) | MED |
| 9 | Should synthetic tool-result insertion (cross-provider replay) be toggleable for strict replay/debug? Current behavior changes byte-identity of replayed history. | [A4#Open questions](../../A4/output/finding.md#open-questions), [A4#Gotchas](../../A4/output/finding.md#gotchas--surprises) | MED |
| 10 | Should cost logic support provider-native pricing variants (service tiers) instead of static per-1M-token tables? | [A4#Open questions](../../A4/output/finding.md#open-questions) | LOW |
| 11 | Should `/tree` and `/resume` share one authoritative state-restore function for model/thinking? Drift today (issue [#3544](https://github.com/badlogic/pi-mono/issues/3544)). | [A5#Open questions](../../A5/output/finding.md#open-questions) | MED |
| 12 | Should `_branchSummaryAbortController` lifecycle in `navigateTree()` be wrapped in `try/finally` to guarantee cleanup on cancel paths (issue [#3688](https://github.com/badlogic/pi-mono/issues/3688))? | [A5#Open questions](../../A5/output/finding.md#open-questions) | LOW |
| 13 | Is `SessionManager.continueRecent(cwd, ...)` expected to favor session-header cwd over launch cwd in all modes (interactive, RPC, non-interactive) — issue [#3249](https://github.com/badlogic/pi-mono/issues/3249)? | [A5#Open questions](../../A5/output/finding.md#open-questions) | MED |
| 14 | Should `/resume` threaded mode expose stronger diagnostics when canonical parent-link matching fails (issue [#3364](https://github.com/badlogic/pi-mono/issues/3364))? | [A5#Open questions](../../A5/output/finding.md#open-questions) | LOW |
| 15 | Is the upstream `./hooks` export in `package.json` a long-term contract or transitional? Affects extension authors picking a stable surface. | [B1#Open questions](../../B1/output/finding.md#open-questions) | MED |
| 16 | Should mutable `tool_call` arg handlers gain optional post-mutation validation guardrails to make policy extensions safer? | [B1#Open questions](../../B1/output/finding.md#open-questions), [C3#Gotchas](../../C3/output/finding.md#gotchas--surprises) | MED |
| 17 | How stable is extension ordering semantics across releases for conflict cases (same command name, same shortcut, same tool override)? | [B1#Open questions](../../B1/output/finding.md#open-questions) | MED |
| 18 | Where is the unified precedence matrix covering skills + prompts + themes together? Project>user>package is enforced for skills only by regression test. | [B2#Open questions](../../B2/output/finding.md#open-questions) | MED |
| 19 | What is pi's behavior parity with Claude-only skill frontmatter (`context`, `agent`, `hooks`, `paths`)? Cross-harness compat is documented but not mapped. | [B2#Open questions](../../B2/output/finding.md#open-questions) | MED |
| 20 | What is the schema of `SessionStats` returned by RPC `get_session_stats`? Outside C2 slice but needed for fleet cost aggregation. | [C2#Open questions](../../C2/output/finding.md#open-questions) | **HIGH** |

---

## Bucket 2 — pi.dev ecosystem (unmapped)

| # | Question | Raised by | Cost |
|---|---|---|---|
| 21 | Which namespaces beyond `@mariozechner/*` should be treated as "officially supported" for production adoption (`@oh-my-pi/`, `@helios-agent/`, etc.)? | [B3#Open questions](../../B3/output/finding.md#open-questions) | MED |
| 22 | Should GitHub topic metadata be normalized (hard-required `pi-extension` topic + badge) to reduce discovery noise — `topic:pi-coding-agent` overlaps `topic:pi-extension`? | [B3#Open questions](../../B3/output/finding.md#open-questions) | LOW |
| 23 | Is there a canonical "awesome-pi for pi.dev" list, or should the project publish one to disambiguate from Raspberry Pi / Sonic Pi? Current `awesome-pi` search returns 14k mostly-unrelated hits. | [B3#Open questions](../../B3/output/finding.md#open-questions) | LOW |
| 24 | Should ecosystem-counting scripts default to strict regex (`^@mariozechner/`, `^@oh-my-pi/`, `\bpi-(extension\|skill)\b`) to avoid inflated metrics from fuzzy npm search? | [B3#Open questions](../../B3/output/finding.md#open-questions) | LOW |
| 25 | Tighter discoverability metadata for skill packages — many `pi-package`-keyworded npm entries are mixed-purpose repos with low signal. | [B2#Open questions](../../B2/output/finding.md#open-questions) | LOW |
| 26 | Which power-user workflows persist >3 months vs being HN/Show-HN spike experiments? | [B4#Open questions](../../B4/output/finding.md#open-questions) | MED |
| 27 | What is the stable "minimum safe profile" that retains pi velocity while reducing destructive-command risk? Today everyone retrofits sandboxing. | [B4#Open questions](../../B4/output/finding.md#open-questions), [B4#Gotchas](../../B4/output/finding.md#gotchas--surprises) | **HIGH** |
| 28 | What share of serious teams use embedded pi SDK (OpenClaw model) vs CLI + extensions? Affects whether redesign should target SDK or process boundary. | [B4#Open questions](../../B4/output/finding.md#open-questions) | MED |
| 29 | After the April 8 2026 governance/repo move to Earendil, which enterprise-only features materially affect OSS users? Could break hardcoded package refs in port plans. | [B4#Open questions](../../B4/output/finding.md#open-questions), [C3#Gotchas](../../C3/output/finding.md#gotchas--surprises) | **HIGH** |
| 30 | How should B5-style synthesis treat Cloudflare-protected review-aggregator domains — exclude or low-confidence-only? Affects reproducibility of competitive comparison. | [B5#Open questions](../../B5/output/finding.md#open-questions) | LOW |
| 31 | Do we want separate competitive rankings for `solo dev` vs `regulated enterprise` vs `CI-first headless`? Today's sources mix personas. | [B5#Open questions](../../B5/output/finding.md#open-questions) | MED |
| 32 | Should comparison weighting favor terminal-native extensibility (pi's strongest axis) even when benchmark literature under-represents it? | [B5#Open questions](../../B5/output/finding.md#open-questions) | LOW |

---

## Bucket 3 — portability gaps

| # | Question | Raised by | Cost |
|---|---|---|---|
| 33 | Does `build_inner_cmd` already have enough extensibility to add `provider=pi` without changing call sites in all four launchers, or will new options/events force script changes everywhere? | [C1#Open questions](../../C1/output/finding.md#open-questions) | **HIGH** |
| 34 | Should `relaunch-worker.sh` be migrated to `build_inner_cmd` first, eliminating the hardcoded Claude path before any pi integration? | [C1#Open questions](../../C1/output/finding.md#open-questions) | **HIGH** |
| 35 | Which canonical terminal/cost event schema should fleet standardize on — Claude `result` vs Codex `turn.completed` — to drop per-provider conditionals? | [C1#Open questions](../../C1/output/finding.md#open-questions) | **HIGH** |
| 36 | How should pi's lack of a CLI cwd flag be papered over for worktree-fleet (each worker is cwd-pinned to its worktree)? RPC embed vs `cd` wrapper vs upstream PR. | [C2#Gotchas](../../C2/output/finding.md#gotchas--surprises), [C3#Gotchas](../../C3/output/finding.md#gotchas--surprises) | **HIGH** |
| 37 | What is the stable contract for autoresearch's search-mode escalation under pi (today: `sed`-based mutation of `claude -p` for `--tools default`, `-c web_search="live"` for codex)? | [C1#Building blocks](../../C1/output/finding.md#building-blocks--concepts), [C1#Gotchas](../../C1/output/finding.md#gotchas--surprises) | MED |
| 38 | How does iterative-fleet's replay-from-`.worker-cmd-*.sh` handle the quoting/substitution fragility a pi adapter introduces? | [C1#Gotchas](../../C1/output/finding.md#gotchas--surprises) | MED |

---

## Bucket 4 — redesign uncertainties (feeds S5)

| # | Question | Raised by | Cost |
|---|---|---|---|
| 39 | Should the first migration milestone be "`provider=pi` adapter only" across all fleet launchers before any extension-native control-plane work? Lowest risk, highest immediate leverage. | [C3#Open questions](../../C3/output/finding.md#open-questions) | **HIGH** |
| 40 | Can `iterative-fleet` reviewer verdicts be made branch-native via session entries, or is file-based `iterations/N/review.md` required for operator auditability? | [C3#Open questions](../../C3/output/finding.md#open-questions) | MED |
| 41 | For `doc`, can session-tree IDs become the canonical sequence key, or must script-level numbering remain after extensionization? | [C3#Open questions](../../C3/output/finding.md#open-questions) | MED |
| 42 | Worker briefs in plan 02/03 reference stale paths (`packages/api`, `src/extensions`, `src/providers`) that no longer exist; should plan 05 be updated before next research round to prevent worker drift? | [A4#Open questions](../../A4/output/finding.md#open-questions), [C2#Gotchas](../../C2/output/finding.md#gotchas--surprises), [C3#Gotchas](../../C3/output/finding.md#gotchas--surprises) | **HIGH** |
| 43 | Worker self-critique pattern: most A/B/C workers cannot reach the 30-unique-web-domain health floor without violating MECE. Should plan 05 lower the floor for code-heavy slices, or accept asymmetric targets? | [A2#Open questions](../../A2/output/finding.md#open-questions), [A3#Open questions](../../A3/output/finding.md#open-questions), [A5#Open questions](../../A5/output/finding.md#open-questions), [C1#Open questions](../../C1/output/finding.md#open-questions), [C3#Open questions](../../C3/output/finding.md#open-questions) | MED |

---

## Bucket 5 — Contradictions between workers

Surfaced, not smoothed. Each is a real divergence the next round must resolve.

### C-1: "no built-in subagents" vs first-party subagent extension
- [B1#Gotchas](../../B1/output/finding.md#gotchas--surprises) and [B1#Building blocks](../../B1/output/finding.md#building-blocks--concepts) — `examples/extensions/subagent/` ships first-party, implements subagents via `pi --mode json --no-session` subprocesses.
- [B4#Gotchas](../../B4/output/finding.md#gotchas--surprises) (contradiction 3) — maintainer narrative is "no built-in subagents/plan mode," yet community recreates orchestration in userland.
- [C3#Building blocks](../../C3/output/finding.md#building-blocks--concepts) — "maintainer philosophy constraint" — redesign should prefer extensions over core.
- **Resolution needed:** is this a *capability denial* or a *packaging boundary*? Affects whether fleet can ship as an extension and expect upstream stability.

### C-2: OSS = lower lock-in vs heavy embedded SDK creates de-facto coupling
- [B5#Summary](../../B5/output/finding.md#summary) — "lock-in cost is lowest for open-source terminal tools (aider, pi, Codex CLI OSS client)."
- [B5#Gotchas](../../B5/output/finding.md#gotchas--surprises) (contradiction 4) — teams self-lock via proprietary APIs / model aliases / workflow conventions even with OSS CLIs.
- [B4#Gotchas](../../B4/output/finding.md#gotchas--surprises) (contradiction 5) — OpenClaw embeds pi as SDK runtime, not CLI; that is structural lock-in to pi's session/event model.
- **Resolution needed:** distinguish license lock-in from interface lock-in for synthesis ranking.

### C-3: 25 providers vs 10 API adapters
- [A4#Code refs](../../A4/output/finding.md#code-refs) — `models.generated.ts` lists 25 top-level providers.
- [A4#Gotchas](../../A4/output/finding.md#gotchas--surprises) — only 10 API adapters; the rest are OpenAI/Anthropic/Google compat overlays.
- **Resolution needed:** which number is the honest "provider breadth" claim for S2/S3?

### C-4: stale source paths across worker briefs (meta-contradiction)
- [A4#Gotchas](../../A4/output/finding.md#gotchas--surprises) — `packages/api` is now `packages/ai`; `coding-agent/src/providers` doesn't exist.
- [C2#Gotchas](../../C2/output/finding.md#gotchas--surprises) — same `packages/ai` rename.
- [C3#Gotchas](../../C3/output/finding.md#gotchas--surprises) — `src/extensions|hooks|skills` in brief, but actual layout is `src/core/extensions` + `src/core/skills.ts`.
- **Resolution needed:** plan 05 brief paths must be regenerated against current `pi-mono` checkout before the next round (see Q42).

### C-5: JSONL framing portability
- [A3#Building blocks](../../A3/output/finding.md#building-blocks--concepts) — strict LF-only framing; U+2028/U+2029 valid inside payload.
- [A3#Gotchas](../../A3/output/finding.md#gotchas--surprises) — official docs warn against `readline`, but Polpo (a real client) uses it.
- [C2#Building blocks](../../C2/output/finding.md#building-blocks--concepts) — confirms strict framing, but C1 fleet scripts use `tail -1 | jq -r .type`, also potentially fragile.
- **Resolution needed:** is the framing contract already broken in the wild, or is the LF-only invariant still safe to bet on for fleet?

### C-6: skill-collision philosophy mismatch
- [B2#Gotchas](../../B2/output/finding.md#gotchas--surprises) — pi: first-seen-wins + diagnostics, no plugin namespace.
- [B2#Building blocks](../../B2/output/finding.md#building-blocks--concepts) — Claude Code: explicit precedence (enterprise/personal/project/plugin) + `plugin-name:skill-name` namespace.
- **Resolution needed:** if fleet ships skills cross-harness, which collision model wins when both are present? Matters for B2's Claude→pi compat story.

### C-7: bash exit semantics — safety vs ergonomics
- [A2#Gotchas](../../A2/output/finding.md#gotchas--surprises) — every non-zero exit is a tool error; collides with `grep/diff/test` whose non-zero is meaningful, not failure.
- [A2#Open questions](../../A2/output/finding.md#open-questions) (Q4 above) proposes configurable allowlist.
- **Resolution needed:** does the fleet adapter need to rewrite/suppress these errors, or is upstream willing to change the contract?

---

## Coverage map (lossless check)

Every worker's "Open questions" section was harvested:

| Worker | Cited above? |
|---|---|
| A1 | ✅ Q1 of bucket-1 covers install guardrail/clean-room flags ([A1#Open questions](../../A1/output/finding.md#open-questions) — install retry policy and clean-room first-run profile, captured in this index by reference; not separately tabled because both are S2/S5 concerns rather than next-round research targets) |
| A2 | ✅ Q4, Q5, Q6 |
| A3 | ✅ Q2, Q7 |
| A4 | ✅ Q8, Q9, Q10, Q42 |
| A5 | ✅ Q11, Q12, Q13, Q14 |
| B1 | ✅ Q15, Q16, Q17 |
| B2 | ✅ Q18, Q19, Q25 |
| B3 | ✅ Q21, Q22, Q23, Q24 |
| B4 | ✅ Q26, Q27, Q28, Q29 |
| B5 | ✅ Q30, Q31, Q32 |
| C1 | ✅ Q33, Q34, Q35 |
| C2 | ✅ Q1, Q3, Q20, Q42 |
| C3 | ✅ Q39, Q40, Q41, Q42 |

A1's two questions are the only ones not assigned a numbered row above; they are S2-bound (beginner onboarding) rather than next-experiment research items, so they are linked but not tabled. All others retained verbatim with attribution.

---

## What this doc does NOT cover

- **Beginner onboarding ("start here", install/first-run/core tools)** → see **S2** `pi-beginner-onboarding`. A1's install-guardrail and clean-room-profile questions live there as recommendations, not as open research.
- **Power-user named recipes** → see **S3** `pi-power-workflow-recipes`.
- **Per-skill portability verdicts (does each fleet skill run on pi today?)** → see **S4** `pi-portability-verdict`. Bucket 3 questions inform but don't replace S4's punch list.
- **Per-skill keep-bash / port-to-extension / hybrid verdicts + effort** → see **S5** `pi-native-redesign-roadmap`. Bucket 4 questions feed S5 directly but S5 owns the verdicts.
- **Index/landing page over all 13 raw findings** → see **S1** `pi-knowledge-index`.
- **Raw worker findings** — not summarized here; always link via `../../<id>/output/finding.md`.
