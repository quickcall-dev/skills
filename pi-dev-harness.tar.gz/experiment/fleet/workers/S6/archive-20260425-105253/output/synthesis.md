---
title: "pi-open-questions"
experiment: 004-pi-dev-harness
audience: "next-experiment planner"
synth_doc: S6
created: "2026-04-25"
---

## TL;DR

Across 12 of 13 worker findings (C3 produced no `finding.md` — see [Coverage gaps](#coverage-gaps)), open questions cluster into 5 buckets: pi.dev internals still unverified at runtime, ecosystem boundaries that workers couldn't enumerate without violating MECE, portability gaps for the bash fleet, redesign uncertainties (largely unanswered because C3 is missing), and a small set of cross-worker contradictions. Highest-cost unknowns: the canonical terminal/cost event schema (`result` vs `turn.completed`) for fleet integration ([C1](#bucket-3--portability-gaps)); whether `AgentSessionEvent` per-turn usage shape is fleet-stable ([C2](#bucket-3--portability-gaps)); and whether the `tree`/`resume` state-restore drift is one-bug-many-symptoms or independent issues ([A5](#bucket-1--pidev-internals-unanswered)). Ranked lists below.

---

## Coverage gaps

- **C3 (native redesign) — no `finding.md` on disk.** Worker dir has `prompt.md`, `.done`, `session.jsonl`, but `output/finding.md` is absent. Bucket 4 (redesign uncertainties) is therefore unsourced from C3 itself; questions in that bucket are inferred from C1/C2 cross-refs that explicitly defer to C3.
- All other 12 workers (A1–A5, B1–B5, C1, C2) contributed an `## Open questions` section — harvested verbatim below as link targets.

---

## Bucket 1 — pi.dev internals (unanswered)

Ranked by cost-of-not-knowing for downstream skill work.

| # | Question | Source | Why it matters |
|---|---|---|---|
| 1 | Should `/tree` and `/resume` share one authoritative "state restore" function for model/thinking restoration? Drift visible in [pi-mono#3544](https://github.com/badlogic/pi-mono/issues/3544). | [A5#open-questions](../../A5/output/finding.md#open-questions) | Session-resume reliability is load-bearing for any iterative-fleet port. |
| 2 | Is `SessionManager.continueRecent(cwd, ...)` expected to favor session-header cwd over launch cwd in non-interactive + RPC ([#3249](https://github.com/badlogic/pi-mono/issues/3249))? | [A5#open-questions](../../A5/output/finding.md#open-questions) | RPC fleet workers run with non-trivial cwd; wrong choice = wrong session resumed. |
| 3 | Should `bash` tool expose configurable non-zero exit allowlists (grep/diff/test exit code 1) instead of blanket error conversion? | [A2#open-questions](../../A2/output/finding.md#open-questions) | Affects every bash-driven fleet check; current behavior may falsely fail workers. |
| 4 | Should provider/API registration be runtime-introspectable (active adapters + compat flags) so `/model` + diagnostics can explain normalization deterministically? | [A4#open-questions](../../A4/output/finding.md#open-questions) | Without this, multi-provider cost accounting in fleet is opaque. |
| 5 | Should synthetic tool-result insertion be toggleable for strict replay/debug modes? | [A4#open-questions](../../A4/output/finding.md#open-questions) | Replay determinism for fleet reviewer workers. |
| 6 | Should cost logic support provider-native pricing variants beyond static per-1M token tables? | [A4#open-questions](../../A4/output/finding.md#open-questions) | Static tables drift; budget caps in fleets become inaccurate. |
| 7 | Should pi adopt optional hash-anchor edit mode (hashline-style) for weaker models, keeping exact mode default? | [A2#open-questions](../../A2/output/finding.md#open-questions) | Edit-tool reliability on Haiku-class models in fleets. |
| 8 | Should pi expose an atomic multi-file edit transaction primitive (not just per-file mutation queue)? | [A2#open-questions](../../A2/output/finding.md#open-questions) | Worktree-fleet merge safety. |
| 9 | Should `_branchSummaryAbortController` lifecycle be wrapped in `try/finally` in `navigateTree()` ([#3688](https://github.com/badlogic/pi-mono/issues/3688))? | [A5#open-questions](../../A5/output/finding.md#open-questions) | Resource leak under tree navigation in long-running RPC sessions. |
| 10 | Should `/resume` threaded mode expose stronger diagnostics when parent links fail canonical matching ([#3364](https://github.com/badlogic/pi-mono/issues/3364))? | [A5#open-questions](../../A5/output/finding.md#open-questions) | Debuggability when fleet workers fail to resume. |
| 11 | Is `./hooks` export in upstream `package.json` intentionally long-term-supported, or transitional? | [B1#open-questions](../../B1/output/finding.md#open-questions) | Skills that import hooks risk breaking on minor upgrade. |
| 12 | Should mutable `tool_call` args support post-mutation validation guardrails for safer policy extensions? | [B1#open-questions](../../B1/output/finding.md#open-questions) | Security review of extension-based policy enforcement. |
| 13 | How stable is extension ordering for conflict cases (same command/shortcut/tool override) across releases? | [B1#open-questions](../../B1/output/finding.md#open-questions) | Determines whether fleet-relevant extensions are safe to ship. |
| 14 | Should strict JSONL framing be enforced by schema/version handshake at RPC startup? | [A3#open-questions](../../A3/output/finding.md#open-questions) | Silent client incompat = silent fleet corruption. |
| 15 | Should RPC add an explicit `get_capabilities` packet, or stay with implicit `get_state`/`get_commands`? | [A3#open-questions](../../A3/output/finding.md#open-questions) | Negotiation matters for mixed-version fleet workers. |
| 16 | Should upstream publish JSON schema artifacts / conformance tests for tool/result event shapes (third-party wrappers like Polpo use custom field names)? | [A3#open-questions](../../A3/output/finding.md#open-questions) | C1 fleet integration depends on this stability. |

## Bucket 2 — pi.dev ecosystem (unmapped)

| # | Question | Source | Why it matters |
|---|---|---|---|
| 1 | Which power-user workflows persist >3 months versus HN "Show HN" hype-cycle spikes? | [B4#open-questions](../../B4/output/finding.md#open-questions) | Drives S3 (power workflow recipes) durability claims. |
| 2 | How many serious teams use embedded pi SDK (OpenClaw-style) vs pure CLI + extension model? | [B4#open-questions](../../B4/output/finding.md#open-questions) | Determines whether fleet should support SDK embedding path. |
| 3 | What is the stable "minimum safe profile" that retains pi velocity but reduces destructive command risk? | [B4#open-questions](../../B4/output/finding.md#open-questions) | Profile recommendation for fleet defaults. |
| 4 | After April 8, 2026 governance changes, which enterprise-only features materially affect OSS users? | [B4#open-questions](../../B4/output/finding.md#open-questions) | OSS-fleet roadmap risk. |
| 5 | Which namespaces should be considered "officially supported" beyond `@mariozechner/*` for production adoption? | [B3#open-questions](../../B3/output/finding.md#open-questions) | Catalog trust boundary for fleet's package allowlist. |
| 6 | Is there a canonical "awesome-pi for pi.dev" list, or should the project publish one (to disambiguate from Raspberry Pi / Sonic Pi)? | [B3#open-questions](../../B3/output/finding.md#open-questions) | Discovery friction for skill maintainers. |
| 7 | Should topic metadata be normalized (hard requirement for `pi-extension` topic + badge) to reduce GH discovery noise? | [B3#open-questions](../../B3/output/finding.md#open-questions) | Search-quality input for fleet's package picker. |
| 8 | Should package-discovery scripts use strict regex filters (`^@mariozechner/`, `^@oh-my-pi/`, `\bpi-(extension|skill)\b`) by default? | [B3#open-questions](../../B3/output/finding.md#open-questions) | Avoids inflated ecosystem metrics in adoption decisions. |
| 9 | Should pi adopt a single authoritative precedence matrix covering skills + prompts + themes (project/user/package)? | [B2#open-questions](../../B2/output/finding.md#open-questions) | Currently spread across docs + regression tests; fleet authors guess. |
| 10 | What is the runtime quality + safety posture of third-party skill packages (none were executed in B2's pass)? | [B2#open-questions](../../B2/output/finding.md#open-questions) | Static-only audit means fleet adopting popular skills is uninformed. |
| 11 | Behavior parity for advanced Claude-only frontmatter (`context`, `agent`, `hooks`, `paths`) under pi — explicitly mapped? | [B2#open-questions](../../B2/output/finding.md#open-questions) | Cross-harness skill portability claims need verification. |
| 12 | Should pi comparison weights emphasize terminal-native extensibility even when benchmark literature under-represents it vs commercial tools? | [B5#open-questions](../../B5/output/finding.md#open-questions) | Comparison-doc framing decision. |
| 13 | Do we want separate rankings for solo-dev / regulated-enterprise / CI-first headless personas? | [B5#open-questions](../../B5/output/finding.md#open-questions) | Single ranking conflates personas. |
| 14 | For lock-in-cost scoring, do we want a fixed rubric (migration hours, config portability, CI portability, policy portability)? | [B5#open-questions](../../B5/output/finding.md#open-questions) | Normalization across future B5-style passes. |

## Bucket 3 — portability gaps

Direct blockers for porting the bash fleet skill set onto pi.

| # | Question | Source | Why it matters |
|---|---|---|---|
| 1 | Which canonical terminal/cost event schema should the fleet standardize on (`result` vs `turn.completed`) to avoid per-provider conditionals? | [C1#open-questions](../../C1/output/finding.md#open-questions) | This is the single highest-leverage portability decision; affects every launcher. |
| 2 | Does `build_inner_cmd` already have enough extensibility to add `provider=pi` without changing call sites in all four launchers? | [C1#open-questions](../../C1/output/finding.md#open-questions) | Determines port cost: helper-only edit vs four-file fan-out. |
| 3 | Should `relaunch-worker.sh` migrate to `build_inner_cmd` first to eliminate the hardcoded Claude path before any pi integration? | [C1#open-questions](../../C1/output/finding.md#open-questions) | Sequencing: tech-debt cleanup before port, or after. |
| 4 | What are the exact top-level event field names for per-turn usage in `AgentSessionEvent`? Usage shape is clear at `AssistantMessage.usage`, but event-wrapping types live outside C2's source slice. | [C2#open-questions](../../C2/output/finding.md#open-questions) | Cost-aggregation parity with Claude/Codex paths. |
| 5 | Does the CLI support hidden cwd override flags not shown in `--help`? | [C2#open-questions](../../C2/output/finding.md#open-questions) | Worktree-fleet correctness depends on cwd injection contract. |
| 6 | What is the `get_session_stats` / `SessionStats` return schema? Imported from a core module outside C2's slice. | [C2#open-questions](../../C2/output/finding.md#open-questions) | Required for `iterative-fleet` budget caps. |
| 7 | What is the exact final `claude/codex/pi` command emitted by `lib/worker-spawn.sh` (excluded from C1 source list)? | [C1#open-questions](../../C1/output/finding.md#open-questions) | Ground-truth gap in C1's audit. |

## Bucket 4 — redesign uncertainties

C3 produced no finding, so this bucket is sourced from cross-refs in C1/C2 that explicitly hand off to C3. Treat all entries as **unanswered, source-missing**.

| # | Question | Source (deferred to C3) | Why it matters |
|---|---|---|---|
| 1 | Architecture choice: bash port vs pi-native RPC/extension redesign for fleet — which path? | [C1#cross-refs](../../C1/output/finding.md#cross-refs) | Top-level redesign decision; gates all S5 work. |
| 2 | Should tmux orchestration be replaced by pi-native session/RPC primitives, or kept? | [C1#cross-refs](../../C1/output/finding.md#cross-refs) | Determines whether persistence guarantees survive port. |
| 3 | Should hook-based control loops be replaced by pi extension lifecycle? | [C1#cross-refs](../../C1/output/finding.md#cross-refs) | Affects every fleet that uses hooks (dag-fleet, iterative-fleet). |
| 4 | SDK embedding (`AgentSession`) vs cross-process RPC isolation — which selection criteria for fleet workers? | [A3#open-questions](../../A3/output/finding.md#open-questions) | A3 explicitly notes a missing "selection matrix" in docs for reliability/security tradeoffs. |
| 5 | "Clean-room first run" profile (`--no-context-files --no-session --no-extensions`) — should it be the default fleet-worker bootstrap? | [A1#open-questions](../../A1/output/finding.md#open-questions) | Fleet-worker reproducibility. |
| 6 | Install guardrail recommendation for publish-race failures (retry policy, pinning, fallback version command) ([#3280](https://github.com/badlogic/pi-mono/issues/3280))? | [A1#open-questions](../../A1/output/finding.md#open-questions) | CI fleets fail intermittently on npm publish races. |

## Bucket 5 — contradictions between workers

Three cross-worker tensions surfaced. None are direct factual conflicts; all are unresolved scope/recommendation tensions that S5/S4 must reconcile.

| # | Tension | Workers | Resolution path |
|---|---|---|---|
| 1 | **SDK-embed vs RPC-isolation as the recommended fleet integration**. A3 nudges Node users toward embedding `AgentSession` per docs but flags that "cross-process isolation and fault containment are better with RPC" — an unresolved tradeoff inside one worker. C1 implicitly assumes RPC/CLI for the bash-port path. B4 separately asks how many "serious teams" actually use SDK-embed. | [A3#open-questions](../../A3/output/finding.md#open-questions) ↔ [C1#open-questions](../../C1/output/finding.md#open-questions) ↔ [B4#open-questions](../../B4/output/finding.md#open-questions) | S5 must pick a default + document the escape hatch. |
| 2 | **Cost-event schema source-of-truth**. C1 frames the choice as `result` vs `turn.completed`. C2 reports the per-turn usage shape lives at `AssistantMessage.usage` but the event-wrapper types are outside its slice. A4 separately asks whether cost logic should move beyond static per-1M tables. Three workers point at adjacent pieces of the same accounting story without anyone owning end-to-end. | [C1#open-questions](../../C1/output/finding.md#open-questions) ↔ [C2#open-questions](../../C2/output/finding.md#open-questions) ↔ [A4#open-questions](../../A4/output/finding.md#open-questions) | Follow-up worker should own cost-event schema E2E. |
| 3 | **Extension stability claims**. B1 flags ordering semantics for conflict cases as unstable across releases AND asks whether `./hooks` export is transitional. B2 builds on extensions/skills as if precedence is well-defined (regression tests cited) yet asks for an authoritative matrix. C1's `relaunch-worker.sh` audit assumes hooks are stable enough to depend on for fleet control. | [B1#open-questions](../../B1/output/finding.md#open-questions) ↔ [B2#open-questions](../../B2/output/finding.md#open-questions) ↔ [C1#open-questions](../../C1/output/finding.md#open-questions) | S4 punch list must downgrade hook-based fleet features pending B1 resolution. |

Additionally, several workers self-flagged **health-target tension** (could not hit ≥30 unique web domains without violating MECE source partition): [A5](../../A5/output/finding.md#open-questions), [A2](../../A2/output/finding.md#open-questions), [A3](../../A3/output/finding.md#open-questions), [C1](../../C1/output/finding.md#open-questions). Not a contradiction between workers — a contradiction between fleet-plan health targets and fleet-plan source partition. Flagged for next-experiment planner: **either relax the 30-domain floor for code-heavy slices, or widen MECE partitions to allow commentary domains**.

---

## Source map

Every finding's `## Open questions` section was harvested verbatim and linked above. C3 has no finding (see [Coverage gaps](#coverage-gaps)). Sources.md siblings were sampled for breadth weighting but not cited individually — exploration breadth informed bucket ranking only, not specific claims.

Worker findings cited:
- [A1](../../A1/output/finding.md), [A2](../../A2/output/finding.md), [A3](../../A3/output/finding.md), [A4](../../A4/output/finding.md), [A5](../../A5/output/finding.md)
- [B1](../../B1/output/finding.md), [B2](../../B2/output/finding.md), [B3](../../B3/output/finding.md), [B4](../../B4/output/finding.md), [B5](../../B5/output/finding.md)
- [C1](../../C1/output/finding.md), [C2](../../C2/output/finding.md)
- C3 — no finding produced

---

## What this doc does NOT cover

- **First-run onboarding answers** (install, auth, first session) → [S2 pi-beginner-onboarding](../../S2/output/synthesis.md).
- **Power-user recipe answers** (named workflows, headless review, multi-provider cost opt) → S3 `pi-power-workflow-recipes`.
- **Bash-fleet portability verdicts** (per-skill punch list of what works today) → S4 `pi-portability-verdict`. This doc only surfaces the *unknowns* that block S4.
- **Native-redesign verdicts** (keep-bash / port / hybrid + effort estimate per skill) → S5 `pi-native-redesign-roadmap`. Bucket 4 here is the question list S5 must answer; the answers themselves belong in S5.
- **Navigation index** linking all synthesis docs + raw findings → S1 `pi-knowledge-index`.
- **The verbatim text of each worker's open-questions section** stays in the worker findings under `workers/{ID}/output/finding.md` — this doc clusters and ranks them, never replaces them.
