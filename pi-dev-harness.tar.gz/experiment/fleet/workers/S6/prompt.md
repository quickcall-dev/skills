# Worker S6 — open questions harvest (synthesis)

You are a synthesis worker. Inputs = upstream worker findings on disk. Output = one synthesis doc + sibling pointers.

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/04-synthesis-multi-doc.md` — it defines the lossless-merge contract you MUST follow.

## Input findings (read these — verbatim from worker output)

All 13 worker findings — specifically each one's '## Open questions' section:
- $FLEET_ROOT/workers/{A1..A5,B1..B5,C1..C3}/output/finding.md

Also read each input's sibling `sources.md` to understand exploration breadth (helps you weigh confidence).

## Audience

Future-experiment planner. Wants the unknowns clustered for the next research round.

## Required structure

Buckets:
- pi.dev internals (unanswered)
- pi.dev ecosystem (unmapped)
- portability gaps
- redesign uncertainties
- contradictions between workers (cross-ref)
Each bucket = a list of crisp questions, each tagged with which worker(s) raised it. Rank by 'cost of not knowing'.

## Mandatory rules (per plan 04)

- NO concatenation. Link to source findings, do not paste.
- NO replacing a finding with its summary inline — link instead.
- NO dropping "Open questions" / "Gotchas" — those feed sibling synth doc S6.
- NO smoothing contradictions. Surface them with a "Contradictions" subsection.
- Tables stay tables.
- End with: "## What this doc does NOT cover" — point to sibling synth docs (S1-S6) that handle the excluded scope.

## Citation form

Cite worker findings as `[A2#Building blocks](../../A2/output/finding.md#building-blocks--concepts)` — relative paths from your output dir.

## Health targets (synth-tier)

- 100% finding coverage (every relevant input cited or explicitly excluded with reason)
- ≥3 cross-finding contradictions surfaced (or "no contradictions found, here's why")
- ≥5 actionable items (S4/S5 only)
- 0 lossy summaries

## Deliverable

`$FLEET_ROOT/workers/S6/output/synthesis.md`

Save ALL output files to `$FLEET_ROOT/workers/S6/output/` — use absolute paths.
