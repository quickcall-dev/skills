## Summary
- pi’s built-in `read`/`write`/`edit`/`bash` tools are strict, typed wrappers with explicit truncation and abort semantics, and they now share extension-style pluggable backends instead of hardcoded local-only behavior (`read.ts`, `write.ts`, `edit.ts`, `bash.ts`). [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:33] [/tmp/pi-mono/packages/coding-agent/src/core/tools/write.ts:25] [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:70] [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:49] [#3553](https://github.com/badlogic/pi-mono/issues/3553) [#235b247](https://github.com/badlogic/pi-mono/commit/235b247f1f09dd177062e2f9ce0d6983e1876c6d)
- `edit` in pi is still exact-text replacement first (with multi-edit and better arg coercion), unlike hash-anchored edit families (oh-my-pi hashline) and unlike Anthropic’s built-in text editor API shape (`str_replace_based_edit_tool`). [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:31] [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:42] [#3370](https://github.com/badlogic/pi-mono/pull/3370) [oh-my-pi hashline](https://github.com/can1357/oh-my-pi/blob/main/packages/coding-agent/src/edit/modes/hashline.ts) [Anthropic text editor tool docs](https://docs.anthropic.com/en/docs/agents-and-tools/tool-use/text-editor-tool)
- `bash` is intentionally tail-truncated + temp-file backed and process-tree aware, but non-zero exit handling and shell-path/config drift have been recurring operational pain points in issues. [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:247] [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:381] [#3509](https://github.com/badlogic/pi-mono/issues/3509) [#3521](https://github.com/badlogic/pi-mono/issues/3521) [#2852](https://github.com/badlogic/pi-mono/issues/2852) [#2389](https://github.com/badlogic/pi-mono/pull/2389)

## Building blocks / concepts
- `Read path + bounded payload`: `read` resolves path within cwd constraints and bounds text by line/byte limits with continuation hints (`offset`, `limit`). [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:141] [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:216]
- `Read image branch`: image MIME detection routes to attachment mode; optional resize and non-vision model warning text prevent silent loss. [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:160] [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:168] [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:81] [#3429](https://github.com/badlogic/pi-mono/issues/3429) [#2055](https://github.com/badlogic/pi-mono/issues/2055)
- `Write is overwrite + mkdir`: `write` always creates parent dirs and overwrites target file content, serialized through a file mutation queue. [/tmp/pi-mono/packages/coding-agent/src/core/tools/write.ts:190] [/tmp/pi-mono/packages/coding-agent/src/core/tools/write.ts:203]
- `Edit = exact replacement set`: `edit` expects `edits[]` replacements against original file text, with overlap constraints and one-call multi-edit preference. [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:45] [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:297] [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:302]
- `Edit compatibility layer`: argument prep normalizes legacy `oldText/newText` and stringified `edits` before validation, reducing model/tool mismatch failures. [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:90] [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:97] [#2639](https://github.com/badlogic/pi-mono/issues/2639) [#3370](https://github.com/badlogic/pi-mono/pull/3370)
- `Bash local backend`: `bash` executes through shell config, streams stdout/stderr, supports timeout/abort, and uses rolling-tail truncation with optional persisted full output. [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:75] [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:100] [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:313] [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:364]

## Code refs
- Read schema and parameter contract: `/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:17-21` (path, offset, limit).
- Read truncation continuation UX: `/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:229-233`.
- Read first-line-too-large fallback to `sed`: `/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:219-223`.
- Write overwrite semantics + mkdir: `/tmp/pi-mono/packages/coding-agent/src/core/tools/write.ts:190-224`.
- Edit strict input validation (`edits` required): `/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:116-120`.
- Edit BOM/line-ending preservation: `/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:366-382`.
- Edit preview diff lifecycle in TUI: `/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:432-443` and `:445-480`.
- Bash timeout/abort kill process tree: `/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:94-109`.
- Bash truncation + full output path notices: `/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:366-379`.
- Bash non-zero exit as error behavior: `/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:381-384`.
- Recent behavior-shaping threads: [#3509](https://github.com/badlogic/pi-mono/issues/3509), [#3521](https://github.com/badlogic/pi-mono/issues/3521), [#3554](https://github.com/badlogic/pi-mono/issues/3554), [#3672](https://github.com/badlogic/pi-mono/issues/3672), [#2852](https://github.com/badlogic/pi-mono/issues/2852), [#3134](https://github.com/badlogic/pi-mono/issues/3134).

## Examples
```json
{
  "tool": "read",
  "arguments": {"path": "src/main.ts", "offset": 1, "limit": 200}
}
```
Uses bounded read slices and explicit continuation via increasing `offset`. [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:199] [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:235]

```json
{
  "tool": "edit",
  "arguments": {
    "path": "src/main.ts",
    "edits": [
      {"oldText": "const a = 1;", "newText": "const a = 2;"},
      {"oldText": "return a;", "newText": "return a + 1;"}
    ]
  }
}
```
Multi-edit in one call is preferred vs many single edits; matches are against original content. [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:47] [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:303]

```json
{
  "tool": "bash",
  "arguments": {"command": "npm test", "timeout": 120}
}
```
Timeout is optional; partial streaming uses tail truncation and final output can include full temp-file path on truncation. [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:35] [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:333] [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:368]

```json
{
  "tool": "edit",
  "arguments": {
    "path": "file.ts",
    "edits": "[{\"oldText\":\"x\",\"newText\":\"y\"}]"
  }
}
```
Now coerced from stringified JSON in `prepareArguments` before schema validation. [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:97] [#3370](https://github.com/badlogic/pi-mono/pull/3370)

## Gotchas / surprises
- `bash` marks every non-zero code as tool error, which collides with normal `grep/diff/test` semantics and can mislead agent control flow. [/tmp/pi-mono/packages/coding-agent/src/core/tools/bash.ts:381] [#3509](https://github.com/badlogic/pi-mono/issues/3509)
- `read` can suggest `sed` fallback when first line exceeds byte cap; this pushes the model back into shell-edit patterns the prompt otherwise discourages. [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:220] [/tmp/pi-mono/packages/coding-agent/src/core/tools/read.ts:132]
- `edit` robustness is partly outsourced to preprocessing (`prepareEditArguments`), implying provider/model drift still leaks into tool argument shape. [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:90] [#3370](https://github.com/badlogic/pi-mono/pull/3370)
- Prior fuzzy-match fixes show how easy it is to accidentally mutate untouched text outside intended edits. [#3554](https://github.com/badlogic/pi-mono/issues/3554)
- `bash` truncation correctness required explicit fix for line-truncation-without-byte-threshold case; otherwise “full output” could be missing. [#2852](https://github.com/badlogic/pi-mono/issues/2852)
- Windows shell/path edge cases repeatedly break assumptions (`shellPath`, MinGW mkdir/write path behavior, detached descendants). [#3521](https://github.com/badlogic/pi-mono/issues/3521) [#3672](https://github.com/badlogic/pi-mono/issues/3672) [#2389](https://github.com/badlogic/pi-mono/pull/2389)
- Compared to hashline edits in oh-my-pi, pi’s exact-text mode remains more retry-prone under whitespace/quote drift (though simpler and broadly compatible). [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:297] [oh-my-pi README](https://github.com/can1357/oh-my-pi/blob/main/README.md) [oh-my-pi hashline](https://github.com/can1357/oh-my-pi/blob/main/packages/coding-agent/src/edit/modes/hashline.ts)

## Open questions
- Health target mismatch: with this MECE-constrained slice (pi tool files + pi issues/PRs + small Claude/oh-my-pi compare set), I exceeded 100 sources but cannot honestly reach 30 unique web domains without violating source partition intent.
- Should `bash` expose configurable non-zero exit allowlists (e.g., grep/diff/test code 1) instead of blanket error conversion?
- Should pi adopt optional hash-anchor addressing mode (similar to hashline) for lower-friction edits on weaker models while keeping exact mode as default?
- For read/write/edit parity with Claude-style text editor tooling, should pi expose an atomic multi-file edit transaction primitive, not just per-file mutation queueing?
- Self-critique: issue/PR filtering used keyword heuristics over 300 recent items; deeper historical mining may surface older tool regressions outside this sampled window.

## Cross-refs
- Session tree/branch semantics surfaced repeatedly while tracing tool rendering and result grouping; belongs to A5 (session model). [/tmp/pi-mono/packages/coding-agent/src/core/tools/edit.ts:445]
- Tool execution ordering and sequential groups intersect with run-mode orchestration concerns; belongs to A3 (run modes). [#3345](https://github.com/badlogic/pi-mono/pull/3345)
- Extension override behavior for built-ins (`read`/`bash`/`edit`/`write`) overlaps with B1 extension internals. [#3553](https://github.com/badlogic/pi-mono/issues/3553)
