# Worker A2 — core tools deep-dive

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Read / Write / Edit / Bash semantics in pi.dev. How they compare to Claude Code's equivalents (e.g. hash-anchored edits in oh-my-pi).

## Sources you own (do not touch others')

- `pi-mono/packages/coding-agent/src/tools/` directory: read.ts, write.ts, edit.ts, bash.ts
- Tool-related issues + PRs in pi-mono GitHub

## Out of scope (other workers cover)

- Install/bootstrap (A1)
- Run modes (A3)
- Extensions (B1)

## Source-mix target (per plan 05)

80% source code, 20% docs/issues. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/A2/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/A2/output/` — use absolute paths.
