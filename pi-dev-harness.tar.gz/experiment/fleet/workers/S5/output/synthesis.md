---
title: "pi-native-redesign-roadmap"
synthesis: S5
audience: "skill maintainer (Sagar)"
sources: ["C3", "C2 (peek)"]
created: "2026-04-25"
---

# S5 — pi-native redesign roadmap

## TL;DR

C3 maps all 6 fleet/doc skills to one of `keep-bash` / `port-to-extension` / `hybrid`. Pattern: long-lived multi-worker orchestration stays bash (tmux, git, file state); per-process control + resource discovery moves into pi extensions. Strongest pi-native leverage = `registerCommand` + `resources_discover` + session-tree state. Blocking dependency for every "hybrid" verdict = a `pi` runner adapter that normalizes `--mode rpc` events into fleet's existing terminal/cost schema. Build that adapter first; everything else unblocks behind it. See [C3#Summary](../../C3/output/finding.md).

---

## Per-skill verdict table

Verbatim from [C3 code refs table](../../C3/output/finding.md#code-refs). Do not paraphrase — read source for full citations.

| Skill | Verdict | Why (link) | Dependencies | Effort | Priority |
|---|---|---|---|---|---|
| `dag-fleet` | `hybrid` | tmux+DAG stays external; swap runner internals to pi RPC adapter — [C3 row 1](../../C3/output/finding.md#code-refs) | RPC adapter (P0); [C2 RPC flag map](../../C2/output/finding.md) | 1.5–2.5 wk | P1 (after adapter) |
| `worktree-fleet` | `keep-bash` | git worktree + merge planning belongs outside agent; only spawn path needs `provider=pi` — [C3 row 2](../../C3/output/finding.md#code-refs) | RPC adapter (P0) | 3–5 days | P1 (cheapest win) |
| `iterative-fleet` | `hybrid` | external iteration DAG + reviewer gate semantics into extension via `turn_end`/`agent_end` — [C3 row 3](../../C3/output/finding.md#code-refs) | RPC adapter; reviewer-state design (open Q) | 2–3 wk | P2 |
| `autoresearch-fleet` | `hybrid` | external loop + extensionized plateau/search policy + structured metrics from session stats — [C3 row 4](../../C3/output/finding.md#code-refs) | RPC adapter; metrics schema | 2–3 wk | P3 |
| `fleet-plan` | `port-to-extension` | full port: `registerCommand("/fleet-plan")` + `resources_discover` for templates + prompt templates — [C3 row 5](../../C3/output/finding.md#code-refs) | extension package skeleton; [B2 skills/prompt semantics](../../B2/output/finding.md) | 1–1.5 wk | P2 |
| `doc` | `hybrid` | scripts stay as deterministic file/index backend; add `/doc-*` commands + template discovery + session-tree-aware checkpoints — [C3 row 6](../../C3/output/finding.md#code-refs) | extension skeleton; session-tree ID question | 1–2 wk | P2 |

Total effort range: ~8–13 weeks calendar (single maintainer, sequential). Parallelizable to ~4–5 weeks if RPC adapter lands first and the four hybrid/port tracks proceed independently.

---

## Building blocks (preserve verbatim — link only)

C3 names four redesign planes + one philosophical constraint. Do not summarize away — read [C3#Building blocks](../../C3/output/finding.md#building-blocks--concepts):

- **Execution plane** — RPC/JSON runner adapter normalizes pi events to fleet schema.
- **Control plane** — `registerCommand`, `tool_call`/`tool_result`, session/tree hooks replace shell conditionals.
- **Resource plane** — `resources_discover` + package-distributed `skills/`+`prompts/` ship behavior natively.
- **Session-tree state** — `fork`/`switchSession`/`navigateTree` + persisted custom entries replace iterative directory bookkeeping.
- **Maintainer-philosophy constraint** — pi core stays minimal; redesign MUST be optional extension packages, never core changes.

---

## Dependency graph between redesigns

```
                  [P0] pi RPC adapter (provider=pi)
                  src: C3 row 1 + C2 finding
                              │
        ┌────────────────┬────┴─────┬────────────────────┐
        ▼                ▼          ▼                    ▼
  worktree-fleet     dag-fleet   iterative-fleet   autoresearch-fleet
  (keep-bash,        (hybrid)    (hybrid)          (hybrid)
   spawn only)                         │
                                       │ depends on
                                       ▼
                              extension skeleton ◄─────── fleet-plan
                              (registerCommand,           (port-to-extension)
                               resources_discover,                │
                               prompts)                           │
                                       ▲                          │
                                       └──────── doc (hybrid) ────┘
                                                 (shares extension skeleton
                                                  + session-tree state)
```

Critical edges:
- Every hybrid skill blocks on the **RPC adapter**. Without it, fleet's terminal/cost parsers break — see C3 cross-ref to [C2 event envelope](../../C2/output/finding.md) and [C1 call-site audit](../../C1/output/finding.md).
- `fleet-plan` and `doc` share an **extension package skeleton**. Build skeleton once during whichever lands first; reuse for the other.
- `doc` extensionization may unblock `iterative-fleet` reviewer-state design if session-tree IDs replace file-based `iterations/N/` (see Open Question 2 below).

---

## 90-day roadmap (concrete sequence)

**Week 0–2 — P0 RPC adapter (foundation)**
- Build `provider=pi` runner adapter normalizing `pi --mode rpc` JSONL → fleet event/cost schema.
- Wire into worktree-fleet spawn path first (smallest surface, validates adapter).
- Exit criteria: worktree-fleet runs end-to-end against pi worker; cost aggregation matches codex baseline.
- Refs: [C3 row 1+2](../../C3/output/finding.md#code-refs), [C2 RPC types](../../C2/output/finding.md).

**Week 2–3 — P1a worktree-fleet finalize (keep-bash, 3–5 days)**
- Ship `provider=pi` to worktree-fleet users. First production pi-fleet skill. Cheapest milestone.

**Week 2–4.5 — P1b dag-fleet hybrid (parallel with worktree finalize)**
- Migrate dag-fleet runner internals onto adapter; preserve operator-owned kill/relaunch.
- Validate against existing dag-fleet experiments.

**Week 4–5.5 — P2a fleet-plan port-to-extension (1–1.5 wk)**
- Build extension package skeleton. Register `/fleet-plan` command, `resources_discover` for templates, prompt templates for archetypes.
- Skeleton becomes shared base for `doc`.

**Week 5–7 — P2b doc hybrid (1–2 wk, overlaps fleet-plan)**
- Reuse extension skeleton. Add `/doc-*` commands, template discovery. Decide session-tree-ID question (Open Q3) before checkpoint helper work.

**Week 7–10 — P2c iterative-fleet hybrid (2–3 wk)**
- Reviewer gate into extension via `turn_end`/`agent_end`. Resolve Open Q2 (file-based vs session-native verdicts) before implementation.

**Week 10–13 — P3 autoresearch-fleet hybrid (2–3 wk)**
- Plateau/search policy as extension. Structured metrics from `get_session_stats` replacing brittle shell parsing.

**Out of 90-day window**: any pi-core changes (philosophy constraint forbids), any hooks-based work (signal: oh-my-pi hooks path is legacy vs upstream extension-centric — see [C3 gotchas](../../C3/output/finding.md#gotchas--surprises)).

---

## Contradictions surfaced

Per plan 04 anti-merge rule: do not smooth these away. They feed S6.

1. **"Extensions for everything" vs maintainer-philosophy constraint.** C3 recommends extension-heavy redesign for 5/6 skills, but also flags that pi maintainer rejects built-in subagents/plan/todo. Resolution: redesigns must ship as **external optional packages**, not PRs to pi core. See [C3 gotchas#2](../../C3/output/finding.md#gotchas--surprises). Risk if mis-resolved: wasted effort on upstream PRs that will be rejected.
2. **Hooks vs extensions migration ambiguity.** `oh-my-pi` still documents hooks path + `.omp` layout; upstream is extension-centric. C3 treats hooks as legacy but does not declare them deprecated. Decision needed before any "hybrid" work touches event handling. See [C3 architectural anchors](../../C3/output/finding.md#code-refs).
3. **CLI cwd portability gap.** C2 baseline assumes per-call `--cd`-style flag; pi has no first-class equivalent. C3 says "prefer RPC embedding/adapter" but `worktree-fleet` (keep-bash verdict) currently relies on cwd-per-spawn. Resolution implied: worktree-fleet's `provider=pi` spawn must use RPC session embedding, not naive CLI invocation. Worth re-checking if 3–5 day estimate holds. See [C3 gotchas#5](../../C3/output/finding.md#gotchas--surprises) + [C2 finding L13](../../C2/output/finding.md).
4. **Self-declared source-breadth gap.** C3 explicitly self-critiques: assigned source slice was narrow, could not credibly reach 30+ web domains without violating MECE. Confidence in architectural verdicts is high (primary code sources strong); confidence in ecosystem trends (e.g. Earendil rename impact) is lower. See [C3 open questions#4](../../C3/output/finding.md#open-questions).

No contradiction found between C3 and its peers C1/B1/B2 on building blocks — they align (per C3 cross-refs).

---

## Open questions (passed through to S6)

Per plan 04: do not drop these. Verbatim references — read [C3#Open questions](../../C3/output/finding.md#open-questions):

1. First migration milestone = `provider=pi` adapter only across all launchers before any extension-native work? (lowest risk, highest immediate leverage)
2. Reviewer verdicting for `iterative-fleet` — branch-native via session entries, or file-based `iterations/N/review.md` for operator auditability?
3. For `doc` — is script-level numbering still required, or can session-tree IDs become canonical sequence key?
4. Source-breadth self-critique — C3's slice was narrow by design; ecosystem-trend confidence is lower than architectural-verdict confidence.

Plus operational gotchas to watch ([C3#Gotchas](../../C3/output/finding.md#gotchas--surprises)):

- Source path mismatch: prompts say `src/extensions|hooks|skills`; actual is `src/core/extensions` + `src/core/skills.ts`.
- `tool_call` mutates args without post-mutation validation → policy extensions can introduce unsafe drift.
- Command-context lifecycle footgun: post `newSession/fork/switchSession/reload`, captured old context is stale and throws.
- April 8 2026 Earendil rename: hardcoded `@mariozechner/pi-coding-agent` references will break.

---

## Source map

- [C3 finding (primary)](../../C3/output/finding.md) — all per-skill verdicts, building blocks, gotchas, open questions.
- [C2 finding (peek)](../../C2/output/finding.md) — RPC/CLI flag mapping; cited for adapter-feasibility evidence.
- [C1 finding (cross-ref)](../../C1/output/finding.md) — call-site portability audit; relied on by C3 but not re-enumerated here.
- [B1 finding (cross-ref)](../../B1/output/finding.md) — extension runtime internals.
- [B2 finding (cross-ref)](../../B2/output/finding.md) — skills/prompt/theme packaging semantics for `fleet-plan` + `doc`.

C3 has no sibling `sources.md` on disk (verified). Confidence weighting per C3's own self-critique: high on architectural verdicts (primary code refs strong), lower on ecosystem trends.

---

## What this doc does NOT cover

- **Portability punch list / per-skill blockers today** → [S4 pi-portability-verdict](../../S4/output/synthesis.md). S5 assumes you decided to invest; S4 tells you what breaks before you start.
- **Beginner onboarding to pi itself** → [S2 pi-beginner-onboarding](../../S2/output/synthesis.md).
- **Power-user workflow recipes (headless review, multi-provider cost opt, fleet-via-RPC)** → [S3 pi-power-workflow-recipes](../../S3/output/synthesis.md). Note: S3's "fleet via RPC" recipe is the operational counterpart to this doc's P0 adapter milestone.
- **Aggregated open questions across all 13 workers** → [S6 pi-open-questions](../../S6/output/synthesis.md). S5 surfaces only C3-local open questions; S6 cross-cuts.
- **Index over all synthesis docs + raw findings** → [S1 pi-knowledge-index](../../S1/output/synthesis.md).
- **Anything requiring pi-core changes** — out of scope by maintainer-philosophy constraint.
