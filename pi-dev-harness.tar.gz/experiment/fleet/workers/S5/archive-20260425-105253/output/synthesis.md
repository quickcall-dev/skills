---
title: "S5 — pi-native redesign roadmap"
audience: skill maintainer (Sagar)
created: "2026-04-25"
---

# S5 — pi-native redesign roadmap

## TL;DR

Per-skill verdict for the 5 fleet skills + doc skill on whether to keep bash, port to a pi extension, or run hybrid. **Primary input C3 (`pi-native designs`) did not produce a finding.md** — see [Input gap](#input-gap) below. Verdicts here are derived from sibling findings ([B1 extension internals](../../B1/output/finding.md), [B2 skills format](../../B2/output/finding.md), [C2 CLI baseline](../../C2/output/finding.md)) and are flagged **PROVISIONAL** until C3 reruns. Headline: most fleet skills stay bash-driven (orchestrator-shaped); a thin pi extension only earns its keep where lifecycle hooks, tool interception, or in-session UX matter — `iterative-fleet` reviewer gating and `doc` skill resource discovery are the strongest extension candidates. The dag-fleet/worktree-fleet/autoresearch-fleet runners stay bash + `pi -p`/`pi --mode rpc`.

---

## Input gap

| Expected input | Status |
|---|---|
| `workers/C3/output/finding.md` (pi-native designs, primary) | **MISSING.** `.done` marker present; status.json frozen at `RUNNING` / `step: launched`; `.spawn.out.last` only contains `SPAWNED`; no output dir. C3 never produced. |
| `workers/C2/output/finding.md` (CLI baseline, peek) | present |
| `workers/B1/output/finding.md` (extension internals, dep) | present (read for context) |
| `workers/B2/output/finding.md` (skills format, dep) | present (read for context) |

**Effect on this synthesis:** all per-skill verdicts are derived from the extension API surface ([B1#Building blocks](../../B1/output/finding.md)) + headless CLI capabilities ([C2#Summary](../../C2/output/finding.md)) rather than from C3-authored designs. **PROVISIONAL** flag on every row. Re-run C3 before committing engineering effort.

---

## Per-skill verdict table

Skill list comes from the maintainer's user-invocable fleet/doc skills. C3 brief named "5 fleet skills + doc skill"; that resolves to: `dag-fleet`, `worktree-fleet`, `iterative-fleet`, `fleet-plan`, `autoresearch-fleet`, `doc`.

| Skill | Verdict | Why | Dependencies | Effort | Priority |
|---|---|---|---|---|---|
| `dag-fleet` | **keep-bash** (PROVISIONAL) | Orchestrator-shaped: spawns N `pi -p` / `codex exec` workers in tmux with budget caps + DAG ordering. Pi headless via `pi -p` and `pi --mode json -p` already exists ([C2#table](../../C2/output/finding.md#summary)). Extension would not add capability — runners are out-of-process by design. | C2 CLI surface stable | **S** (swap `claude -p` → `pi -p` shim) | P1 |
| `worktree-fleet` | **keep-bash** (PROVISIONAL) | Same shape as dag-fleet but per-worktree. Git plumbing + tmux is the substrate; pi extension API has no advantage here. | C2 CLI surface; cwd handling per-worker | **S** | P1 |
| `autoresearch-fleet` | **keep-bash** (PROVISIONAL) | Karpathy-style edit/eval/keep loop. Single agent + git as state machine. Headless `pi -p` + JSON event stream is sufficient. Extension would only help if you want in-session plateau detection — current bash plateau detector works fine. | C2 JSON event stream ([C2#building-blocks](../../C2/output/finding.md#building-blocks--concepts)) | **S** | P2 |
| `iterative-fleet` | **hybrid** (PROVISIONAL) | Runner stays bash (`pi -p` workers + reviewer worker). **But** the reviewer-verdict gate (`lgtm | iterate | escalate`) is a natural fit for a pi extension command (`/iterate-verdict`) running inside the reviewer's session, with `tool_call` interception ([B1#code-refs](../../B1/output/finding.md#code-refs)) to enforce the verdict schema before the reviewer writes a malformed file. Extension is value-add, not replacement. | B1 `registerCommand` + `tool_call` mutate path; B2 skill discovery if reviewer ships as skill | **M** | P1 |
| `fleet-plan` | **port-to-extension** (PROVISIONAL, weak signal) | Currently a planning skill. Pi's `registerCommand` + `ExtensionCommandContext` ([B1#building-blocks](../../B1/output/finding.md#building-blocks--concepts)) gives session-control methods (`reload`, `newSession`, `fork`, `switchSession`) that a planning command can use to spawn the planned fleet via RPC instead of shelling out. **Caveat:** without C3's design, unclear whether the extension form actually beats `bash + pi -p planner`. **Provisional verdict, low confidence.** | B1 command context; C2 RPC `set_model`/session controls | **M–L** | P3 |
| `doc` skill | **port-to-extension** (PROVISIONAL) | Doc skill is config-driven (experiments, plans, findings, checkpoints). Pi's resource discovery model already discovers skills/prompts/themes by name with collision diagnostics ([B2#building-blocks](../../B2/output/finding.md#building-blocks--concepts)). A pi extension that registers `defineTool` for `doc.create`, `doc.find`, `doc.checkpoint` integrates with `resources_discover` lifecycle and survives `/reload` cleanly ([B1#summary](../../B1/output/finding.md#summary)). Bash version still works but loses the in-session `/doc:*` UX. | B2 skill format; B1 `registerTool` | **M** | P2 |

**S** = ≤1 day, **M** = 2–5 days, **L** = >5 days. Effort estimates are PROVISIONAL — would tighten with C3.

---

## Dependency graph between redesigns

```
[C2 CLI baseline stable] ──► dag-fleet (bash shim)
                         ├──► worktree-fleet (bash shim)
                         └──► autoresearch-fleet (bash shim)

[B1 extension API] ──► doc-as-pi-extension ──┐
                                             ├──► fleet-plan-as-pi-extension
                                             │     (uses doc extension to write plans)
                                             └──► iterative-fleet hybrid
                                                   (reviewer-verdict command)

[B2 skill discovery] ──► doc-as-pi-extension (resource discovery integration)
```

Critical path: **doc-skill-as-pi-extension unblocks fleet-plan-as-pi-extension.** A pi-native `fleet-plan` that wants to *write* its plan output via the doc tool needs that doc tool to exist as a registered pi tool first. Otherwise fleet-plan reverts to bash file-writing.

Iterative-fleet hybrid is independent — can ship in parallel with the doc port.

---

## Contradictions surfaced

Per [plan 04 §lossy-merge prohibitions](../../../../plans/04-synthesis-multi-doc.md), contradictions are not smoothed.

1. **"Pi has no built-in subagents" vs "first-party subagent example exists"** — [B1#gotchas](../../B1/output/finding.md#gotchas--surprises) flags pi's product positioning ("no built-in sub-agents") while pointing to `examples/extensions/subagent/index.ts` that implements them via subprocess. Implication for S5: a fleet runner ported to pi extension would *also* be subprocess-orchestration, so the "extension vs bash" distinction collapses to "where does the orchestrator live" — TS/extension or bash. Not a capability question.
2. **Tool interception surface moved** — [B1#summary](../../B1/output/finding.md#summary) says interception is now at `AgentSession` (`beforeToolCall`/`afterToolCall`), not wrapper-level. Older docs/forks (`oh-my-pi`) still document hook-style. Any extension we port today against current `pi-mono` will not work on `oh-my-pi` forks. C3 absence means we don't know which fork the maintainer's pi install tracks.
3. **CLI cwd gap** — [C2#table](../../C2/output/finding.md#summary) flags "no top-level `pi --cd` CLI flag" but RPC client supports per-process cwd. `worktree-fleet` depends on per-worker cwd. Bash workaround: `cd` before spawning. Extension workaround: drive via RPC. Contradiction is on which is canonical — C3 would have ruled.
4. **Skill collision policy mismatch** — [B2#gotchas](../../B2/output/finding.md#gotchas--surprises) notes pi uses first-seen-winner + diagnostics, while Claude Code uses location precedence + plugin namespacing. If `doc` skill ships as both a Claude skill (today) and a pi extension (proposed), users with both installed get pi's first-wins behavior — could silently load the wrong one. No guidance from C3 on resolution.

---

## 90-day roadmap (concrete sequence)

**Days 0–7: unblock + decide.**
1. Re-run C3 worker (it produced no finding — see [Input gap](#input-gap)). Without C3's pi-native designs, every verdict above stays PROVISIONAL.
2. Confirm which pi fork the maintainer's install tracks (`pi-mono` vs `oh-my-pi`) — see [Contradiction #2](#contradictions-surfaced).

**Days 7–21: cheapest, highest-value port — `iterative-fleet` reviewer command.**
3. Implement `/iterate-verdict` as a pi extension command using `registerCommand` + `tool_call` interception ([B1#code-refs](../../B1/output/finding.md#code-refs)). This is hybrid: bash runner unchanged, extension only handles the verdict gate. Low blast radius; reverts cleanly if it doesn't pan out.

**Days 21–45: `doc` skill port.**
4. Build pi extension exposing `defineTool({name: "doc.create"|"doc.find"|"doc.checkpoint"})`. Validate `resources_discover` integration ([B1#summary](../../B1/output/finding.md#summary)). Keep bash doc skill in parallel until parity proven.
5. Resolve [Contradiction #4](#contradictions-surfaced) (skill collision) before public release — pick a namespace prefix (`pi-doc` or similar).

**Days 45–75: `fleet-plan` port (gated on doc port).**
6. If doc-as-extension shipped successfully, port `fleet-plan` to pi extension that writes plan output via `doc.create` tool. If doc port stalled, **abort fleet-plan port** — bash version is fine.

**Days 75–90: shim + leave alone.**
7. `dag-fleet` / `worktree-fleet` / `autoresearch-fleet`: ship a one-line shim that lets `--engine pi` swap `claude -p` → `pi -p`. No structural change. Verifies headless parity.
8. Reassess: if iterative + doc + fleet-plan ports all paid off, revisit whether `dag-fleet` should also become an extension that drives RPC sessions. Defer this decision to day 90.

---

## Actionable items (≥5 required)

1. **Re-run worker C3** — primary input missing, blocking confidence. Owner: maintainer. Effort: re-launch fleet worker.
2. **Confirm pi fork** (`pi-mono` vs `oh-my-pi`) before any extension code is written. See [Contradiction #2](#contradictions-surfaced).
3. **Prototype `/iterate-verdict` extension** for iterative-fleet reviewer (smallest, highest-value port).
4. **Decide on skill namespacing** for the doc port — see [Contradiction #4](#contradictions-surfaced). Pick `pi-doc:*` or equivalent prefix before publishing.
5. **Add `--engine pi` shim** to dag-fleet/worktree-fleet/autoresearch-fleet to validate headless parity without restructuring.
6. **Defer fleet-plan port** until doc port ships — do not invest until dependency is met.
7. **Document cwd workaround** for worktree-fleet on pi (RPC cwd vs `cd` pre-spawn) — [Contradiction #3](#contradictions-surfaced).

---

## Source map

Every claim above cites a worker finding by relative path + section anchor.

- [B1#Summary](../../B1/output/finding.md#summary) — extension event surface, `AgentSession` tool interception, hot reload semantics.
- [B1#Building blocks](../../B1/output/finding.md#building-blocks--concepts) — `ExtensionFactory`, `ExtensionRunner`, command-vs-event context split, subagent example.
- [B1#Code refs](../../B1/output/finding.md#code-refs) — `pi.on("tool_call")` mutable input, `registerCommand`, runtime stale-context guards.
- [B1#Gotchas](../../B1/output/finding.md#gotchas--surprises) — built-in tool override is name-based, fork divergence (`oh-my-pi` vs `pi-mono`).
- [B2#Summary](../../B2/output/finding.md#summary) — skill discovery composition + collision diagnostics.
- [B2#Building blocks](../../B2/output/finding.md#building-blocks--concepts) — skill discovery roots, validation contract, distribution model.
- [B2#Gotchas](../../B2/output/finding.md#gotchas--surprises) — first-seen-winner collision policy vs Claude Code namespace precedence.
- [C2#Summary](../../C2/output/finding.md#summary) — `pi -p`, `pi --mode json`, `pi --mode rpc`, session resume mapping.
- [C2#Building blocks](../../C2/output/finding.md#building-blocks--concepts) — print mode, RPC protocol, JSONL framing, model swap surface.
- [C2#Gotchas](../../C2/output/finding.md#gotchas--surprises) — no top-level `--cd` flag; JSON header line; RPC operations beyond `prompt`/`response`.

C3's `sources.md` could not be inspected (worker did not produce output dir).

---

## What this doc does NOT cover

- **Beginner onboarding** — see sibling [S2 `pi-beginner-onboarding`](../../S2/output/synthesis.md) (audience: new pi user).
- **Power-user workflow recipes** — see sibling [S3 `pi-power-workflow-recipes`](../../S3/output/synthesis.md) (named workflows, not redesign verdicts).
- **Portability audit of existing skills as-is** — see sibling [S4 `pi-portability-verdict`](../../S4/output/synthesis.md). S4 answers "does my fleet skill set run on pi *today*?"; S5 answers "should I rebuild it pi-native?". Different question.
- **Open questions and unknowns harvest** — see sibling [S6 `pi-open-questions`](../../S6/output/synthesis.md). The C3 input gap, fork-divergence question, namespace-collision resolution, and cwd-flag canonicalization all belong in S6 too.
- **Navigation index across all 13 raw findings + 6 synthesis docs** — see sibling [S1 `pi-knowledge-index`](../../S1/output/synthesis.md).
