# Worker S5 — pi-native redesign roadmap (synthesis)

You are a synthesis worker. Inputs = upstream worker findings on disk. Output = one synthesis doc + sibling pointers.

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/04-synthesis-multi-doc.md` — it defines the lossless-merge contract you MUST follow.

## Input findings (read these — verbatim from worker output)

- $FLEET_ROOT/workers/C3/output/finding.md (pi-native designs)
- (also peek at C2 for CLI baseline if needed)

Also read each input's sibling `sources.md` to understand exploration breadth (helps you weigh confidence).

## Audience

Skill maintainer (Sagar). Wants to know what to rebuild pi-native vs leave as bash.

## Required structure

Per-skill table:
| Skill | Verdict (keep-bash/port-extension/hybrid) | Why | Dependencies | Effort | Priority |
|---|---|---|---|---|---|

Then: dependency graph between redesigns (e.g. doc-skill-as-pi-skill might unblock fleet-plan-as-pi-skill). End with 90-day roadmap suggestion (concrete sequence).

## Mandatory rules (per plan 04)

- NO concatenation. Link to source findings, do not paste.
- NO replacing a finding with its summary inline — link instead.
- NO dropping "Open questions" / "Gotchas" — those feed sibling synth doc S6.
- NO smoothing contradictions. Surface them with a "Contradictions" subsection.
- Tables stay tables.
- End with: "## What this doc does NOT cover" — point to sibling synth docs (S1-S6) that handle the excluded scope.

## Citation form

Cite worker findings as `[A2#Building blocks](../../A2/output/finding.md#building-blocks--concepts)` — relative paths from your output dir.

## Health targets (synth-tier)

- 100% finding coverage (every relevant input cited or explicitly excluded with reason)
- ≥3 cross-finding contradictions surfaced (or "no contradictions found, here's why")
- ≥5 actionable items (S4/S5 only)
- 0 lossy summaries

## Deliverable

`$FLEET_ROOT/workers/S5/output/synthesis.md`

Save ALL output files to `$FLEET_ROOT/workers/S5/output/` — use absolute paths.
