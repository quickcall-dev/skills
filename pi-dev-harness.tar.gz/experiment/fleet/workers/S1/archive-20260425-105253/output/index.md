---
title: "pi-knowledge-index"
audience: navigation
synthesis_tier: S1
created: "2026-04-25"
---

# pi.dev knowledge — index

Thin landing page. One-line hook per link. No summaries — read the source.

## Start here (by audience)

- New user → [S2 beginner onboarding](../../S2/output/synthesis.md)
- Power user → [S3 workflow recipes](../../S3/output/synthesis.md)
- Skill maintainer → [S4 portability verdict](../../S4/output/synthesis.md) + [S5 native redesign roadmap](../../S5/output/synthesis.md)
- Researcher / next-experiment planner → [S6 open questions](../../S6/output/synthesis.md)

## Synthesis docs (5)

- [S2 pi-beginner-onboarding](../../S2/output/synthesis.md) — linear walkthrough: install → auth → first run → core tools → first session.
- [S3 pi-power-workflow-recipes](../../S3/output/synthesis.md) — five named recipes (policy gate, headless review, multi-provider, ecosystem packs, embedded runtime).
- [S4 pi-portability-verdict](../../S4/output/synthesis.md) — per-skill table: does the bash fleet run on pi today, and what's the punch list.
- [S5 pi-native-redesign-roadmap](../../S5/output/synthesis.md) — per-skill keep-bash / port-to-extension / hybrid verdict (PROVISIONAL — C3 missing).
- [S6 pi-open-questions](../../S6/output/synthesis.md) — five buckets of unresolved unknowns harvested from all worker `Open questions` sections.

## Raw worker findings (13)

### Bucket A — foundations

- [A1 pi-bootstrap](../../A1/output/finding.md) — install, auth, config roots, context-file injection, CLI entrypoint behavior.
- [A2 pi-core-tools](../../A2/output/finding.md) — `read`/`write`/`edit`/`bash` typed contracts, truncation/abort semantics, recurring bash pain points.
- [A3 pi-execution-modes](../../A3/output/finding.md) — interactive TUI, print text, print JSON, RPC, SDK embed — wire formats and lifecycle.
- [A4 pi-providers-models](../../A4/output/finding.md) — 25 providers / 10 API adapters; mid-session model swap, normalization, unified usage/cost struct.
- [A5 pi-sessions-tree-resume](../../A5/output/finding.md) — append-only JSONL session tree, branch-as-pointer, `/tree`, fork, resume lifecycle.

### Bucket B — power use

- [B1 pi-extensions](../../B1/output/finding.md) — `ExtensionAPI.on(...)` event surface, agent-level tool interception, hot reload semantics.
- [B2 pi-skills-prompts-themes](../../B2/output/finding.md) — discovery roots, validation, collision precedence; comparison vs Claude Code skills.
- [B3 pi-ecosystem](../../B3/output/finding.md) — first-party `@mariozechner/*` packages plus extension/skill packs across npm + GitHub topics.
- [B4 pi-real-adopters](../../B4/output/finding.md) — minimal-core + userland pattern; embedded SDK example (OpenClaw); package-first profile workflows.
- [B5 pi-vs-competitors](../../B5/output/finding.md) — pi vs Claude Code / Cursor / aider / Codex on lock-in, customization ceiling, headless suitability.

### Bucket C — portability

- [C1 fleet-call-sites](../../C1/output/finding.md) — `build_inner_cmd` adapter seam; one hardcoded `claude -p` site; provider-coupled event/cost contracts.
- [C2 pi-cli-baseline](../../C2/output/finding.md) — `pi -p` / `--mode json` / `--mode rpc` capability matrix vs claude/codex flags; cwd CLI gap.
- [C3 pi-native-designs](../../C3/output/) — **MISSING** (`finding.md` not produced; `.done` marker present, see [S5 input gap](../../S5/output/synthesis.md#input-gap) and [S6 coverage gaps](../../S6/output/synthesis.md#coverage-gaps)).

## Source-volume snapshot (per worker)

| Worker | Sources consulted | Unique domains | Primary sources |
|---|---|---|---|
| A1 | 166 | 39 | 108 |
| A2 | 237 | 2 | 237 |
| A3 | 157 | 8 | 120 |
| A4 | 110 | 33 | 82 |
| A5 | 105 | 3 | 84 |
| B1 | 189 | 34 | 151 |
| B2 | 135 | 30 | 105 |
| B3 | 2034 | 107 | 1466 |
| B4 | 114 | 53 | 16 |
| B5 | 167 | 42 | 11 |
| C1 | 273 | 1 | 273 |
| C2 | 610 | 1 | 610 |
| C3 | — | — | — |
