# Worker S1 — knowledge index (LAST to run)

You are the index. Thin landing page that links everything. NEVER summarize — the synthesis docs already do that. Your job is navigation.

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/04-synthesis-multi-doc.md`.

## Inputs

- All 13 raw findings: `$FLEET_ROOT/workers/{A1..A5,B1..B5,C1..C3}/output/finding.md`
- All 5 synthesis docs: `$FLEET_ROOT/workers/{S2,S3,S4,S5,S6}/output/synthesis.md`

## Required structure

```
# pi.dev knowledge — index

## Start here (by audience)
- New user → [S2 beginner onboarding](...)
- Power user → [S3 workflow recipes](...)
- Skill maintainer → [S4 portability](...) + [S5 redesign](...)
- Researcher → [S6 open questions](...)

## Synthesis docs (5)
- [S2 ...](...) — one-line hook
- [S3 ...](...) — one-line hook
- [S4 ...](...) — one-line hook
- [S5 ...](...) — one-line hook
- [S6 ...](...) — one-line hook

## Raw worker findings (13)
### Bucket A — foundations
- [A1 bootstrap](...) — one-line hook
- ... (A2-A5)
### Bucket B — power use
- [B1 extensions](...) — one-line hook
- ... (B2-B5)
### Bucket C — portability
- [C1 call-sites](...) — one-line hook
- [C2 pi CLI](...) — one-line hook
- [C3 redesign](...) — one-line hook

## Source-volume snapshot (per worker)
| Worker | Sources consulted | Domains | Primary |
|---|---|---|---|
(from each worker's sources.md frontmatter)
```

## Rules

- One-line hook per link (max ~15 words)
- NO content summaries beyond hooks
- All links relative paths from your output dir
- Total doc < 200 lines

## Deliverable

`$FLEET_ROOT/workers/S1/output/index.md`

Save ALL output files to `$FLEET_ROOT/workers/S1/output/` — use absolute paths.
