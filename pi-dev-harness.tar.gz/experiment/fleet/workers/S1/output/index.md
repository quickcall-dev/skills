---
title: "pi-knowledge-index"
audience: navigation
synthesizes: [A1..A5, B1..B5, C1..C3, S2..S6]
created: "2026-04-25"
---

# pi.dev knowledge — index

Thin landing page. Each link goes to the source doc; the one-line hooks here are not summaries — read the source.

---

## Start here (by audience)

- New user → [S2 — pi-beginner-onboarding](../../S2/output/synthesis.md)
- Power user → [S3 — pi-power-workflow-recipes](../../S3/output/synthesis.md)
- Skill maintainer (today's portability) → [S4 — pi-portability-verdict](../../S4/output/synthesis.md)
- Skill maintainer (native redesign) → [S5 — pi-native-redesign-roadmap](../../S5/output/synthesis.md)
- Researcher / next-experiment planner → [S6 — pi-open-questions](../../S6/output/synthesis.md)

---

## Synthesis docs (5)

- [S2 — pi-beginner-onboarding](../../S2/output/synthesis.md) — linear install → first run → core tools → modes → sessions, with gotchas.
- [S3 — pi-power-workflow-recipes](../../S3/output/synthesis.md) — five named workflows (preflight gate, multi-provider cost opt, fleet-via-RPC, etc.).
- [S4 — pi-portability-verdict](../../S4/output/synthesis.md) — per-skill table: does my fleet skill run on pi today, blockers, effort.
- [S5 — pi-native-redesign-roadmap](../../S5/output/synthesis.md) — per-skill verdict keep-bash / port-to-extension / hybrid + ~8–13 wk roadmap.
- [S6 — pi-open-questions](../../S6/output/synthesis.md) — ~40 unknowns in 5 buckets + 7 cross-worker contradictions.

---

## Raw worker findings (13)

### Bucket A — foundations

- [A1 — bootstrap](../../A1/output/finding.md) — global npm install, auth paths, `~/.pi`/`.pi` config layering, AGENTS/CLAUDE auto-context.
- [A2 — core tools](../../A2/output/finding.md) — strict typed `read/write/edit/bash` with exact-text edits and tail-truncated bash.
- [A3 — execution modes](../../A3/output/finding.md) — interactive TUI, print text, print JSONL, long-lived RPC, SDK embedding.
- [A4 — providers + cost](../../A4/output/finding.md) — 25 providers behind 10 API adapters, mid-session model swap, unified usage/cost.
- [A5 — sessions + tree + resume](../../A5/output/finding.md) — append-only JSONL tree, `/tree` branch nav, `--resume` runtime replacement.

### Bucket B — power use

- [B1 — extensions](../../B1/output/finding.md) — 28-event API, agent-level `tool_call` interception, hot-reload runtime swap.
- [B2 — skills / prompts / themes](../../B2/output/finding.md) — composition-first discovery, collision warn-not-fail, cross-harness skill paths.
- [B3 — package ecosystem](../../B3/output/finding.md) — `@mariozechner/*` first-party + fragmented `pi-extension`/`pi-skill` community packs.
- [B4 — in-the-wild patterns](../../B4/output/finding.md) — workflow engineers layer extensions; OpenClaw embeds SDK; AGENTS as workflow primitive.
- [B5 — vs competitors](../../B5/output/finding.md) — terminal-native + extensible; thinner third-party validation vs Claude/Codex/aider/Cursor.

### Bucket C — portability

- [C1 — fleet call-sites](../../C1/output/finding.md) — `build_inner_cmd` seam in 4/5 launchers; `relaunch-worker.sh` hardcodes `claude -p`.
- [C2 — pi CLI mapping](../../C2/output/finding.md) — `-p`, `--mode json|rpc`, `--continue`/`--resume`/`--session`, `--tools`; gap on `--cd`.
- [C3 — pi-native redesign](../../C3/output/finding.md) — per-skill verdict keep-bash / port-to-extension / hybrid + effort estimates.

---

## Source-volume snapshot (per worker)

| Worker | Sources | Domains | Primary |
|---|---:|---:|---:|
| A1 | 166 | 39 | 108 |
| A2 | 237 | 2 | 237 |
| A3 | 157 | 8 | 120 |
| A4 | 110 | 33 | 82 |
| A5 | 105 | 3 | 84 |
| B1 | 189 | 34 | 151 |
| B2 | 135 | 30 | 105 |
| B3 | 2034 | 107 | 1466 |
| B4 | 114 | 53 | 16 |
| B5 | 167 | 42 | 11 |
| C1 | 273 | 1 | 273 |
| C2 | 610 | 1 | 610 |
| C3 | N/A | N/A | N/A |
