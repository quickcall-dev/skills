# Worker A4 — provider layer (15+ LLM providers)

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Provider abstraction, /model mid-session swap, cost+token tracking, normalization across providers with different tool schemas.

## Sources you own (do not touch others')

- `pi-mono/packages/coding-agent/src/providers/`
- `pi-mono/packages/api/` (unified LLM API)
- Per-provider docs (Anthropic/OpenAI/Google/Bedrock/etc.)
- Comparison posts mentioning pi's provider story

## Out of scope (other workers cover)

- Run modes (A3)
- Sessions (A5)
- Comparison vs other harnesses (B5)

## Source-mix target (per plan 05)

50% pi provider source, 30% per-provider docs, 20% comparison posts. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/A4/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/A4/output/` — use absolute paths.
