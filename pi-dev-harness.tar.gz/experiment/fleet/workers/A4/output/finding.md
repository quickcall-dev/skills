## Summary
- The provider layer is API-first, not vendor-first: `stream()` resolves `model.api` to a registered API provider, while `model.provider` is mostly metadata/auth/routing (`/tmp/pi-mono/packages/ai/src/stream.ts:17`, `/tmp/pi-mono/packages/ai/src/api-registry.ts:66`, `/tmp/pi-mono/packages/ai/src/types.ts:5`).
- Mid-session model/provider swap is persisted and safe-guarded: `/model` calls `session.setModel()`, enforces auth, appends a model-change entry, and re-clamps thinking level (`/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:2492`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:1390`).
- Normalization is explicit and deep: cross-provider replay rewrites tool-call IDs, downgrades unsupported image blocks, and synthesizes missing tool results to keep multi-provider loops valid (`/tmp/pi-mono/packages/ai/src/providers/transform-messages.ts:64`, `/tmp/pi-mono/packages/ai/src/providers/openai-responses-shared.ts:109`, `/tmp/pi-mono/packages/ai/test/cross-provider-handoff.test.ts:6`).

## Building blocks / concepts
- API registry (`ApiProvider`): maps `api` string -> `{stream, streamSimple}` with runtime API mismatch guards (`/tmp/pi-mono/packages/ai/src/api-registry.ts:23`).
- Built-in lazy provider modules: runtime loads provider implementation on first use and emits structured error messages if module load fails (`/tmp/pi-mono/packages/ai/src/providers/register-builtins.ts:168`).
- Model registry: combines generated built-ins + `models.json` overrides + dynamic extension registration, then filters available models by configured auth (`/tmp/pi-mono/packages/coding-agent/src/core/model-registry.ts:363`, `/tmp/pi-mono/packages/coding-agent/src/core/model-registry.ts:607`).
- Unified usage/cost struct: all providers emit `usage.{input,output,cacheRead,cacheWrite,totalTokens,cost}` and call shared pricing helper where applicable (`/tmp/pi-mono/packages/ai/src/types.ts:189`, `/tmp/pi-mono/packages/ai/src/models.ts:39`).
- Reasoning compatibility shim: `SimpleStreamOptions.reasoning` is translated per provider/API and clamped when unsupported (e.g., xhigh->high) (`/tmp/pi-mono/packages/ai/src/providers/simple-options.ts:21`, `/tmp/pi-mono/packages/ai/src/types.ts:298`).
- Session affinity/prompt cache abstraction: shared `sessionId` + `cacheRetention` fan out to provider-specific headers/fields (`/tmp/pi-mono/packages/ai/src/types.ts:81`, `/tmp/pi-mono/packages/ai/src/providers/openai-responses.ts:216`, `/tmp/pi-mono/packages/ai/src/providers/mistral.ts:228`, `/tmp/pi-mono/packages/ai/src/providers/amazon-bedrock.ts:198`).

## Code refs
- Provider count and breadth:
  - 25 top-level providers in generated catalog (`/tmp/pi-mono/packages/ai/src/models.generated.ts:7`, `/tmp/pi-mono/packages/ai/src/models.generated.ts:14925`).
  - `KnownProvider` includes gateway/proxy families beyond direct vendors (`/tmp/pi-mono/packages/ai/src/types.ts:19`).
- API implementation set:
  - Built-ins register 10 API adapters (Anthropic/OpenAI variants/Google variants/Bedrock/Mistral) (`/tmp/pi-mono/packages/ai/src/providers/register-builtins.ts:366`).
- Mid-session model swap:
  - Interactive `/model` command path (`/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:2492`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts:3909`).
  - Session mutation + persistence (`/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:1390`).
  - RPC equivalent (`/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:448`).
- Cost/token tracking:
  - Provider-level cost compute (`/tmp/pi-mono/packages/ai/src/models.ts:39`).
  - Session aggregate stats from assistant usages (`/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2880`).
  - Daily provider breakdown script from session JSONL (`/tmp/pi-mono/scripts/cost.ts:69`).
- Tool schema normalization:
  - Generic cross-provider message transformer (`/tmp/pi-mono/packages/ai/src/providers/transform-messages.ts:64`).
  - OpenAI Responses ID normalization for foreign tool calls (`/tmp/pi-mono/packages/ai/src/providers/openai-responses-shared.ts:109`).
  - Google thought-signature and tool-call ID handling (`/tmp/pi-mono/packages/ai/src/providers/google-shared.ts:25`, `/tmp/pi-mono/packages/ai/src/providers/google-shared.ts:92`).
  - Anthropic tool-name casing and tool_result packing (`/tmp/pi-mono/packages/ai/src/providers/anthropic.ts:68`, `/tmp/pi-mono/packages/ai/src/providers/anthropic.ts:1045`).
  - Mistral fixed-length tool ID derivation (`/tmp/pi-mono/packages/ai/src/providers/mistral.ts:152`).
- External contract alignment:
  - OpenAI Responses reasoning encrypted content + tools ([OpenAI Responses API](https://platform.openai.com/docs/api-reference/responses/create?api-mode=responses)).
  - Anthropic tool-use turn constraints ([Anthropic tool use](https://docs.anthropic.com/en/docs/agents-and-tools/tool-use/implement-tool-use)).
  - Gemini thought signatures/tool-call continuity ([Gemini thought signatures](https://ai.google.dev/gemini-api/docs/thought-signatures)).
  - Bedrock Converse tool use ([Bedrock tool use](https://docs.aws.amazon.com/bedrock/latest/userguide/tool-use.html)).

## Examples
```ts
import { getModel, completeSimple } from "@mariozechner/pi-ai";

const model = getModel("openai", "gpt-5.4")!;
const out = await completeSimple(model, {
  messages: [{ role: "user", content: "ping", timestamp: Date.now() }],
}, { reasoning: "medium", sessionId: "sess-1", cacheRetention: "short" });

console.log(out.usage.totalTokens, out.usage.cost.total);
```

```ts
// Mid-session swap behavior (interactive/RPC eventually calls setModel)
await session.setModel(nextModel);
// persists model change + default model and clamps thinking against new capability
```
(Corresponding implementation: `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:1390`)

```ts
// Dynamic provider override from extension
pi.registerProvider("my-proxy", {
  baseUrl: "https://proxy.example.com/v1",
  api: "openai-completions",
  apiKey: "MY_PROXY_KEY",
  models: [{
    id: "proxy-model",
    reasoning: false,
    input: ["text"],
    cost: { input: 0, output: 0, cacheRead: 0, cacheWrite: 0 },
    contextWindow: 128000,
    maxTokens: 4096,
  }],
});
```
(Flow enforced by `/tmp/pi-mono/packages/coding-agent/src/core/model-registry.ts:758`)

## Gotchas / surprises
- Path drift vs worker brief: provider layer is now in `packages/ai`, not `packages/api`, and there is no `coding-agent/src/providers` directory in this checkout (`/tmp/pi-mono/packages/ai/src/index.ts:4`).
- 25 providers are exposed at model-catalog level, but only 10 API adapters are implemented; many providers are OpenAI/Anthropic/Google-compatible overlays rather than bespoke transports (`/tmp/pi-mono/packages/ai/src/models.generated.ts:7`, `/tmp/pi-mono/packages/ai/src/providers/register-builtins.ts:366`).
- Cross-provider replay can mutate history semantics by inserting synthetic tool results when calls are orphaned; great for robustness, but it means replayed context is not byte-identical to original turns (`/tmp/pi-mono/packages/ai/src/providers/transform-messages.ts:155`).
- Availability UX is auth-gated: `getAvailable()` hides models with no configured auth, so provider breadth is larger than what `/model` initially shows (`/tmp/pi-mono/packages/coding-agent/src/core/model-registry.ts:607`, `/tmp/pi-mono/packages/coding-agent/src/modes/interactive/components/model-selector.ts:96`).
- Reasoning/tool compatibility logic is highly provider-specific and fragmented (OpenAI compat matrix, Anthropic beta headers, Gemini thought signatures, Bedrock reasoning payloads), so portability depends on ongoing shim maintenance (`/tmp/pi-mono/packages/ai/src/types.ts:277`, `/tmp/pi-mono/packages/ai/src/providers/anthropic.ts:163`, `/tmp/pi-mono/packages/ai/src/providers/google-shared.ts:45`, `/tmp/pi-mono/packages/ai/src/providers/amazon-bedrock.ts:55`).
- Third-party comparison coverage of pi’s provider internals is thin and uneven; strongest evidence remains source + tests + official provider docs (e.g., [issue #2386](https://github.com/badlogic/pi-mono/issues/2386), [Instagit analysis](https://instagit.com/badlogic/pi-mono/pi-ai-multi-llm-provider-integration/)).

## Open questions
- Should provider/API registration be introspectable at runtime (e.g., expose active API adapters + compat flags) so `/model` and diagnostics can explain normalization behavior deterministically?
- Should synthetic tool-result insertion be toggleable for strict replay/debug modes?
- Should cost logic support provider-native pricing variants beyond static per-1M token tables (service tiers are currently patched per provider in code)?
- Should the fleet plan update A4 source paths to current repo layout to avoid worker drift? (self-critique: this run spent non-trivial time reconciling stale paths before collecting evidence.)

## Cross-refs
- Session persistence/tree semantics for model switches likely belong to A5 (e.g., `appendModelChange`, branch compaction boundaries): `/tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts`, `/tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts:2932`.
- Interactive selector UX and mode-specific command handling overlap A3 run-modes scope (`/tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts`).
- Market/tool positioning comparisons vs Cursor/aider/Claude Code are B5 scope; only provider-layer evidence was captured here.
