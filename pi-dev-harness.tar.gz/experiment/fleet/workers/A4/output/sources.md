---
worker: A4
finding: pi-providers
created: "2026-04-25T11:05:00Z"
total_sources: 110
unique_domains: 33
primary_sources: 82
---

## Sources consulted

### A) pi provider source (55)
- /tmp/pi-mono/packages/ai/src/stream.ts — API-level stream dispatch entrypoint.
- /tmp/pi-mono/packages/ai/src/api-registry.ts — API provider registry contract.
- /tmp/pi-mono/packages/ai/src/models.ts — provider/model lookup and shared cost calculation.
- /tmp/pi-mono/packages/ai/src/types.ts — unified usage/tool/thinking/compat types.
- /tmp/pi-mono/packages/ai/src/providers/register-builtins.ts — lazy provider module registration.
- /tmp/pi-mono/packages/ai/src/providers/transform-messages.ts — cross-provider normalization and synthetic tool results.
- /tmp/pi-mono/packages/ai/src/providers/openai-completions.ts — OpenAI-compatible streaming implementation.
- /tmp/pi-mono/packages/ai/src/providers/openai-responses.ts — OpenAI Responses implementation.
- /tmp/pi-mono/packages/ai/src/providers/openai-responses-shared.ts — responses message/tool conversion and stream processing.
- /tmp/pi-mono/packages/ai/src/providers/openai-codex-responses.ts — Codex responses transport/session handling.
- /tmp/pi-mono/packages/ai/src/providers/azure-openai-responses.ts — Azure responses adapter.
- /tmp/pi-mono/packages/ai/src/providers/anthropic.ts — Anthropic messages adapter.
- /tmp/pi-mono/packages/ai/src/providers/google.ts — Gemini adapter.
- /tmp/pi-mono/packages/ai/src/providers/google-shared.ts — Gemini/CCA shared conversion and thought-signature handling.
- /tmp/pi-mono/packages/ai/src/providers/google-vertex.ts — Vertex adapter.
- /tmp/pi-mono/packages/ai/src/providers/google-gemini-cli.ts — Cloud Code Assist/Antigravity adapter.
- /tmp/pi-mono/packages/ai/src/providers/mistral.ts — Mistral adapter and tool-ID normalizer.
- /tmp/pi-mono/packages/ai/src/providers/amazon-bedrock.ts — Bedrock converse adapter.
- /tmp/pi-mono/packages/ai/src/providers/simple-options.ts — common reasoning/token options.
- /tmp/pi-mono/packages/ai/src/env-api-keys.ts — provider env var/auth source resolution.
- /tmp/pi-mono/packages/ai/src/models.generated.ts — generated provider/model catalog.
- /tmp/pi-mono/packages/ai/src/index.ts — public exports of provider layer.
- /tmp/pi-mono/packages/coding-agent/src/core/model-registry.ts — dynamic provider registration + auth-gated availability.
- /tmp/pi-mono/packages/coding-agent/src/core/model-resolver.ts — provider/model parsing and defaults.
- /tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts — setModel/cycleModel and session stats.
- /tmp/pi-mono/packages/coding-agent/src/core/slash-commands.ts — `/model` builtin definition.
- /tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts — `/model` command execution.
- /tmp/pi-mono/packages/coding-agent/src/modes/interactive/components/model-selector.ts — model list sourcing and filtering.
- /tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts — RPC `set_model` and `cycle_model`.
- /tmp/pi-mono/packages/coding-agent/src/core/settings-manager.ts — default model/thinking persistence.
- /tmp/pi-mono/packages/coding-agent/src/core/session-manager.ts — model change entries in session tree.
- /tmp/pi-mono/packages/coding-agent/docs/providers.md — provider auth/config behavior.
- /tmp/pi-mono/packages/coding-agent/docs/custom-provider.md — extension provider API and compat knobs.
- /tmp/pi-mono/packages/coding-agent/docs/models.md — models.json schema and compat overrides.
- /tmp/pi-mono/packages/ai/README.md — stated provider abstraction goals.
- /tmp/pi-mono/scripts/cost.ts — per-provider cost aggregation utility.
- /tmp/pi-mono/packages/ai/test/cross-provider-handoff.test.ts — integration coverage for cross-provider replay.
- /tmp/pi-mono/packages/ai/test/tool-call-id-normalization.test.ts — ID normalization expectations.
- /tmp/pi-mono/packages/ai/test/transform-messages-copilot-openai-to-anthropic.test.ts — cross-provider transform coverage.
- /tmp/pi-mono/packages/ai/test/openai-responses-foreign-toolcall-id.test.ts — foreign toolcall handling.
- /tmp/pi-mono/packages/ai/test/openai-responses-tool-result-images.test.ts — tool-result image routing.
- /tmp/pi-mono/packages/ai/test/openai-responses-partial-json-cleanup.test.ts — stream cleanup invariants.
- /tmp/pi-mono/packages/ai/test/openai-completions-empty-tools.test.ts — empty tools edge case.
- /tmp/pi-mono/packages/ai/test/openai-completions-tool-choice.test.ts — tool choice mapping.
- /tmp/pi-mono/packages/ai/test/openai-completions-tool-result-images.test.ts — OpenAI tool result multimodal behavior.
- /tmp/pi-mono/packages/ai/test/openai-completions-prompt-cache.test.ts — cache/session compatibility behavior.
- /tmp/pi-mono/packages/ai/test/openai-codex-stream.test.ts — Codex session/cache headers and reasoning handling.
- /tmp/pi-mono/packages/ai/test/openai-codex-cache-affinity-e2e.test.ts — Codex cache affinity e2e.
- /tmp/pi-mono/packages/ai/test/openai-responses-cache-affinity-e2e.test.ts — Responses cache affinity e2e.
- /tmp/pi-mono/packages/ai/test/openai-responses-copilot-provider.test.ts — copilot-provider response behavior.
- /tmp/pi-mono/packages/ai/test/google-thinking-signature.test.ts — thought-signature persistence.
- /tmp/pi-mono/packages/ai/test/google-shared-gemini3-unsigned-tool-call.test.ts — unsigned tool-call compatibility.
- /tmp/pi-mono/packages/ai/test/google-shared-convert-tools.test.ts — tool schema conversion for Google.
- /tmp/pi-mono/packages/ai/test/google-tool-call-missing-args.test.ts — missing-args resilience.
- /tmp/pi-mono/packages/ai/test/google-gemini-cli-retry-delay.test.ts — retry-delay extraction for CCA transport.
- /tmp/pi-mono/packages/ai/test/mistral-tool-schema.test.ts — Mistral tool schema behavior.
- /tmp/pi-mono/packages/ai/test/mistral-reasoning-mode.test.ts — Mistral reasoning mode mapping.
- /tmp/pi-mono/packages/ai/test/anthropic-tool-name-normalization.test.ts — Anthropic tool name casing behavior.
- /tmp/pi-mono/packages/ai/test/anthropic-eager-tool-input-compat.test.ts — Anthropic eager tool input compat flag.
- /tmp/pi-mono/packages/ai/test/anthropic-thinking-disable.test.ts — Anthropic reasoning off/on payloads.
- /tmp/pi-mono/packages/ai/test/anthropic-long-cache-retention-e2e.test.ts — Anthropic long cache retention behavior.
- /tmp/pi-mono/packages/ai/test/bedrock-thinking-payload.test.ts — Bedrock thinking payload specifics.
- /tmp/pi-mono/packages/ai/test/bedrock-endpoint-resolution.test.ts — Bedrock endpoint/region selection.
- /tmp/pi-mono/packages/ai/test/fireworks-models.test.ts — Fireworks provider model expectations.
- /tmp/pi-mono/packages/ai/test/total-tokens.test.ts — normalized total token accounting.
- /tmp/pi-mono/packages/ai/test/tokens.test.ts — token field semantics across adapters.

### B) per-provider docs (33)
- [OpenAI Responses API reference](https://platform.openai.com/docs/api-reference/responses/create?api-mode=responses) — tool/reasoning fields and response schema.
- [OpenAI reasoning guide](https://platform.openai.com/docs/guides/Reasoning?api-mode=respons) — replay and `reasoning.encrypted_content` expectations.
- [OpenAI function calling overview](https://help.openai.com/en/articles/8555517-function-calling-in-the-openai-api%23.woff2) — tool-calling behavior overview.
- [OpenAI Responses feature post](https://openai.com/index/new-tools-and-features-in-the-responses-api/) — responses tooling updates.
- [Anthropic API getting started](https://docs.anthropic.com/en/api/getting-started) — Messages API base contract.
- [Anthropic messages examples](https://docs.anthropic.com/en/api/messages-examples) — usage fields and stateless turn structure.
- [Anthropic tool-use overview](https://docs.anthropic.com/en/docs/agents-and-tools/tool-use/overview) — tool-use pricing/token notes.
- [Anthropic implement tool-use](https://docs.anthropic.com/en/docs/agents-and-tools/tool-use/implement-tool-use) — strict tool_result sequencing constraints.
- [Anthropic usage and cost API](https://docs.anthropic.com/en/api/usage-cost-api) — provider-side usage reporting model.
- [Gemini function calling](https://ai.google.dev/gemini-api/docs/function-calling) — function calling contract.
- [Gemini thought signatures](https://ai.google.dev/gemini-api/docs/thought-signatures) — thought-signature semantics.
- [Google Gemini thought signatures (hl=en)](https://ai.google.dev/gemini-api/docs/thought-signatures?hl=en) — same feature localized page used in search validation.
- [Vertex AI Generative AI docs](https://cloud.google.com/vertex-ai/generative-ai/docs) — Vertex managed transport context.
- [Bedrock Converse API user guide](https://docs.aws.amazon.com/bedrock/latest/userguide/conversation-inference-call.html) — unified converse request/response shape.
- [Bedrock Converse API reference](https://docs.aws.amazon.com/bedrock/latest/APIReference/API_runtime_Converse.html) — operation-level fields and token metrics.
- [Bedrock tool use guide](https://docs.aws.amazon.com/bedrock/latest/userguide/tool-use.html) — tool use flow and server/client tool calling.
- [Bedrock conversation overview](https://docs.aws.amazon.com/bedrock/latest/userguide/conversation-inference.html) — cross-model conversation abstraction.
- [Azure OpenAI Responses (MS Learn)](https://learn.microsoft.com/azure/ai-foundry/openai/how-to/work-with-code) — Azure responses model/deployment behavior.
- [Mistral function calling](https://docs.mistral.ai/capabilities/function_calling) — tool calling request/response pattern.
- [Mistral docs root](https://docs.mistral.ai/) — model/API catalog context.
- [OpenRouter tool calling docs](https://openrouter.ai/docs/features/tool-calling) — normalized tool-call interface claims.
- [OpenRouter prompt caching](https://openrouter.ai/docs/features/prompt-caching) — cache semantics by provider.
- [Groq tool use docs](https://console.groq.com/docs/tool-use?hss_channel=lcp-12994410) — tool-use patterns and modes.
- [Groq API reference](https://console.groq.com/docs/api-reference) — tool and parallel-calling params.
- [xAI function calling docs](https://docs.x.ai/developers/tools/function-calling) — tool-calling fields and parallel behavior.
- [xAI docs introduction](https://docs.x.ai/docs/introduction) — API scope/entrypoint.
- [Cerebras tool use docs](https://inference-docs.cerebras.ai/capabilities/tool-use) — tool flow with OpenAI-compat layer.
- [Cerebras OpenAI compatibility](https://inference-docs.cerebras.ai/resources/openai) — compatibility target and migration notes.
- [Fireworks function/tool calling](https://docs.fireworks.ai/guides/function-calling) — tool schema and streaming behavior.
- [DeepSeek function calling](https://api-docs.deepseek.com/guides/function_calling) — OpenAI-compatible function call loop.
- [MiniMax API overview](https://platform.minimax.io/docs/api-reference/api-overview) — model/tool-call capability statements.
- [MiniMax function call guide](https://platform.minimax.io/docs/guides/text-function-call) — explicit function-call usage.
- [Hugging Face chat completion task docs](https://huggingface.co/docs/api-inference/tasks/chat-completion) — OpenAI-compatible tool-call fields.
- [Vercel AI Gateway OpenAI-compatible API](https://vercel.com/docs/ai-gateway/openai-compat) — compatibility and endpoint semantics.
- [Vercel AI Gateway tool calls](https://vercel.com/docs/ai-gateway/openai-compat/tool-calls) — OpenAI-style function calling through gateway.
- [GitHub Models quickstart](https://docs.github.com/en/github-models/quickstart) — GitHub-hosted model API usage.

### C) comparison posts / ecosystem commentary (22)
- [Issue #2386: OpenRouter models support in pi](https://github.com/badlogic/pi-mono/issues/2386) — concrete provider-routing gap and config pressure.
- [Instagit: pi-ai multi-LLM provider integration](https://instagit.com/badlogic/pi-mono/pi-ai-multi-llm-provider-integration/) — third-party architecture summary.
- [Instagit: cross-provider handoffs in pi-ai](https://instagit.com/badlogic/pi-mono/how-cross-provider-handoffs-work-between-llm-models/) — narrative on transform/replay behavior.
- [Claude Code vs Cursor (Nevo)](https://nevo.systems/blogs/nevo-journal/claude-code-vs-cursor) — multi-provider positioning context.
- [SFEIR tool comparison](https://institute.sfeir.com/en/claude-code/claude-code-resources/tool-comparison/) — provider-flexibility framing in code agents.
- [Aider vs Cursor (popi.ai)](https://popi.ai/compare/code-editors/aider-vs-cursor/) — pricing/provider transparency commentary.
- [Claude Code vs Cursor (SitePoint)](https://www.sitepoint.com/claude-code-vs-cursor-comparison/) — model-routing comparison context.
- [Cursor vs Claude Code (DeployBase)](https://deploybase.ai/articles/cursor-vs-claude-code) — provider-model switching discussion.
- [Cursor vs Claude Code (Leanware)](https://www.leanware.co/insights/cursor-vs-claude-code-comparison) — ecosystem comparison signal.
- [Cursor vs Claude Code (Decode)](https://decode.agency/article/cursor-vs-claude-code/) — enterprise positioning signal.
- [OpenAI + Cerebras partnership](https://openai.com/index/cerebras-partnership) — provider infra market signal.
- [GitHub Models API changelog](https://github.blog/changelog/2025-05-15-github-models-api-now-available) — hosted model API ecosystem movement.
- [Vercel changelog: Responses API support](https://vercel.com/changelog/ai-gateway-supports-openais-responses-api) — gateway normalization trend.
- [OpenRouter state-of-AI report](https://openrouter.ai/assets/State-of-AI.pdf) — provider routing and market usage framing.
- [TokenMix Anthropic API article](https://tokenmix.ai/blog/anthropic-messages-api-documentation-examples-2026) — non-official but current API commentary.
- [TechRadar article on tool-use share](https://www.techradar.com/pro/anthropic-claims-half-of-its-ai-agent-tool-calls-are-to-do-with-software-engineering) — public signal on tool-use concentration.
- [OpenRouter tool-calling models collection](https://openrouter.ai/collections/tool-calling-models) — ecosystem inventory angle.
- [Vercel AI Gateway capabilities page](https://vercel.com/docs/ai-gateway/capabilities) — cross-provider normalization claims for reasoning.
- [Hugging Face inference providers index](https://huggingface.co/docs/api-inference/index) — aggregator trend for unified provider access.
- [Hugging Face inference providers overview](https://huggingface.co/docs/api-inference) — OpenAI-compatible proxy layer framing.
- [Cerebras models overview](https://inference-docs.cerebras.ai/models/overview) — external provider catalog trend.
- [Fireworks getting started](https://docs.fireworks.ai/getting-started/introduction) — OpenAI-migration and tool-calling messaging.

## Sources cited in finding
- finding §Summary -> /tmp/pi-mono/packages/ai/src/stream.ts; /tmp/pi-mono/packages/ai/src/api-registry.ts; /tmp/pi-mono/packages/coding-agent/src/core/agent-session.ts; /tmp/pi-mono/packages/ai/src/providers/transform-messages.ts
- finding §Building blocks / concepts -> /tmp/pi-mono/packages/ai/src/types.ts; /tmp/pi-mono/packages/coding-agent/src/core/model-registry.ts; /tmp/pi-mono/packages/ai/src/providers/simple-options.ts
- finding §Code refs -> /tmp/pi-mono/packages/ai/src/models.generated.ts; /tmp/pi-mono/packages/ai/src/providers/register-builtins.ts; /tmp/pi-mono/packages/coding-agent/src/modes/interactive/interactive-mode.ts; /tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts
- finding §Code refs (external) -> https://platform.openai.com/docs/api-reference/responses/create?api-mode=responses ; https://docs.anthropic.com/en/docs/agents-and-tools/tool-use/implement-tool-use ; https://ai.google.dev/gemini-api/docs/thought-signatures ; https://docs.aws.amazon.com/bedrock/latest/userguide/tool-use.html
- finding §Gotchas / surprises -> /tmp/pi-mono/packages/ai/src/index.ts ; /tmp/pi-mono/packages/ai/src/models.generated.ts ; /tmp/pi-mono/packages/ai/src/providers/transform-messages.ts ; /tmp/pi-mono/packages/coding-agent/src/core/model-registry.ts ; https://github.com/badlogic/pi-mono/issues/2386
