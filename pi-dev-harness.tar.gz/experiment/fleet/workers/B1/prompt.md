# Worker B1 — extension system internals

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

25+ hook lifecycle, TS API, hot-reload, packaging, sub-agent extensions, tool-exec interception.

## Sources you own (do not touch others')

- `pi-mono/packages/coding-agent/src/extensions/` + `hooks/`
- Extension example dir / starter
- Mario's blog posts on extensions
- oh-my-pi as a real extension example

## Out of scope (other workers cover)

- Skills/prompts/themes (B2)
- Ecosystem catalog (B3)
- pi CLI translation (C2)

## Source-mix target (per plan 05)

70% source + example exts, 30% Mario writeups + community exts. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/B1/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/B1/output/` — use absolute paths.
