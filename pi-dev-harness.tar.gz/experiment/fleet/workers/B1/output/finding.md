## Summary
- pi’s extension system is a typed event+tool runtime centered on `ExtensionAPI.on(...)`, with 28 registered event names spanning session, agent, model, input, and tool lifecycles (`src/core/extensions/types.ts:1074`, `src/core/extensions/types.ts:1110`).
- Tool interception is now installed at `AgentSession` (`beforeToolCall`/`afterToolCall`) instead of wrapper-level interception, while wrappers only inject extension context into tool execution (`src/core/agent-session.ts:373`, `src/core/agent-session.ts:396`, `src/core/extensions/wrapper.ts:5`).
- Hot reload is full runtime replacement: emit `session_shutdown`, reload resources/settings, rebuild runtime/tool registry, then emit `session_start` with `reason: "reload"` and run extension resource discovery (`src/core/agent-session.ts:2371`, `src/core/agent-session.ts:2389`, `docs/extensions.md:1136`).

## Building blocks / concepts
- `ExtensionFactory`: default-exported sync/async factory; async startup is awaited before `session_start`/`resources_discover` (`src/core/extensions/types.ts:1357`, `docs/extensions.md:179`).
- `ExtensionRuntime`: loader creates shared runtime with throwing action stubs until runner binding; this prevents action calls during load (`src/core/extensions/loader.ts:134`, `src/core/extensions/types.ts:1513`).
- `ExtensionRunner`: binds runtime actions/context, dispatches handlers in extension order, and exposes typed emit paths (`src/core/extensions/runner.ts:262`, `src/core/extensions/runner.ts:676`).
- `Discovery+packaging`: extension entries come from project/global extension dirs, explicit paths, and `package.json.pi.extensions` manifests with `index.ts|index.js` fallback (`src/core/extensions/loader.ts:476`, `src/core/extensions/loader.ts:560`, `docs/packages.md:108`).
- `Command-vs-event context split`: session-control methods (`reload`, `newSession`, `fork`, `switchSession`) only exist on `ExtensionCommandContext` to avoid deadlock-prone usage from general handlers/tools (`src/core/extensions/types.ts:331`, `docs/extensions.md:940`).
- `Subagent extension pattern`: implemented as separate `pi` subprocesses in JSON mode (`--mode json -p --no-session`) for isolated context windows (`examples/extensions/subagent/index.ts:12`, `examples/extensions/subagent/index.ts:265`).

## Code refs
- Event surface is overload-defined in `ExtensionAPI.on(...)` with session/tool/input/provider hooks: `src/core/extensions/types.ts:1074`-`1110`.
- `tool_call` input is mutable and can block execution; no re-validation after mutation: `src/core/extensions/types.ts:807`-`813`, `docs/extensions.md:648`-`654`.
- `tool_result` patch chaining (`content/details/isError`) is middleware-style and tested: `src/core/extensions/runner.ts:710`-`757`, `test/extensions-runner.test.ts:657`-`698`.
- Agent-level interception wiring lives in `AgentSession._installAgentToolHooks()`: `src/core/agent-session.ts:373`-`421`.
- Wrapper explicitly states interception is not handled there anymore: `src/core/extensions/wrapper.ts:5`-`6`.
- Runtime stale-context invalidation string and guard: `src/core/extensions/loader.ts:164`-`168`, `src/core/extensions/runner.ts:462`-`474`.
- Provider registration queue before bind and immediate effect after bind: `src/core/extensions/loader.ts:169`-`176`, `src/core/extensions/runner.ts:297`-`331`, `test/extensions-runner.test.ts:725`-`762`.
- `/reload` command UX guardrails (no stream/compaction overlap) and runtime refresh: `src/modes/interactive/interactive-mode.ts:4745`-`4753`, `src/modes/interactive/interactive-mode.ts:4782`-`4808`.
- Reload semantics contract for extension authors: `docs/extensions.md:1121`-`1143`.
- Extension discovery order/locations: `src/core/extensions/loader.ts:579`-`606`, `docs/extensions.md:111`-`119`.
- Package manifest contract for distributable extension bundles: `docs/packages.md:108`-`123`, `examples/extensions/with-deps/package.json:11`-`18`.
- Subagent example capabilities and security caveat: `examples/extensions/subagent/README.md:7`-`13`, `examples/extensions/subagent/README.md:55`-`66`.
- Maintainer positioning (“no built-in sub-agents/plan mode/MCP”) tied to extensibility: [mariozechner.at post](https://mariozechner.at/posts/2025-11-30-pi-coding-agent/) and [pi.dev](https://pi.dev/).

## Examples
```ts
// 1) Minimal extension tool
import { Type } from "@mariozechner/pi-ai";
import { defineTool, type ExtensionAPI } from "@mariozechner/pi-coding-agent";

export default function (pi: ExtensionAPI) {
  pi.registerTool(defineTool({
    name: "hello",
    label: "Hello",
    description: "A simple greeting tool",
    parameters: Type.Object({ name: Type.String() }),
    async execute(_id, params) {
      return { content: [{ type: "text", text: `Hello, ${params.name}!` }], details: {} };
    },
  }));
}
```
Source: `examples/extensions/hello.ts:5`-`26`.

```ts
// 2) Preflight interception (block destructive bash)
import { isToolCallEventType, type ExtensionAPI } from "@mariozechner/pi-coding-agent";

export default function (pi: ExtensionAPI) {
  pi.on("tool_call", async (event) => {
    if (isToolCallEventType("bash", event) && event.input.command.includes("rm -rf")) {
      return { block: true, reason: "Dangerous command" };
    }
  });
}
```
Source: `docs/extensions.md:657`-`671`.

```ts
// 3) Safe reload entrypoint from command context
import type { ExtensionAPI } from "@mariozechner/pi-coding-agent";

export default function (pi: ExtensionAPI) {
  pi.registerCommand("reload-runtime", {
    description: "Reload extensions, skills, prompts, and themes",
    handler: async (_args, ctx) => { await ctx.reload(); return; },
  });
}
```
Source: `examples/extensions/reload-runtime.ts:11`-`20`.

## Gotchas / surprises
- `tool_call` handlers can mutate `event.input` and execution proceeds without re-validation; this is powerful but easy to misuse (`docs/extensions.md:648`-`654`).
- Extension runtime action methods are intentionally invalid during factory load; calling `pi.sendMessage()` too early throws (`src/core/extensions/loader.ts:134`-`137`, `docs/extensions.md:179`).
- Reload does not “teleport” currently running handler state: post-`await ctx.reload()` code still executes in old call frame (`docs/extensions.md:1138`-`1141`).
- Built-in tool override is name-based; registering `read` shadows core behavior, which is great for policy wrappers but can silently drift expected semantics (`examples/extensions/tool-override.ts:69`-`74`, `docs/extensions.md:2481`).
- Upstream package exports `./hooks` (`package.json`) but current source tree is extension-centric; this compatibility seam can confuse source readers (`package.json:19`-`22`).
- Sub-agents are “not built-in” at product philosophy level, yet a first-party extension example implements them via subprocess orchestration; distinction is core-vs-extension, not capability absence (`https://pi.dev/`, `examples/extensions/subagent/index.ts:265`).
- Fork divergence matters: `oh-my-pi` still documents both hooks and extensions and uses `.omp` paths/namespaces, so tutorials can be subtly incompatible with upstream `pi-mono` assumptions (`/tmp/oh-my-pi/packages/coding-agent/examples/hooks/README.md:1`, `/tmp/oh-my-pi/packages/coding-agent/examples/extensions/README.md:12`).

## Open questions
- Is `./hooks` export in upstream package.json still intentionally supported long-term, or transitional (`package.json:19`-`22`)?
- Should mutable `tool_call` args support optional post-mutation validation guardrails for safer policy extensions (`docs/extensions.md:653`)?
- How stable is extension ordering semantics for conflict cases (same command name, same shortcut, same tool override) across future releases (`src/core/extensions/runner.ts:508`, `src/core/extensions/runner.ts:413`)?
- Self-critique: source breadth floor was exceeded (189), but external-domain evidence is noisier than code evidence; high-confidence claims in this finding are intentionally code/doc anchored.

## Cross-refs
- B2 boundary: `resources_discover` feeds skills/prompts/themes paths and reload reasons; detailed behavior belongs to skills/prompts/themes track (`src/core/extensions/runner.ts:944`, `docs/extensions.md:334`).
- B3 boundary: package/gallery ecosystem breadth and popularity claims should be consolidated there (this finding only sampled ecosystem for extension internals context) ([pi.dev/packages](https://pi.dev/packages)).
- C2 boundary: CLI-level command UX and mode transport specifics (`--mode rpc/json`, slash parsing) are touched only where they affect extension lifecycle (`src/modes/interactive/interactive-mode.ts:4745`, `src/core/slash-commands.ts:38`).
