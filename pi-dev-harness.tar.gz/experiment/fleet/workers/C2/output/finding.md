## Summary
- pi supports headless single-shot and JSONL streaming directly: `-p` for one-shot and `--mode json` for newline-delimited event output; `--mode rpc` is the stronger machine-control channel. (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:21`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:22`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:103`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:10`)
- Resume/session continuity maps to `--continue`, `--resume`, `--session <path|id>` in CLI, and to `switch_session` / `get_state.sessionId` in RPC. (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:23`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:24`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:25`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:426`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:558`)
- Main portability gap versus codex-style flags is cwd override: no top-level `pi --cd` flag in help, but embedded RPC client supports process-level `cwd` in spawn options. (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:15`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:26`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:87`)

| Capability | claude/codex pattern | pi equivalent | Status |
|---|---|---|---|
| Headless one-shot run | `claude -p`, `codex exec` | `pi -p "..."` (print mode) (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:22`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:32`) | ✅ |
| Stream JSONL | `--output-format stream-json`, `--json` | `pi --mode json -p "..."` or `pi --mode rpc` (JSONL protocol) (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:21`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:105`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:10`) | ✅ |
| Session resume | `--resume <sid>` | `--continue`, `--resume`, `--session <path|id>`; RPC `switch_session` (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:23`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:24`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:25`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:558`) | ✅ (different UX) |
| Per-turn cost/tokens | event usage/cost fields | `AssistantMessage.usage.{input,output,cacheRead,cacheWrite,totalTokens,cost.*}`; RPC `get_session_stats` (`/tmp/pi-mono/packages/ai/src/types.ts:189`, `/tmp/pi-mono/packages/ai/src/types.ts:195`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:172`) | ⚠️ (event wrapper type outside C2 slice) |
| Tool allowlist | `--allowed-tools`, sandbox/tool flags | `--tools`, `--no-tools`, `--no-builtin-tools` (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:31`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:32`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:33`) | ✅ |
| CWD override | `--cd` (codex) | no top-level CLI flag seen; RPC embed uses `RpcClientOptions.cwd` (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:15`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:29`) | ⚠️ (CLI gap) |
| Model swap | `--model` | startup `--provider/--model`; runtime RPC `set_model`/`cycle_model` (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:16`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:17`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:448`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:458`) | ✅ |

## Building blocks / concepts
- Print mode (`text`/`json`): single-shot execution path that subscribes to session events and either prints final assistant text (`text`) or raw JSON event lines (`json`). (`/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:17`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:103`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:128`)
- RPC mode protocol: long-lived stdin/stdout JSONL command-response channel with typed commands (prompt/state/model/session/etc.) and asynchronous events. (`/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:48`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:19`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:111`)
- Strict JSONL framing: serializer appends `\n`; reader splits on LF only (not readline Unicode separators). (`/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:10`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:21`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:33`)
- Unified usage schema: assistant usage includes `input`, `output`, `cacheRead`, `cacheWrite`, `totalTokens`, and nested `cost.*`, which is the core shape for cost/token extraction. (`/tmp/pi-mono/packages/ai/src/types.ts:189`, `/tmp/pi-mono/packages/ai/src/types.ts:194`, `/tmp/pi-mono/packages/ai/src/types.ts:195`, `/tmp/pi-mono/packages/ai/src/types.ts:219`)
- Model control surface: startup model/provider selection via CLI flags and runtime model swap via RPC (`set_model`, `cycle_model`). (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:16`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:17`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:448`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:458`)

## Code refs
- Headless one-shot run: `/tmp/pi-mono/packages/coding-agent/pi-help.txt:22`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:32`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:120`.
- JSONL stream (CLI print mode): `/tmp/pi-mono/packages/coding-agent/pi-help.txt:21`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:104`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:105`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:112`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:114`.
- JSONL stream (RPC mode): `/tmp/pi-mono/packages/coding-agent/pi-help.txt:21`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:53`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:10`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/jsonl.ts:21`.
- Session resume/continuity: `/tmp/pi-mono/packages/coding-agent/pi-help.txt:23`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:24`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:25`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:98`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:99`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:434`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:435`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:558`.
- Per-turn cost/tokens: `/tmp/pi-mono/packages/ai/src/types.ts:189`, `/tmp/pi-mono/packages/ai/src/types.ts:194`, `/tmp/pi-mono/packages/ai/src/types.ts:195`, `/tmp/pi-mono/packages/ai/src/types.ts:200`, `/tmp/pi-mono/packages/ai/src/types.ts:219`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:103`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:341`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:172`.
- Tool allowlist: `/tmp/pi-mono/packages/coding-agent/pi-help.txt:31`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:32`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:33`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:135`.
- CWD override: `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:29`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:87`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:15`.
- Model swap: `/tmp/pi-mono/packages/coding-agent/pi-help.txt:16`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:17`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:31`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:448`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:458`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:123`.

## Examples
```bash
# 1) Headless one-shot (closest to `claude -p` / `codex exec`)
HOME=/tmp node /tmp/pi-mono/packages/coding-agent/dist/cli.js -p "summarize this repo"

# 2) JSONL event stream from print mode
HOME=/tmp node /tmp/pi-mono/packages/coding-agent/dist/cli.js --mode json -p "list files"

# 3) Restrict tools (allowlist)
HOME=/tmp node /tmp/pi-mono/packages/coding-agent/dist/cli.js --tools read,grep,find,ls -p "review src/"

# 4) Resume by explicit session path/id
HOME=/tmp node /tmp/pi-mono/packages/coding-agent/dist/cli.js --session <path-or-partial-uuid> -p "continue"
```

```json
{"id":"1","type":"get_state"}
{"id":"2","type":"set_model","provider":"openai","modelId":"gpt-4o"}
{"id":"3","type":"switch_session","sessionPath":"<session-file-or-id>"}
{"id":"4","type":"get_session_stats"}
```

## Gotchas / surprises
- `--help` still initializes session storage; in this sandbox it failed until `HOME=/tmp` was set. (`/tmp/pi-mono/packages/coding-agent/src/cli.ts:18`, `/tmp/pi-mono/packages/coding-agent/pi-help.txt:128`)
- No explicit CLI cwd flag in help output; cwd control exists in RPC client embedding path, not as first-class CLI switch. (`/tmp/pi-mono/packages/coding-agent/pi-help.txt:15`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-client.ts:29`)
- JSON mode emits a header line before event stream, so consumers must handle non-event first record. (`/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:111`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:114`)
- Print mode JSON writes raw subscribed events without schema narrowing in this file; downstream parser must tolerate event variants from `session.subscribe`. (`/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:103`, `/tmp/pi-mono/packages/coding-agent/src/modes/print-mode.ts:105`)
- RPC mode supports many operations beyond prompting (bash, compaction, clone/fork, model cycling), so an adapter that assumes only `prompt`/`response` will underutilize pi. (`/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:19`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:56`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:69`)
- `packages/api` appears renamed/reorganized as `packages/ai`; C2 source-owner path needed remap to `packages/ai/src/*`. (`/tmp/pi-mono/packages/ai/src/index.ts:4`)

## Open questions
- Exact top-level event field names for per-turn usage in `AgentSessionEvent` are not declared in C2-owned files; usage shape is clear at `AssistantMessage.usage`, but event wrapping comes from core/agent types outside this slice. (`/tmp/pi-mono/packages/ai/src/types.ts:219`)
- Whether CLI supports hidden cwd override flags not shown in help requires reading CLI arg parser (outside strict C2 source list).
- `get_session_stats` return schema (`SessionStats`) is imported from core session module outside this slice; cost aggregation fields need that file for strict guarantees. (`/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-types.ts:172`)
- Self-critique: mapping is high-confidence for flags/protocols, lower-confidence for event payload envelope because C2 scope excludes agent-core event type definitions.

## Cross-refs
- Extension hook lifecycle behavior surfaced while inspecting RPC extension UI bridging, but detailed hook lifecycle belongs to B1. (`/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:332`)
- Skill/prompt command discovery appears in RPC `get_commands` (`source: skill|prompt|extension`), but skills format/details belong to B2. (`/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:617`, `/tmp/pi-mono/packages/coding-agent/src/modes/rpc/rpc-mode.ts:638`)
