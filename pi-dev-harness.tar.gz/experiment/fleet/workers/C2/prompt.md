# Worker C2 — pi CLI translation table

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

For each capability my fleet skills require (headless run, stream JSONL, session resume, per-turn cost, tool allowlist, cwd override, model swap), find the pi equivalent.

## Sources you own (do not touch others')

- pi-mono/packages/coding-agent/src/cli.ts (entry)
- pi-mono/packages/coding-agent/src/modes/print/
- pi-mono/packages/coding-agent/src/modes/rpc/
- pi-mono/packages/api/
- pi --help output (clone + run)

## Out of scope (other workers cover)

- Extension hook lifecycle (B1)
- Skills format (B2)

## Source-mix target (per plan 05)

100% pi-mono source. Build the translation table from code, not docs. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/C2/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/C2/output/` — use absolute paths.
