# Shared brief — every research worker (A*, B*, C*)

## Canonical plans (read first)

- `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/01-prelim-research-scope.md`
- `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/02-research-mece-distribution.md` (worker briefs, MECE source partition)
- `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/03-pi-fleet-portability.md` (C-bucket detail)
- `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/04-synthesis-multi-doc.md` (downstream consumers)
- `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/05-fleet-config-and-targets.md` (health targets + citation contract — MANDATORY)

## Health targets (floor; go deeper if budget allows)

- ≥ 100 distinct sources consulted
- ≥ 30 unique domains/origins
- ≥ 10 primary sources (source code, official docs, maintainer-authored)
- ≥ 5 contradicting or surprising signals noted
- Per-track source-mix tailoring per plan 05 table

If you cannot hit 100 sources within $10, record WHY in "Open questions". Do not fake the count.

## Citation contract (MANDATORY — produce TWO files)

1. `$FLEET_ROOT/workers/{id}/output/finding.md` — the finding
2. `$FLEET_ROOT/workers/{id}/output/sources.md` — exploration log, ≥100 lines, frontmatter with `total_sources`, `unique_domains`, `primary_sources`

In-finding citations: `[label](url)` or `path:line`. NO bare claims.

## Required finding sections (verbatim headings — synthesis depends on them)

```
## Summary
(3 bullets)

## Building blocks / concepts
(named, defined)

## Code refs
(file:line for every claim)

## Examples
(minimal runnable snippets)

## Gotchas / surprises
(at least 5)

## Open questions
(unresolved, feeds S6)

## Cross-refs
(things you saw belonging to other tracks — note, do not duplicate)
```

## Method

1. Re-read this brief + your per-worker prompt.
2. Read your assigned MECE source slice (plan 02 / 03 source-partition tables). Do NOT touch other workers' sources.
3. Clone `https://github.com/badlogic/pi-mono` to `/tmp/pi-mono` if not already there (only workers needing source code).
4. Take notes inline, then write final `finding.md` + `sources.md`.

## Stop conditions (first wins)

1. Budget hit ($10).
2. All health-target floors hit AND finding sections complete AND ≥1 self-critique noted.
3. Source pool exhausted (state explicitly).

## Output destination

Save ALL output files to `$FLEET_ROOT/workers/{id}/output/` — use absolute paths.
