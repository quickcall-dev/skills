# Worker C1 — fleet skill shell-out call-site audit

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Enumerate every place my fleet skills shell out to claude/codex. Classify each call by what pi must provide to substitute.

## Sources you own (do not touch others')

- /home/sagar/skills/skills/dag-fleet/scripts/launch.sh
- /home/sagar/skills/skills/dag-fleet/scripts/relaunch-worker.sh
- /home/sagar/skills/skills/worktree-fleet/scripts/launch.sh
- /home/sagar/skills/skills/iterative-fleet/scripts/launch.sh
- /home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh
(read-only — DO NOT EDIT)

## Out of scope (other workers cover)

- pi internals (C2)
- redesign verdicts (C3)

## Source-mix target (per plan 05)

100% local — every script + every flag + every JSONL field referenced. No web research needed (skip 100-source floor; explain why in finding). Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/C1/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/C1/output/` — use absolute paths.
