## Summary
- Fleet shell-out execution is centralized through `build_inner_cmd` in 4/5 launch scripts; only `dag-fleet/scripts/relaunch-worker.sh` directly hardcodes `claude -p` with explicit CLI flags (`/home/sagar/skills/skills/dag-fleet/scripts/relaunch-worker.sh:242`).
- To substitute `claude/codex`, `pi` must provide: non-interactive prompt execution, JSONL streaming with stable terminal/cost/usage fields, per-run model/budget/tool controls, resumable session identity, and cwd/sandbox/tool-search controls (call-site params at `/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:554`, `/home/sagar/skills/skills/worktree-fleet/scripts/launch.sh:349`, `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:719`, `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:403`).
- Event consumers already encode provider-specific assumptions (`result` vs `turn.completed`, `total_cost_usd`, `usage.input_tokens/output_tokens`, and Claude `subtype`) that must be normalized by an adapter if `pi` event shapes differ (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:309`, `/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:354`, `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:234`, `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:218`).

## Building blocks / concepts
`build_inner_cmd` abstraction
Defined as the launcher-level provider abstraction boundary: all major launchers pass a structured option set and execute returned shell (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:554`, `/home/sagar/skills/skills/worktree-fleet/scripts/launch.sh:349`, `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:719`, `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:403`).

Direct CLI hardcode path
`relaunch-worker.sh` bypasses abstraction and inlines `claude -p --dangerously-skip-permissions --output-format stream-json ...` (`/home/sagar/skills/skills/dag-fleet/scripts/relaunch-worker.sh:242`).

Terminal-event contract
Completion checks are event-type driven and provider-coupled: `result` (Claude), `turn.completed`/`turn.failed` (Codex) (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:309`, `/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:316`).

Cost contract
Cost is exact when `total_cost_usd` exists, otherwise estimated from token usage fields (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:369`, `/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:378`, `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:235`, `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:249`).

Search-mode tool escalation
Autoresearch mutates command surface for web search: Codex via extra config flag; Claude via string replacement to add `--tools default` (`/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:398`, `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:423`).

## Code refs
Call-site inventory (shell-outs to `claude/codex`, including generated/orchestrated paths):

| Call site | Where | Current mechanism | What `pi` must provide |
|---|---|---|---|
| DAG worker launch | `/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:554` | `build_inner_cmd` output executed in tmux via runner script (`:589`, `:619`) | Adapter entrypoint that accepts prompt file, emits JSONL stream, supports model/budget/tools/session/cwd/sandbox arguments from passed options (`:555-571`) |
| DAG selective relaunch | `/home/sagar/skills/skills/dag-fleet/scripts/relaunch-worker.sh:242` | Direct `cat prompt | claude -p ... | tee session.jsonl` (`:243-255`) | Native `pi` non-interactive prompt ingestion + stream output + equivalent controls for permissions, model, turns, budget, session name, tool restrictions |
| Worktree worker launch | `/home/sagar/skills/skills/worktree-fleet/scripts/launch.sh:349` | `build_inner_cmd` in per-worker git worktree, tmux spawn (`:371`) | Same adapter as DAG plus strict cwd/worktree targeting and branch env compatibility (`:350`, `:362`) |
| Iterative initial spawn + replay | `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:719` and generated orchestrator spawn (`:410`) | `build_inner_cmd` persisted into `.worker-cmd-<id>.sh`, then reused each iteration (`:741`) | Stable, replayable command form for repeated execution; deterministic prompt-file substitution compatibility (`:407`) |
| Autoresearch per-iteration agent | `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:403` | `build_inner_cmd` each loop, executed via `bash -c` (`:427`) | Fast one-shot loop execution with predictable JSONL logs per iteration and budget/turn limits |
| Autoresearch search-mode escalation | `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:398` and `:423` | Codex: `-c 'web_search="live"'`; Claude: inject `--tools default` | `pi` equivalent for enabling web search/tools per iteration without brittle text substitution |

Flags/options referenced in scripts (must be mappable by `pi` adapter):
- Direct Claude flags in relaunch path: `-p`, `--dangerously-skip-permissions`, `--output-format stream-json`, `--verbose`, `--model`, `--fallback-model`, `--max-turns`, `--max-budget-usd`, `--name`, `--disallowed-tools` (`/home/sagar/skills/skills/dag-fleet/scripts/relaunch-worker.sh:242`).
- Search-mode Claude injection: `--tools default` (`/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:423`).
- Search-mode Codex extra config: `-c 'web_search="live"'` (`/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:398`).
- `build_inner_cmd` option surface used by launchers: `--cwd`, `--fleet-root`, `--worker-id`, `--worker-prompt`, `--worker-model`, `--fallback-model`, `--max-turns`, `--max-budget`, `--session-name`, `--disallowed-tools`, `--session-jsonl`, `--worker-dir`, `--provider`, `--reasoning-effort`, `--codex-sandbox`, `--codex-extra-flags`, plus worktree-only `--extra-exports` (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:555`, `/home/sagar/skills/skills/worktree-fleet/scripts/launch.sh:350`, `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:720`, `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:404`).

JSONL/event fields referenced by fleet scripts (must be present or normalized):
- `type` terminal routing: `result`, `turn.completed`, `turn.failed` (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:316`).
- Claude success subtype check: `subtype` (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:434`).
- Claude cost field: `total_cost_usd` (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:369`, `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:235`, `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:220`).
- Codex/estimated usage fields: `usage.input_tokens`, `usage.output_tokens` (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:378`, `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:243`).
- Autoresearch assistant-shaped usage: `message.model`, `message.usage.input_tokens`, `message.usage.output_tokens`, `message.usage.cache_read_input_tokens`, `message.usage.cache_creation_input_tokens` (`/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:244`, `/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:251`).

## Examples
```bash
# Direct hardcoded path today (relaunch-worker)
cat "$WORKER_PROMPT" | claude -p \
  --dangerously-skip-permissions \
  --output-format stream-json \
  --model "$WORKER_MODEL" \
  --max-turns "$MAX_TURNS" \
  --max-budget-usd "$MAX_BUDGET" \
  --name "$SESSION_NAME" \
  --disallowed-tools "$DISALLOWED_TOOLS" \
  2>&1 | tee "$WORKER_SESSION_JSONL"
```

```bash
# Provider-abstracted path today (all other launchers)
AGENT_CMD=$(build_inner_cmd \
  --cwd "$CWD" --worker-prompt "$PROMPT" --provider "$PROVIDER" \
  --worker-model "$MODEL" --fallback-model "$FALLBACK" \
  --max-turns "$MAX_TURNS" --max-budget "$BUDGET" \
  --session-jsonl "$JSONL" --codex-sandbox "$SANDBOX")
bash -c "$AGENT_CMD"
```

```bash
# Terminal/cost parsing contract consumed by launcher logic
last_type=$(tail -1 "$jsonl" | jq -r '.type')
# expected terminal: result | turn.completed | turn.failed
cost=$(grep -m1 '"type":"result"' "$jsonl" | jq -r '.total_cost_usd // 0')
```

## Gotchas / surprises
- `relaunch-worker.sh` hard-requires `claude` and directly embeds Claude-only flags, so provider portability is asymmetric today (`/home/sagar/skills/skills/dag-fleet/scripts/relaunch-worker.sh:114`, `/home/sagar/skills/skills/dag-fleet/scripts/relaunch-worker.sh:242`).
- Dependency-gating treats `turn.failed` as terminal and still launches downstream workers, so failure propagation is intentionally weak (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:438`).
- Codex cost handling is heuristic token math in multiple scripts; no unified exact-cost contract for non-Claude providers (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:371`, `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:236`).
- Iterative orchestration depends on replaying raw shell command strings from `.worker-cmd-*.sh`, which increases quoting/substitution fragility for any new provider adapter (`/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:741`, `/home/sagar/skills/skills/iterative-fleet/scripts/launch.sh:405`).
- Autoresearch search enablement is implemented by command-string mutation (`sed` on `claude -p`) rather than structured options, which is brittle for command-shape changes (`/home/sagar/skills/skills/autoresearch-fleet/scripts/launch.sh:423`).
- Worktree fleet has provider-conditional worker-type override logic specific to Claude constraints (`/home/sagar/skills/skills/worktree-fleet/scripts/launch.sh:321`), so policy parity for `pi` needs explicit design.

## Open questions
- Does the existing `build_inner_cmd` contract already have enough extensibility to add `provider=pi` without changing call sites, or will new options/events force script changes in all four launchers (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:554`)?
- Should `relaunch-worker.sh` be migrated to `build_inner_cmd` first to eliminate the hardcoded Claude path before any `pi` integration (`/home/sagar/skills/skills/dag-fleet/scripts/relaunch-worker.sh:235`)?
- Which canonical terminal/cost event schema should the fleet standardize on (`result` vs `turn.completed`) to avoid per-provider conditionals (`/home/sagar/skills/skills/dag-fleet/scripts/launch.sh:309`)?
- C1 source-mix is explicitly 100% local (plan 05), so no web research was needed; this slice is source-pool-limited to assigned scripts/plans and cannot satisfy multi-domain web breadth by design (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/05-fleet-config-and-targets.md:69`).
- Self-critique: because C1 scope excluded `lib/worker-spawn.sh`, this audit can prove call-site contracts but not the exact final `claude/codex/pi` command emitted inside that helper.

## Cross-refs
- Precise `pi` CLI/JSON event equivalence and gap verdicts belong to C2 (pi CLI surface mapping), not this call-site audit (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/03-pi-fleet-portability.md:68`).
- Architecture-level choice of bash port vs pi-native RPC/extension redesign belongs to C3, especially replacing tmux orchestration and hook-based control loops (`/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/03-pi-fleet-portability.md:89`).
