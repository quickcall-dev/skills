# Worker A1 — pi.dev bootstrap (install + first-run)

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Install paths, AGENTS.md, SYSTEM.md, config files, env vars, first-run UX.

## Sources you own (do not touch others')

- `pi-mono/packages/coding-agent/README.md`
- `pi-mono/packages/coding-agent/src/cli.ts` (or entry-point file)
- `https://pi.dev/` landing page + install docs
- npm page `@mariozechner/pi-coding-agent`

## Out of scope (other workers cover)

- Tool internals (A2)
- Run modes (A3)
- Providers (A4)
- Sessions (A5)
- Extensions/skills (B1/B2)

## Source-mix target (per plan 05)

60% pi-mono code/docs, 30% blog/walkthroughs, 10% issues. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/A1/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/A1/output/` — use absolute paths.
