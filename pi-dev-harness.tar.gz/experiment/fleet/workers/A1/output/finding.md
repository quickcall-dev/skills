## Summary
- Pi bootstrap is a global npm install (`npm install -g @mariozechner/pi-coding-agent`) followed by either API-key auth (`ANTHROPIC_API_KEY`) or interactive `/login` provider auth inside `pi` (/tmp/pi-mono/packages/coding-agent/README.md:69, /tmp/pi-mono/packages/coding-agent/README.md:72, /tmp/pi-mono/packages/coding-agent/README.md:75, /tmp/pi-mono/packages/coding-agent/README.md:78, /tmp/pi-mono/packages/coding-agent/README.md:84, /tmp/pi-mono/packages/coding-agent/README.md:86).
- First-run behavior is strongly shaped by local files and flags: `AGENTS.md`/`CLAUDE.md` auto-loading, optional `SYSTEM.md` replacement/append, and `settings.json`/env-var overrides under `~/.pi/agent` or project-local `.pi/` (/tmp/pi-mono/packages/coding-agent/README.md:270, /tmp/pi-mono/packages/coding-agent/README.md:271, /tmp/pi-mono/packages/coding-agent/README.md:281, /tmp/pi-mono/packages/coding-agent/README.md:288, /tmp/pi-mono/packages/coding-agent/README.md:292, /tmp/pi-mono/packages/coding-agent/README.md:603).
- CLI entrypoint is intentionally minimal: it sets `process.title`, exports `PI_CODING_AGENT=true`, disables `emitWarning`, sets proxy-aware HTTP dispatcher, then delegates to `main(argv)` (/tmp/pi-mono/packages/coding-agent/src/cli.ts:12, /tmp/pi-mono/packages/coding-agent/src/cli.ts:13, /tmp/pi-mono/packages/coding-agent/src/cli.ts:14, /tmp/pi-mono/packages/coding-agent/src/cli.ts:16, /tmp/pi-mono/packages/coding-agent/src/cli.ts:18).

## Building blocks / concepts
- Global bootstrap command: install once globally, then invoke `pi` from project shells (/tmp/pi-mono/packages/coding-agent/README.md:72).
- Auth boot path: either env-var API key path or interactive `/login` path (/tmp/pi-mono/packages/coding-agent/README.md:75, /tmp/pi-mono/packages/coding-agent/README.md:86).
- Config roots: global `~/.pi/agent/*` plus project `.pi/*` overlays (/tmp/pi-mono/packages/coding-agent/README.md:270, /tmp/pi-mono/packages/coding-agent/README.md:271, /tmp/pi-mono/packages/coding-agent/README.md:603).
- Context-file injection: startup concatenates `AGENTS.md`/`CLAUDE.md` from global + parent dirs + cwd unless `--no-context-files` is set (/tmp/pi-mono/packages/coding-agent/README.md:281, /tmp/pi-mono/packages/coding-agent/README.md:282, /tmp/pi-mono/packages/coding-agent/README.md:284, /tmp/pi-mono/packages/coding-agent/README.md:288, /tmp/pi-mono/packages/coding-agent/README.md:544).
- System-prompt override path: `.pi/SYSTEM.md` or `~/.pi/agent/SYSTEM.md`; append-only supported via `APPEND_SYSTEM.md` and CLI flags (`--system-prompt`, `--append-system-prompt`) (/tmp/pi-mono/packages/coding-agent/README.md:292, /tmp/pi-mono/packages/coding-agent/README.md:552, /tmp/pi-mono/packages/coding-agent/README.md:553).
- First-run mode controls: `--no-session`, `--session`, `--fork`, tool allowlists, and `--no-*` resource toggles constrain startup footprint (/tmp/pi-mono/packages/coding-agent/README.md:517, /tmp/pi-mono/packages/coding-agent/README.md:520, /tmp/pi-mono/packages/coding-agent/README.md:526, /tmp/pi-mono/packages/coding-agent/README.md:544, /tmp/pi-mono/packages/coding-agent/README.md:546).

## Code refs
- Install command + quick-start auth flow: `/tmp/pi-mono/packages/coding-agent/README.md:69-91`.
- Settings path and telemetry toggle: `/tmp/pi-mono/packages/coding-agent/README.md:266-276`.
- AGENTS/CLAUDE context-file discovery + disable flag: `/tmp/pi-mono/packages/coding-agent/README.md:281-289`, `/tmp/pi-mono/packages/coding-agent/README.md:544`.
- SYSTEM prompt replacement/append semantics: `/tmp/pi-mono/packages/coding-agent/README.md:290-293`, `/tmp/pi-mono/packages/coding-agent/README.md:552-553`.
- Session and startup flags (`--session`, `--fork`, `--no-session`, resource toggles): `/tmp/pi-mono/packages/coding-agent/README.md:513-546`.
- Env vars controlling config and telemetry: `/tmp/pi-mono/packages/coding-agent/README.md:601-608`.
- Entrypoint behavior (`PI_CODING_AGENT`, warning suppression, dispatcher, main handoff): `/tmp/pi-mono/packages/coding-agent/src/cli.ts:12-18`.

## Examples
```bash
# 1) Install
npm install -g @mariozechner/pi-coding-agent

# 2) API-key first run
export ANTHROPIC_API_KEY=sk-ant-...
pi
```

```bash
# Subscription/OAuth first run (no API key env var)
pi
/login
```

```bash
# Safe-ish first-run in ephemeral + reduced-resource mode
pi --no-session --no-context-files --no-extensions --no-skills
```

```bash
# Pin custom config root for isolated bootstrap testing
PI_CODING_AGENT_DIR=/tmp/pi-agent-config pi --no-session
```

## Gotchas / surprises
- `npm install -g` had a real breakage window: issue #3280 reports `ETARGET` due version skew between `pi-agent-core` and `pi-ai` during publish sequencing ([issue #3280](https://github.com/badlogic/pi-mono/issues/3280), [registry metadata](https://registry.npmjs.org/@mariozechner/pi-coding-agent)).
- CLI docs emphasize four default tools early in Quick Start, but CLI reference lists seven built-ins (`read`, `bash`, `edit`, `write`, `grep`, `find`, `ls`), which can confuse first-run expectation-setting (/tmp/pi-mono/packages/coding-agent/README.md:89, /tmp/pi-mono/packages/coding-agent/README.md:530).
- Startup context loading walks parent directories by default; this is powerful but can silently import stale repo-level instructions if users do not notice loaded files in header (/tmp/pi-mono/packages/coding-agent/README.md:140, /tmp/pi-mono/packages/coding-agent/README.md:281, /tmp/pi-mono/packages/coding-agent/README.md:286).
- `process.emitWarning` is overridden to noop in CLI entrypoint; this reduces noise but can also hide runtime warning signals users expect during install/first-run troubleshooting (/tmp/pi-mono/packages/coding-agent/src/cli.ts:14).
- npm package page is Cloudflare-protected for non-browser fetches in this environment; automation should prefer registry API endpoints for machine-readable bootstrap checks ([npm package URL](https://www.npmjs.com/package/@mariozechner/pi-coding-agent), [registry API](https://registry.npmjs.org/@mariozechner/pi-coding-agent)).
- First-run security posture is intentionally minimal by design (no built-in permission popups); users should run in sandbox/container or add extension-based gates early ([pi.dev](https://pi.dev/), [blog rationale](https://mariozechner.at/posts/2025-11-30-pi-coding-agent/), [sandbox analysis](https://agent-safehouse.dev/docs/agent-investigations/pi)).

## Open questions
- Which install guardrail should be recommended in official bootstrap docs for publish-race failures (retry policy, pinning, or fallback version command)? ([issue #3280](https://github.com/badlogic/pi-mono/issues/3280))
- Should bootstrap docs include an explicit “clean-room first run” profile (`--no-context-files --no-session --no-extensions`) before users opt into richer defaults?
- Self-critique: this pass prioritized breadth/citation auditability over executing a full live OAuth + model chat smoke test across providers; that runtime validation is still outstanding for A1.

## Cross-refs
- Tool semantics and default/built-in tool behavior details belong to A2 (I only referenced tool names for bootstrap expectation-setting).
- Run-mode behavior (`--mode json`, `--mode rpc`, SDK wiring) belongs to A3.
- Provider normalization and model catalog depth belong to A4.
- Tree/session internals and persistence semantics beyond startup flags belong to A5.
- Extension/skills internals and packaging depth belong to B1/B2 (I only touched bootstrap entrypoints and install-facing mentions).
