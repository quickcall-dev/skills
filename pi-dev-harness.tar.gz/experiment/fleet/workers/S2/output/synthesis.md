---
title: "pi-beginner-onboarding"
audience: new pi.dev user
synthesis_of: [A1, A2, A3, A4, A5]
created: "2026-04-25"
---

# Pi Beginner Onboarding

## TL;DR

Install `@mariozechner/pi-coding-agent` globally, authenticate (API key env var or `/login`), then run `pi`. The agent ships seven built-in tools (`read`, `write`, `edit`, `bash`, `grep`, `find`, `ls`) with strict typed contracts, four execution modes (interactive TUI, one-shot text, one-shot JSONL, long-lived RPC), 25 model providers behind 10 API adapters with mid-session swap, and an append-only session-tree model where branches are pointer moves. New users mostly stumble on: silent context-file inheritance from parent dirs, `bash` treating any non-zero exit as a tool error, and resume-time cwd drift between sessions and projects.

This doc is a linear walkthrough. Each step links to the source finding — read those for full code refs and edge cases.

---

## 1. Install + first run

Source: [A1#Building blocks](../../A1/output/finding.md#building-blocks--concepts), [A1#Examples](../../A1/output/finding.md#examples).

```bash
# Install
npm install -g @mariozechner/pi-coding-agent

# API-key first run
export ANTHROPIC_API_KEY=sk-ant-...
pi

# OR: subscription / OAuth first run
pi
/login
```

Config roots: global `~/.pi/agent/*` plus project-local `.pi/*` overlays. Context files (`AGENTS.md`, `CLAUDE.md`) auto-load from global + every parent dir + cwd unless `--no-context-files`. System prompt overrideable via `.pi/SYSTEM.md` or `~/.pi/agent/SYSTEM.md` (or appended via `APPEND_SYSTEM.md` / `--append-system-prompt`). Full env-var + flag matrix: [A1#Code refs](../../A1/output/finding.md#code-refs).

Clean-room first run (recommended for first try):

```bash
pi --no-session --no-context-files --no-extensions --no-skills
```

---

## 2. Core tools — what each does + gotchas

Source: [A2#Building blocks](../../A2/output/finding.md#building-blocks--concepts), [A2#Examples](../../A2/output/finding.md#examples).

| Tool | Contract | Watch-out |
|------|----------|-----------|
| `read` | path + optional `offset`/`limit`; bounded by line/byte caps with continuation hints | Falls back to suggesting `sed` if first line exceeds byte cap — pushes model toward shell-edit patterns. Image MIME auto-routes to attachment mode. |
| `write` | always overwrites + `mkdir -p` parent dirs; serialized through file-mutation queue | No append mode — every call rewrites the file. |
| `edit` | `edits[]` of `{oldText, newText}`; exact-text match; multi-edit in one call preferred | Robustness depends on `prepareEditArguments` preprocessing for legacy/stringified shapes — provider drift still leaks in. Whitespace/quote drift is retry-prone vs hash-anchored alternatives (oh-my-pi hashline). |
| `bash` | shell-config-aware exec; tail truncation; full output to temp file; timeout/abort kills process tree | **Any non-zero exit code = tool error.** Collides with `grep` / `diff` / `test` semantics — agent control flow can be misled. |
| `grep`, `find`, `ls` | seven built-ins total, but Quick Start docs only mention four | Doc inconsistency — the CLI reference is canonical (see Contradictions below). |

Full code refs + per-flag details: [A2#Code refs](../../A2/output/finding.md#code-refs). Recent behavior-shaping issue threads (truncation, Windows shell paths, fuzzy-match regressions): [A2#Code refs](../../A2/output/finding.md#code-refs).

---

## 3. Pick a run mode

Source: [A3#Building blocks](../../A3/output/finding.md#building-blocks--concepts), [A3#Examples](../../A3/output/finding.md#examples).

```bash
pi                                              # 1) Interactive TUI
pi -p "Summarize src/main.ts"                   # 2) One-shot text
pi --mode json "List TypeScript files"          # 3) One-shot JSONL events
pi --mode rpc --model anthropic/claude-sonnet-4-5  # 4) Long-lived RPC loop
```

Selection guide (synthesized from [A3#Summary](../../A3/output/finding.md#summary)):

- **Interactive** — humans, exploratory work. TUI with slash commands, model selector, queue UX, extension widgets.
- **Print text** (`-p`) — shell pipelines that just want the assistant's final text. Exits non-zero on assistant error/abort.
- **Print JSON** (`--mode json`) — same one-shot lifecycle, but emits a session header followed by an `AgentSessionEvent` JSONL stream. Use when you need to see tool calls / token usage / events.
- **RPC** (`--mode rpc`) — long-lived stdin/stdout JSONL loop with request/response correlation (`id` field) and an extension-UI sub-protocol. Use when a host process drives multiple prompts and needs lifecycle control. JSONL framing is **strict LF only** — generic Node `readline` is protocol-risky because of Unicode line separators in payloads.
- **SDK embedding** — in-process `createAgentSession()` / `AgentSessionRuntime`. `OpenClaw` / `PiClaw` use this path; `Polpo` uses RPC. RPC is **not** the universal integration path.

Wire-format detail and a real RPC exchange: [A3#Examples](../../A3/output/finding.md#examples).

---

## 4. Pick a provider + cost awareness

Source: [A4#Building blocks](../../A4/output/finding.md#building-blocks--concepts), [A4#Examples](../../A4/output/finding.md#examples).

Key model from A4: **the provider layer is API-first, not vendor-first.** `model.api` resolves to a registered API adapter (Anthropic, OpenAI variants, Google variants, Bedrock, Mistral — 10 adapters total); `model.provider` is metadata/auth/routing. The model registry exposes 25 top-level providers, but most are OpenAI/Anthropic/Google-compatible overlays rather than bespoke transports.

Beginner essentials:

- `/model` swaps mid-session — calls `session.setModel()`, enforces auth, appends a `model_change` entry, re-clamps thinking level. RPC has the equivalent command.
- Cost is unified: every provider emits `usage.{input, output, cacheRead, cacheWrite, totalTokens, cost}`. Session aggregates roll up from assistant turns; daily breakdown via `scripts/cost.ts`.
- Cross-provider replay rewrites tool-call IDs, downgrades unsupported image blocks, and **synthesizes missing tool results** to keep loops valid. Replayed context is therefore not byte-identical to the original.
- Reasoning levels are clamped per provider (e.g., `xhigh → high` where unsupported).
- `getAvailable()` hides models with no configured auth — provider breadth is larger than what `/model` initially shows. Add a key, re-open `/model`.

Code snippet for SDK use (`completeSimple` + cost field): [A4#Examples](../../A4/output/finding.md#examples). Dynamic provider override from an extension: same section.

---

## 5. Sessions + tree resume

Source: [A5#Building blocks](../../A5/output/finding.md#building-blocks--concepts), [A5#Examples](../../A5/output/finding.md#examples).

Mental model:

- A session is an **append-only JSONL tree**. Each entry is a node with `id` / `parentId`. A mutable `leafId` defines the active branch head.
- The model never sees "all entries" — it sees the **root → leaf path** projected via `buildSessionContext()` (with compaction and branch-summary handling).
- **Branching is pointer movement**, not history rewrite. `/tree` rewinds `leafId` to a prior message and optionally summarizes the abandoned path as a `branch_summary` entry.
- **Fork** (`createBranchedSession()`) creates a *new session file* with a `parentSession` link. `/tree` stays in the current file.
- **Resume** (`--resume`, `--continue`) is runtime replacement: `switchSession()` tears down the old runtime, loads the target session + cwd, emits `session_before_switch` / `session_start(reason: "resume")` lifecycle events, and rebinds. `session_before_switch` can cancel.

Minimal in-memory branching example: [A5#Examples](../../A5/output/finding.md#examples).

---

## 6. Common first-session pitfalls

Harvested from every input's "Gotchas" section. Each item links back to its source.

- **Silent parent-dir context inheritance.** Startup walks parent directories for `AGENTS.md`/`CLAUDE.md`. Stale repo-level instructions can load without you noticing — check the header. ([A1#Gotchas](../../A1/output/finding.md#gotchas--surprises))
- **`process.emitWarning` is no-op'd in the CLI entrypoint.** Reduces noise but also hides Node runtime warnings during install troubleshooting. ([A1#Gotchas](../../A1/output/finding.md#gotchas--surprises))
- **Install publish-race window.** Issue #3280 reports `ETARGET` from version skew between `pi-agent-core` and `pi-ai`. No official guardrail yet; retry or pin if it bites. ([A1#Gotchas](../../A1/output/finding.md#gotchas--surprises))
- **`bash` treats every non-zero exit as a tool error.** Breaks `grep`/`diff`/`test` flow control. ([A2#Gotchas](../../A2/output/finding.md#gotchas--surprises))
- **`bash` truncation has had correctness bugs.** Issue #2852 fixed a case where "full output" file was missing. Trust but verify the temp-file pointer. ([A2#Gotchas](../../A2/output/finding.md#gotchas--surprises))
- **Windows shell/path edges.** `shellPath`, MinGW mkdir/write, detached descendants — recurring breakage. ([A2#Gotchas](../../A2/output/finding.md#gotchas--surprises))
- **Print mode triggered by non-TTY stdin.** Even without `-p`, piping into `pi` forces print path unless RPC is explicit. ([A3#Gotchas](../../A3/output/finding.md#gotchas--surprises))
- **`--mode json` ≠ `--mode rpc`.** JSON is one-shot event dump; RPC is a command loop with request correlation + extension-UI sub-protocol. ([A3#Gotchas](../../A3/output/finding.md#gotchas--surprises))
- **RPC `prompt` returns success at preflight, not at completion.** Final state arrives via later `agent_end` event. ([A3#Gotchas](../../A3/output/finding.md#gotchas--surprises))
- **Strict LF JSONL framing.** Don't use generic `readline` for RPC stdout — Unicode separators inside payloads will corrupt frames. ([A3#Gotchas](../../A3/output/finding.md#gotchas--surprises))
- **RPC UI coverage is partial.** Many TUI methods (`setFooter`, `setHeader`, theme switching) are no-ops or degraded under RPC. ([A3#Gotchas](../../A3/output/finding.md#gotchas--surprises))
- **`/model` hides un-authed models.** Breadth is larger than what shows. Add key, reopen. ([A4#Gotchas](../../A4/output/finding.md#gotchas--surprises))
- **Cross-provider replay is not byte-identical.** Synthetic tool-result insertion keeps loops valid but mutates history semantics. ([A4#Gotchas](../../A4/output/finding.md#gotchas--surprises))
- **Resume-time cwd drift.** `--continue` cwd handling was called out in #3249. Cross-project resumes are high-risk because tools bind to cwd. ([A5#Gotchas](../../A5/output/finding.md#gotchas--surprises))
- **`/tree` ≠ `/resume` state restoration.** Issue #3544 reports model/thinking knobs not restored consistently between the two paths. ([A5#Gotchas](../../A5/output/finding.md#gotchas--surprises))
- **`navigateTree()` cleanup hole.** Bug #3688: early-return on cancel can leave `isCompacting` true. ([A5#Gotchas](../../A5/output/finding.md#gotchas--surprises))
- **Symlinked session roots can break parent/child linking** in the resume threaded view (#3364). ([A5#Gotchas](../../A5/output/finding.md#gotchas--surprises))

---

## Contradictions

Surfaced per plan-04 rule against smoothing. These either leak into beginner experience or signal doc/code drift.

1. **Built-in tool count: 4 vs 7.** A1 reports the README Quick Start emphasizes four default tools, but the CLI reference lists seven (`read`, `bash`, `edit`, `write`, `grep`, `find`, `ls`). ([A1#Gotchas](../../A1/output/finding.md#gotchas--surprises) vs [A2#Summary](../../A2/output/finding.md#summary)). Treat the CLI reference as canonical.
2. **RPC as primary integration path — claimed vs observed.** A3's official docs nudge toward RPC for host-driven integration, but A3's own field survey shows real-world clients are split: Polpo uses RPC, OpenClaw/PiClaw bypass RPC and embed via `createAgentSession`/runtime APIs. RPC is not the universal path. ([A3#Summary](../../A3/output/finding.md#summary), [A3#Gotchas](../../A3/output/finding.md#gotchas--surprises)).
3. **Docs vs code on session API names.** A5 found docs reference `getLeafUuid()` while runtime code uses `getLeafId()`. Code is canonical. ([A5#Gotchas](../../A5/output/finding.md#gotchas--surprises)).
4. **Worker-brief path drift.** A4 documents the provider layer at `packages/ai`, not the briefed `packages/api`; no `coding-agent/src/providers` exists in the current checkout. Beginner-relevant because tutorials and stale third-party blog posts may point at obsolete paths. ([A4#Gotchas](../../A4/output/finding.md#gotchas--surprises)).
5. **`--no-session` ephemeral framing vs append-only persistence.** A1 recommends `--no-session` as a clean-room first run; A5 establishes that sessions are append-only JSONL trees. Not a logic contradiction, but a framing tension: a beginner reading A1 may not realize that *with* sessions, every prompt persists — including mistakes — and that "resetting" later means `/tree` rewind or `--no-session`, not file deletion. ([A1#Examples](../../A1/output/finding.md#examples) vs [A5#Building blocks](../../A5/output/finding.md#building-blocks--concepts)).

---

## What this doc does NOT cover

- **Extensions, skills, packaging internals.** → handled by S3 (power-user recipes) and the B-track findings (B1 extensions, B2 skills).
- **Headless review / multi-provider cost optimization / fleet-via-RPC recipes.** → S3.
- **Whether existing fleet skills run on pi today.** → S4.
- **Per-skill keep-bash / port-to-extension / hybrid verdicts.** → S5.
- **Aggregated open questions across all 13 workers.** → S6. (This doc preserved every Gotcha but did not enumerate Open Questions; those feed S6.)
- **Market positioning vs Cursor / aider / Claude Code.** → B5 / S3.
- **Deeper run-mode wire-format reference** (full RPC schema, JSON event taxonomy). → read [A3#Code refs](../../A3/output/finding.md#code-refs) directly.
- **Provider internals** (per-provider transform shims, encrypted reasoning content, Bedrock Converse details). → read [A4#Code refs](../../A4/output/finding.md#code-refs) directly.
- **Session-tree compaction internals** (branch-summary budgeting, common-ancestor walks). → read [A5#Code refs](../../A5/output/finding.md#code-refs) directly.

---

## Source map

Every section above cites its source worker by relative path + section anchor. The five upstream findings remain authoritative:

- [A1 — bootstrap](../../A1/output/finding.md)
- [A2 — core tools](../../A2/output/finding.md)
- [A3 — run modes](../../A3/output/finding.md)
- [A4 — providers](../../A4/output/finding.md)
- [A5 — sessions](../../A5/output/finding.md)
