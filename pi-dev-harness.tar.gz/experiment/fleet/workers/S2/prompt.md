# Worker S2 — beginner onboarding (synthesis)

You are a synthesis worker. Inputs = upstream worker findings on disk. Output = one synthesis doc + sibling pointers.

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/plans/04-synthesis-multi-doc.md` — it defines the lossless-merge contract you MUST follow.

## Input findings (read these — verbatim from worker output)

- $FLEET_ROOT/workers/A1/output/finding.md (bootstrap)
- $FLEET_ROOT/workers/A2/output/finding.md (core tools)
- $FLEET_ROOT/workers/A3/output/finding.md (run modes)
- $FLEET_ROOT/workers/A4/output/finding.md (providers)
- $FLEET_ROOT/workers/A5/output/finding.md (sessions)

Also read each input's sibling `sources.md` to understand exploration breadth (helps you weigh confidence).

## Audience

New pi.dev user. Wants to install, run, understand the building blocks, and have a first session.

## Required structure

Linear walkthrough with code snippets:
1. Install + first run (from A1)
2. Core tools — what each does, gotchas (from A2)
3. Pick a run mode (from A3)
4. Pick a provider + cost awareness (from A4)
5. Understand sessions + tree resume (from A5)
6. Common first-session pitfalls (harvest from all Gotchas sections)

## Mandatory rules (per plan 04)

- NO concatenation. Link to source findings, do not paste.
- NO replacing a finding with its summary inline — link instead.
- NO dropping "Open questions" / "Gotchas" — those feed sibling synth doc S6.
- NO smoothing contradictions. Surface them with a "Contradictions" subsection.
- Tables stay tables.
- End with: "## What this doc does NOT cover" — point to sibling synth docs (S1-S6) that handle the excluded scope.

## Citation form

Cite worker findings as `[A2#Building blocks](../../A2/output/finding.md#building-blocks--concepts)` — relative paths from your output dir.

## Health targets (synth-tier)

- 100% finding coverage (every relevant input cited or explicitly excluded with reason)
- ≥3 cross-finding contradictions surfaced (or "no contradictions found, here's why")
- ≥5 actionable items (S4/S5 only)
- 0 lossy summaries

## Deliverable

`$FLEET_ROOT/workers/S2/output/synthesis.md`

Save ALL output files to `$FLEET_ROOT/workers/S2/output/` — use absolute paths.
