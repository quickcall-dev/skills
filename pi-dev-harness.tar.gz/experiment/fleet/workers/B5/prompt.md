# Worker B5 — comparison vs Claude Code, Cursor, aider, codex

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Strengths, gaps, lock-in cost, customization ceiling, headless suitability.

## Sources you own (do not touch others')

- External reviews: petronellatech.com, topai.tools, aitoolnet.com, aisoftwaresystems.com, tazlab.net
- Claude Code docs (anthropic.com)
- aider docs
- Cursor docs
- Codex CLI docs
- Comparative blog posts and reviews

## Out of scope (other workers cover)

- Provider layer (A4)
- Power users (B4)

## Source-mix target (per plan 05)

40% pi material, 60% comparator docs + reviews. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/B5/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/B5/output/` — use absolute paths.
