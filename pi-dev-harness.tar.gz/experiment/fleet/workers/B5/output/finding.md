## Summary
- `pi` is strongest when you want a terminal-first, extensible coding agent with explicit hooks/skills/themes and first-class session/tree workflows, but its ecosystem visibility and independent benchmark coverage are thinner than the biggest competitors ([pi.dev](https://pi.dev/), [pi-mono](https://github.com/badlogic/pi-mono), [arXiv 2602.08915](https://arxiv.org/abs/2602.08915)).
- For headless automation, Claude Code, aider, and Codex all expose clearer documented non-IDE workflows today; Cursor has caught up with CLI/background-agent options but is still culturally editor-first in most docs and onboarding ([Anthropic overview](https://docs.anthropic.com/en/docs/claude-code/overview), [Aider usage](https://aider.chat/docs/usage.html), [Codex noninteractive](https://developers.openai.com/codex/noninteractive), [Cursor CLI](https://docs.cursor.com/tools/cli), [Cursor background agents](https://docs.cursor.com/en/background-agents)).
- Lock-in cost is lowest for open-source terminal tools (aider, pi, Codex CLI OSS client) and highest when workflows depend on proprietary managed backends, hosted agent state, or GUI-specific affordances ([Aider repo](https://github.com/Aider-AI/aider), [/tmp/aider/README.md:63], [OpenAI Codex repo](https://github.com/openai/codex), [/tmp/codex/README.md:2], [Cursor privacy](https://cursor.com/privacy), [Anthropic settings](https://docs.anthropic.com/en/docs/claude-code/settings)).

## Building blocks / concepts
- `Lock-in cost`: migration pain from one tool to another, driven by prompt/memory format, CLI automation surface, and vendor-specific infra hooks. Claude’s `CLAUDE.md` and settings hierarchy are explicit and portable as files, but integration flows (GitHub app installer, cloud credentials) still create sticky operational coupling ([Anthropic settings](https://docs.anthropic.com/en/docs/claude-code/settings), [Anthropic GitHub Actions](https://docs.anthropic.com/en/docs/claude-code/github-actions)).
- `Customization ceiling`: how far a team can bend the agent via local policy, commands, and extension points. Cursor exposes rules/modes/background agents, Claude exposes slash commands/settings/MCP/subagents, aider exposes many CLI/runtime switches, and Codex documents config/MCP/skills; pi positions itself around extension/skills/themes packaging in-core ([Cursor modes](https://docs.cursor.com/agent/modes), [Cursor background agents](https://docs.cursor.com/en/background-agents), [Anthropic slash commands](https://docs.anthropic.com/en/docs/claude-code/slash-commands), [/tmp/aider/aider/website/docs/config/options.md:25], [/tmp/codex/docs/config.md:11], [pi.dev](https://pi.dev/)).
- `Headless suitability`: ability to run unattended or scriptable jobs. Strong in aider/Codex/Claude CLI flows and improving in Cursor via CLI + remote background agents ([Aider scripting](https://aider.chat/docs/scripting.html), [Codex noninteractive](https://developers.openai.com/codex/noninteractive), [Anthropic common workflows](https://docs.anthropic.com/en/docs/claude-code/common-workflows), [Cursor CLI](https://docs.cursor.com/tools/cli), [Cursor background agents](https://docs.cursor.com/en/background-agents)).
- `Strengths vs gaps matrix`:
- `pi`: strong extensibility narrative and terminal-native posture; gap is lower third-party validation and fewer neutral benchmarks than major incumbents ([pi.dev](https://pi.dev/), [pi-mono issues](https://github.com/badlogic/pi-mono/issues), [arXiv 2602.08915](https://arxiv.org/abs/2602.08915)).
- `Claude Code`: strong autonomy, broad docs, enterprise workflow docs; gap is higher managed-service coupling and less OSS inspectability than aider/pi ([Anthropic overview](https://docs.anthropic.com/en/docs/claude-code/overview), [Anthropic settings](https://docs.anthropic.com/en/docs/claude-code/settings), [Aider repo](https://github.com/Aider-AI/aider)).
- `Cursor`: strong IDE UX plus remote agents; gap is lock-in to app account/state and mixed clarity between editor-first and CLI-first modes ([Cursor docs](https://docs.cursor.com/), [Cursor CLI](https://docs.cursor.com/tools/cli), [Cursor background agents](https://docs.cursor.com/en/background-agents)).
- `aider`: strongest low-lock-in OSS terminal workflow and git-centric edit loop; gap is steeper setup/tuning burden for non-power users ([/tmp/aider/README.md:63], [/tmp/aider/aider/website/docs/usage.md:88], [/tmp/aider/aider/website/docs/config/options.md:25]).
- `Codex`: strong local CLI + explicit noninteractive/docs + MCP config docs; gap is ecosystem maturity still consolidating relative to older tools ([/tmp/codex/README.md:2], [/tmp/codex/docs/exec.md:1], [/tmp/codex/docs/config.md:11], [OpenAI codex docs](https://developers.openai.com/codex)).

## Code refs
- Aider is terminal-first pair programming: `/tmp/aider/README.md:6`, `/tmp/aider/README.md:11`.
- Aider auto-commits by design in normal workflows: `/tmp/aider/README.md:63`, `/tmp/aider/aider/website/docs/usage.md:88`.
- Aider exposes extensive CLI configurability including model/API/git/lint/test/watch flags: `/tmp/aider/aider/website/docs/config/options.md:25`, `/tmp/aider/aider/website/docs/config/options.md:65`.
- Codex CLI is documented as local computer execution: `/tmp/codex/README.md:2`.
- Codex has explicit non-interactive mode doc entry point: `/tmp/codex/docs/exec.md:1`.
- Codex config includes MCP connections and tool approval controls: `/tmp/codex/docs/config.md:11`, `/tmp/codex/docs/config.md:31`, `/tmp/codex/docs/config.md:33`.
- Codex config documents parallel MCP tool-call safety tradeoffs: `/tmp/codex/docs/config.md:16`, `/tmp/codex/docs/config.md:25`.
- Codex config includes local state-db behavior by sandbox mode: `/tmp/codex/docs/config.md:65`, `/tmp/codex/docs/config.md:66`.
- Codex AGENTS precedence behavior appears behind feature flag in repo docs: `/tmp/codex/docs/agents_md.md:5`, `/tmp/codex/docs/agents_md.md:7`.

## Examples
```bash
# Claude Code: initialize project memory, then run normal interactive flow
claude
/init
```
([Anthropic slash commands](https://docs.anthropic.com/en/docs/claude-code/slash-commands))

```bash
# aider: explicit file-scoped session with model override
aider src/main.py src/utils.py --model sonnet --api-key anthropic=$ANTHROPIC_API_KEY
```
([Aider usage](https://aider.chat/docs/usage.html), [/tmp/aider/aider/website/docs/usage.md:17], [/tmp/aider/aider/website/docs/usage.md:75])

```bash
# Codex: non-interactive invocation entry point (automation-oriented)
codex exec "run tests, fix failures, and summarize changes"
```
([Codex noninteractive](https://developers.openai.com/codex/noninteractive), [/tmp/codex/docs/exec.md:1])

```bash
# Cursor: editor launch from terminal / script contexts
cursor .
```
([Cursor CLI](https://docs.cursor.com/tools/cli))

## Gotchas / surprises
- Contradiction 1: many review blogs frame Cursor as IDE-only, but Cursor now has both CLI and asynchronous background agents, changing older positioning narratives ([Builder comparison](https://www.builder.io/blog/cursor-vs-claude-code), [Cursor CLI](https://docs.cursor.com/tools/cli), [Cursor background agents](https://docs.cursor.com/en/background-agents)).
- Contradiction 2: directory/listing sites (TopAI/AIToolnet) often present stale model/version details versus official docs; useful for discoverability, weak for current technical truth ([TopAI Claude Code](https://topai.tools/t/claude-code), [AIToolnet Claude Code](https://www.aitoolnet.com/claude-code), [Anthropic overview](https://docs.anthropic.com/en/docs/claude-code/overview)).
- Contradiction 3: community reviews repeatedly claim one universal winner, while current academic analyses show task-dependent winners across doc/feature/fix classes ([arXiv 2602.08915](https://arxiv.org/abs/2602.08915), [arXiv 2602.02345](https://arxiv.org/abs/2602.02345), [Reddit discussion](https://www.reddit.com/r/cursor/comments/1qz8rof/cursor_vs_claude_code_vs_codex_ignore_price/)).
- Contradiction 4: “open-source means lower lock-in” is directionally true, but teams still self-lock via proprietary APIs, model aliases, and workflow conventions even with OSS CLIs ([/tmp/aider/aider/website/docs/config/options.md:112], [/tmp/codex/docs/config.md:11], [Aider llms](https://aider.chat/docs/llms.html)).
- Contradiction 5: several third-party posts rank tools by UI preference, but headless suitability depends more on scripting surface, approval policy controls, and remote execution semantics than UI polish ([Petronella Claude guide](https://petronellatech.com/blog/claude-code-cli-guide-ai-powered-development/), [Codex exec-policy](https://developers.openai.com/codex/exec-policy), [Cursor background agents](https://docs.cursor.com/en/background-agents), [Aider scripting](https://aider.chat/docs/scripting.html)).
- Surprise 6: Cloudflare/anti-bot protection on several review aggregators reduces reproducibility of longitudinal comparisons unless mirrored or archived, which itself can bias evidence quality.

## Open questions
- I could not reliably access full crawlable content from some assigned review domains without mirror/proxy paths; should B5 treat those as low-confidence metadata-only sources or exclude them in synthesis?
- For strict lock-in-cost scoring, do we want a fixed rubric (migration hours, config portability, CI portability, policy portability) so S-stage synthesis can normalize across workers?
- Should `pi` comparison weights emphasize terminal-native extensibility even when benchmark literature under-represents it versus commercial tools?
- Do we want separate rankings for `solo dev`, `regulated enterprise`, and `CI-first headless` use cases? Current sources mix these personas.

## Cross-refs
- Provider-layer comparisons (model routing depth, token pricing normalization, provider failover) belong to A4.
- Power-user adoption narratives, social proof, and influencer workflows belong to B4.
- Extension internals and skill-prompt architecture depth belong to B1/B2.
