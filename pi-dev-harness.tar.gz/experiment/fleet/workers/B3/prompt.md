# Worker B3 — ecosystem catalog

**FIRST**: read `/home/sagar/skills/docs/experiments/004-pi-dev-harness/fleet/workers/_shared_research_brief.md` (health targets, citation contract, output sections — all mandatory).

## Your slice (MECE)

Published packages under @mariozechner/* and pi-* namespaces, notable forks, awesome-pi if exists.

## Sources you own (do not touch others')

- npm registry search: `@mariozechner/*`, `pi-extension`, `pi-skill`
- GitHub search `topic:pi-extension`, `topic:pi-coding-agent`
- oh-my-pi repo
- Any awesome-pi / curated lists

## Out of scope (other workers cover)

- Skills/prompts internals (B2)
- Power users (B4)

## Source-mix target (per plan 05)

100% breadth — npm + GH search + curated lists. Aim wide. Total ≥100 sources.

## Deliverable

`$FLEET_ROOT/workers/B3/output/finding.md` + `sources.md`

Save ALL output files to `$FLEET_ROOT/workers/B3/output/` — use absolute paths.
